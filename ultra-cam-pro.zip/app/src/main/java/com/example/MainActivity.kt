package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.camera.AppCaptureDomain
import com.example.camera.CameraPermissionStatus
import com.example.camera.CameraViewModel
import com.example.ui.screens.CameraScreen
import com.example.ui.screens.HardwareInspectorOverlay
import com.example.ui.screens.PermissionWelcomeScreen
import com.example.ui.screens.PhotoViewerOverlay
import com.example.ui.theme.UltraCamProTheme

class MainActivity : ComponentActivity() {

  private val cameraViewModel: CameraViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
    )
    setContent {
      UltraCamProTheme {
        UltraCamProApp(activity = this, viewModel = cameraViewModel)
      }
    }
  }

  override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
    if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
      val state = cameraViewModel.uiState.value
      if (
        state.permissionStatus == CameraPermissionStatus.GRANTED &&
          !state.isHardwareInspectorOpen &&
          !state.isPhotoViewerOpen &&
          state.isVolumeShutterEnabled
      ) {
        if (event?.repeatCount == 0) {
          cameraViewModel.triggerVolumeShutter()
        }
        return true
      }
    }
    return super.onKeyDown(keyCode, event)
  }
}

@Composable
fun UltraCamProApp(
  activity: ComponentActivity,
  viewModel: CameraViewModel,
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  // Sync permission state on start/resume without ever auto-launching the permission dialog
  DisposableEffect(lifecycleOwner, context) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        val granted =
          ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
          viewModel.updatePermissionStatus(CameraPermissionStatus.GRANTED)
        } else if (uiState.permissionStatus == CameraPermissionStatus.GRANTED) {
          viewModel.updatePermissionStatus(CameraPermissionStatus.NOT_REQUESTED)
        }
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  LaunchedEffect(Unit) {
    viewModel.startObservingPresets(context)
  }

  LaunchedEffect(uiState.permissionStatus) {
    if (uiState.permissionStatus == CameraPermissionStatus.GRANTED) {
      viewModel.loadLatestAppPhotoIfNeeded(context)
    }
  }

  // Official Android runtime permission launcher — triggered ONLY when the user taps Open Camera
  val cameraPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
      if (isGranted) {
        viewModel.updatePermissionStatus(CameraPermissionStatus.GRANTED)
      } else {
        val canAskAgain =
          ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.CAMERA)
        viewModel.updatePermissionStatus(
          if (canAskAgain) CameraPermissionStatus.DENIED
          else CameraPermissionStatus.PERMANENTLY_DENIED
        )
      }
    }

  // Zero-permission Android Photo Picker fallback for browsing gallery photos
  val photoPickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) {
        viewModel.openPickedPhotoUri(context, uri)
      }
    }

  val launchGallery = {
    val isVideoContext =
      uiState.captureDomain == AppCaptureDomain.VIDEO || uiState.lastCapturedPhoto?.isVideo == true
    val galleryIntent =
      Intent(Intent.ACTION_VIEW).apply {
        if (isVideoContext) {
          setDataAndType(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video/*")
        } else {
          setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
        }
      }
    try {
      context.startActivity(galleryIntent)
    } catch (_: Exception) {
      photoPickerLauncher.launch(
        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
      )
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    AnimatedContent(
      targetState = uiState.permissionStatus == CameraPermissionStatus.GRANTED,
      transitionSpec = { fadeIn() togetherWith fadeOut() },
      label = "permissionToCameraTransition",
    ) { hasCameraPermission ->
      if (!hasCameraPermission) {
        PermissionWelcomeScreen(
          permissionStatus = uiState.permissionStatus,
          onOpenCameraClick = {
            val alreadyGranted =
              ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
            if (alreadyGranted) {
              viewModel.updatePermissionStatus(CameraPermissionStatus.GRANTED)
            } else {
              cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
          },
          onOpenSettingsClick = {
            val settingsIntent =
              Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
              }
            context.startActivity(settingsIntent)
          },
        )
      } else {
        CameraScreen(
          uiState = uiState,
          volumeShutterEvents = viewModel.volumeShutterEvents,
          onInventoryScanned = viewModel::updateDeviceInventory,
          onSelectCaptureDomain = viewModel::selectCaptureDomain,
          onSelectCameraId = viewModel::selectSpecificCamera,
          onSwitchCamera = viewModel::switchCamera,
          onSelectAspectRatio = viewModel::selectAspectRatio,
          onCycleFlash = viewModel::cycleFlashSetting,
          onCycleTimer = viewModel::cycleShutterTimer,
          onStartCountdown = viewModel::startCountdownAndCapture,
          onCancelCountdown = viewModel::cancelCountdown,
          onToggleQuickCapture = viewModel::toggleCaptureSpeedMode,
          onToggleBurstMode = viewModel::toggleBurstMode,
          onBurstProgress = viewModel::updateBurstProgress,
          onToggleGrid = viewModel::toggleGrid,
          onToggleLevel = viewModel::toggleLevelIndicator,
          onToggleFrontMirror = viewModel::toggleFrontMirror,
          onToggleVolumeShutter = viewModel::toggleVolumeShutter,
          onToggleExposureLock = viewModel::toggleExposureLock,
          onExposureCompChanged = viewModel::updateExposureIndex,
          onToggleProPanel = viewModel::toggleProPanel,
          onSelectProTab = viewModel::selectProTab,
          onSetManualIso = viewModel::setManualIso,
          onSetManualShutter = viewModel::setManualShutter,
          onSetWhiteBalance = viewModel::setWhiteBalance,
          onSetManualKelvin = viewModel::setManualKelvin,
          onSetManualFocus = viewModel::setManualFocus,
          onSelectCaptureFormat = viewModel::selectCaptureOutputFormat,
          onSelectStabilization = viewModel::selectStabilization,
          onToggleFocusPeaking = viewModel::toggleFocusPeaking,
          onCycleFocusPeakingColor = viewModel::cycleFocusPeakingColor,
          onToggleHistogram = viewModel::toggleHistogram,
          onToggleZebra = viewModel::toggleZebraExposure,
          onSetZebraThreshold = viewModel::setZebraThreshold,
          onLiveTelemetry = viewModel::updateLiveTelemetry,
          onFrameAnalysis = viewModel::updateFrameAnalysis,
          onModeCapabilitiesEvaluated = viewModel::updateModeCapabilities,
          onSelectPhotographyMode = viewModel::selectPhotographyMode,
          onPanoramaProgress = viewModel::updatePanoramaProgress,
          onPanoramaMotion = viewModel::updatePanoramaMotion,
          onResetPanorama = viewModel::resetPanoramaSession,
          onVideoCapabilitiesUpdated = viewModel::updateVideoCapabilities,
          onToggleVideoSettings = viewModel::toggleVideoSettingsPanel,
          onSelectVideoQuality = viewModel::selectVideoQuality,
          onSelectVideoFps = viewModel::selectVideoFps,
          onSelectVideoBitrate = viewModel::selectVideoBitrate,
          onSelectVideoStabilization = viewModel::selectVideoStabilization,
          onToggleVideoHdr = viewModel::toggleVideoHdr,
          onToggleVideoAudio = viewModel::toggleVideoAudio,
          onEnableSilentVideo = viewModel::enableSilentVideoMode,
          onToggleVideoTorch = viewModel::toggleVideoTorch,
          onToggleSlowMoBaked = viewModel::toggleSlowMotionBakedIn,
          onUpdateAudioPermissionStatus = viewModel::updateAudioPermissionStatus,
          onVideoRecordingStarted = viewModel::onVideoRecordingStarted,
          onVideoRecordingStatus = viewModel::onVideoRecordingStatus,
          onVideoRecordingPaused = viewModel::onVideoRecordingPaused,
          onVideoRecordingResumed = viewModel::onVideoRecordingResumed,
          onVideoRecordingFinalizing = viewModel::onVideoRecordingFinalizing,
          onVideoRecordingSaved = { uri, name, durationMs, fps, isHdr ->
            viewModel.onVideoRecordingSaved(context, uri, name, durationMs, fps, isHdr)
          },
          onVideoRecordingFailed = viewModel::onVideoRecordingFailed,
          onSavePreset = { name -> viewModel.saveCustomPreset(context, name) },
          onApplyPreset = viewModel::applyCustomPreset,
          onDeletePreset = { id -> viewModel.deleteCustomPreset(context, id) },
          onResetAllToAuto = viewModel::resetAllProToAuto,
          onOpenHardwareInspector = { viewModel.openHardwareInspector() },
          onOpenLastPhoto = {
            uiState.lastCapturedPhoto?.let { photo -> viewModel.openPhotoViewer(photo) }
          },
          onOpenGallery = launchGallery,
          onCameraAvailabilityChecked = viewModel::updateCameraAvailability,
          onCapabilitiesUpdated = viewModel::updateSensorCapabilities,
          onZoomChanged = viewModel::updateZoomRatio,
          onFocusTap = viewModel::showFocusPoint,
          onCaptureStarted = viewModel::onCaptureStarted,
          onCaptureSucceeded = { uri, name, rawSaved, burstSummary ->
            viewModel.onCaptureSucceeded(context, uri, name, rawSaved, burstSummary)
          },
          onCaptureFailed = viewModel::onCaptureFailed,
          onCameraBindError = viewModel::onCameraBindError,
        )
      }
    }

    if (uiState.isHardwareInspectorOpen) {
      HardwareInspectorOverlay(
        inventory = uiState.deviceInventory,
        selectedCameraId = uiState.inspectorSelectedCameraId,
        activeCameraId = uiState.activeCameraId,
        onSelectCamera = viewModel::selectInspectorCamera,
        onUseCameraInViewfinder = { cameraId ->
          viewModel.selectSpecificCamera(cameraId)
          viewModel.closeHardwareInspector()
        },
        onClose = viewModel::closeHardwareInspector,
      )
    }

    val inspectedPhoto = uiState.inspectedPhoto
    if (uiState.isPhotoViewerOpen && inspectedPhoto != null) {
      PhotoViewerOverlay(
        photo = inspectedPhoto,
        onClose = viewModel::closePhotoViewer,
        onOpenInSystemGallery = { photo ->
          val mimeType =
            when {
              photo.isVideo -> "video/mp4"
              photo.displayName.endsWith(".dng", ignoreCase = true) -> "image/x-adobe-dng"
              else -> "image/jpeg"
            }
          val viewIntent =
            Intent(Intent.ACTION_VIEW).apply {
              setDataAndType(photo.uri, mimeType)
              addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
          try {
            context.startActivity(viewIntent)
          } catch (_: Exception) {
            launchGallery()
          }
        },
      )
    }
  }
}
