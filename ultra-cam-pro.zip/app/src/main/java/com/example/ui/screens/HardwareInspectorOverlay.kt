package com.example.ui.screens

import android.hardware.camera2.CameraMetadata
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.camera.CameraHardwareProfile
import com.example.camera.DeviceCameraInventory
import com.example.ui.theme.CaptureEmerald
import com.example.ui.theme.HairlineLight
import com.example.ui.theme.HairlineSubtle
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.OpticalCyan
import com.example.ui.theme.ProAmber
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.SilverSecondary
import com.example.ui.theme.TitaniumWhite
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HardwareInspectorOverlay(
  inventory: DeviceCameraInventory,
  selectedCameraId: String?,
  activeCameraId: String?,
  onSelectCamera: (String) -> Unit,
  onUseCameraInViewfinder: (String) -> Unit,
  onClose: () -> Unit,
  modifier: Modifier = Modifier,
) {
  BackHandler(onBack = onClose)

  val allInspectable =
    rememberInspectableCameras(inventory)
  val selectedProfile =
    allInspectable.firstOrNull { it.cameraId == selectedCameraId } ?: allInspectable.firstOrNull()

  Column(
    modifier =
      modifier
        .fillMaxSize()
        .background(ObsidianBlack)
        .statusBarsPadding()
        .navigationBarsPadding()
  ) {
    // Top Header
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(
        shape = CircleShape,
        color = ObsidianSurface,
        border = BorderStroke(1.dp, HairlineLight),
      ) {
        IconButton(
          onClick = onClose,
          modifier = Modifier.size(48.dp).testTag("close_inspector_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = stringResource(R.string.cd_close_inspector),
            tint = TitaniumWhite,
          )
        }
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = stringResource(R.string.hardware_inspector_title),
          style = MaterialTheme.typography.titleMedium,
          color = TitaniumWhite,
        )
        Text(
          text = stringResource(R.string.hardware_inspector_subtitle),
          style = MaterialTheme.typography.labelSmall,
          color = SilverMuted,
        )
      }
    }

    Column(
      modifier =
        Modifier.fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // 1. Device Camera Array Summary Card
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = ObsidianSurface,
        border = BorderStroke(1.dp, HairlineLight),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "DEVICE CAMERA INVENTORY",
            style = MaterialTheme.typography.labelSmall,
            color = OpticalCyan,
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            InventoryMetric("Logical / Main", "${inventory.allLogicalAndStandaloneCameras.size}")
            InventoryMetric("Physical Sensors", "${inventory.allPhysicalSensors.size}")
            InventoryMetric("Rear", "${inventory.backCameraCount}")
            InventoryMetric("Front", "${inventory.frontCameraCount}")
            if (inventory.externalCameraCount > 0) {
              InventoryMetric("External", "${inventory.externalCameraCount}")
            }
          }
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            PresenceChip("Ultra-Wide", inventory.hasUltraWide)
            PresenceChip("Telephoto", inventory.hasTelephoto)
            PresenceChip("Macro", inventory.hasMacro)
          }
        }
      }

      // 2. Selectable Camera IDs (Logical + Physical)
      if (allInspectable.isNotEmpty()) {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          allInspectable.forEach { profile ->
            val isSelected = profile.cameraId == selectedProfile?.cameraId
            val kindTag =
              when {
                profile.isLogicalMultiCamera -> "LOGICAL"
                profile.isPhysicalOnlySensor -> "PHYSICAL"
                else -> "SENSOR"
              }
            Surface(
              onClick = { onSelectCamera(profile.cameraId) },
              shape = RoundedCornerShape(14.dp),
              color = if (isSelected) TitaniumWhite else ObsidianSurface,
              border = BorderStroke(1.dp, if (isSelected) TitaniumWhite else HairlineLight),
            ) {
              Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(
                  text = "ID ${profile.cameraId} · ${profile.facingLabel} ${profile.role.displayName}",
                  style = MaterialTheme.typography.labelMedium,
                  color = if (isSelected) ObsidianBlack else TitaniumWhite,
                )
                Text(
                  text = "$kindTag · ${profile.hardwareLevel.displayName}",
                  style = MaterialTheme.typography.labelSmall,
                  color = if (isSelected) ObsidianBlack.copy(alpha = 0.7f) else SilverMuted,
                )
              }
            }
          }
        }
      }

      // 3. Detailed Sensor Telemetry Sections for Selected Camera
      selectedProfile?.let { profile ->
        if (profile.isCameraXSelectable && profile.isBackwardCompatible && profile.cameraId != activeCameraId) {
          Surface(
            onClick = { onUseCameraInViewfinder(profile.cameraId) },
            shape = CircleShape,
            color = OpticalCyan,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(vertical = 12.dp),
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Outlined.CameraAlt,
                contentDescription = null,
                tint = ObsidianBlack,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Activate Camera ${profile.cameraId} (${profile.role.displayName}) in Viewfinder",
                style = MaterialTheme.typography.labelLarge,
                color = ObsidianBlack,
              )
            }
          }
        }

        InspectorSectionCard("OPTICS & SENSOR GEOMETRY") {
          KeyValueRow("Camera ID", profile.cameraId)
          KeyValueRow(
            "Sensor Type",
            when {
              profile.isLogicalMultiCamera -> "Logical Multi-Camera (Physical IDs: ${profile.physicalCameraIds.joinToString(", ")})"
              profile.isPhysicalOnlySensor -> "Physical Sub-Sensor (Parent Logical ID: ${profile.parentLogicalCameraId ?: "—"})"
              else -> "Standalone Physical Camera"
            },
          )
          KeyValueRow("Facing & Role", "${profile.facingLabel} · ${profile.role.displayName}")
          KeyValueRow("Hardware Level", profile.hardwareLevel.displayName)
          KeyValueRow(
            "Focal Lengths",
            if (profile.focalLengthsMm.isEmpty()) "Unavailable"
            else profile.focalLengthsMm.joinToString(", ") { "${String.format(Locale.US, "%.2f", it)} mm" },
          )
          KeyValueRow(
            "35mm Equiv / FOV",
            "${profile.equivalent35mmFocalLength?.let { "${it.toInt()} mm" } ?: "—"} / ${profile.horizontalFovDegrees?.let { String.format(Locale.US, "%.1f°", it) } ?: "—"}",
          )
          KeyValueRow("Sensor Physical Size", profile.sensorPhysicalSizeMm ?: "Unavailable")
          KeyValueRow(
            "Aperture(s)",
            if (profile.apertures.isEmpty()) "Unavailable"
            else profile.apertures.joinToString(", ") { "f/$it" },
          )
        }

        InspectorSectionCard("ZOOM & MULTI-LENS OPTICS") {
          KeyValueRow("Optical Zoom", if (profile.hasOpticalZoom) "Supported" else "Not available")
          KeyValueRow("Optical Config", profile.opticalZoomExplanation)
          if (profile.opticalZoomStops.isNotEmpty()) {
            KeyValueRow(
              "Physical Stops",
              profile.opticalZoomStops.joinToString(" · ") {
                "${it.label} (${it.role.shortTag} ${String.format(Locale.US, "%.2f", it.focalLengthMm)}mm)"
              },
            )
          }
          KeyValueRow("Max Digital Zoom", String.format(Locale.US, "%.1f×", profile.maxDigitalZoom))
          KeyValueRow(
            "Zoom Ratio Range",
            profile.controlZoomRatioRange?.let {
              String.format(Locale.US, "%.2f× – %.1f×", it.start, it.endInclusive)
            } ?: "1.0× – ${String.format(Locale.US, "%.1f×", profile.maxDigitalZoom)}",
          )
        }

        InspectorSectionCard("FOCUS, FLASH & EXPOSURE") {
          val foc = profile.focusCapabilities
          KeyValueRow(
            "Autofocus",
            if (foc.isAutoFocusSupported) foc.afModes.joinToString(", ") else "Fixed focus (No AF)",
          )
          KeyValueRow(
            "Manual Focus",
            if (foc.isManualFocusSupported) {
              "Supported (Min ${foc.minimumFocusDistanceCm?.let { String.format(Locale.US, "%.1f cm", it) } ?: "—"} · ${foc.focusCalibrationLabel})"
            } else {
              foc.unsupportedManualReason ?: "Unsupported"
            },
          )
          KeyValueRow("Macro Focus (≤10cm)", if (foc.isMacroFocusCapable) "Capable" else "No")
          KeyValueRow("Flash Unit", profile.flashExplanation)

          val exp = profile.exposureAndRaw
          KeyValueRow(
            "Manual ISO & Shutter",
            if (exp.isManualExposureSupported) "Supported (MANUAL_SENSOR + AE_OFF)"
            else exp.unsupportedManualReason ?: "Unsupported",
          )
          KeyValueRow(
            "ISO Range",
            exp.isoRange?.let { "ISO ${it.first} – ${it.last}" } ?: "Auto only",
          )
          KeyValueRow(
            "Shutter Speed Range",
            exp.shutterRangeNs?.let {
              "${formatShutterSpeed(it.first)} – ${formatShutterSpeed(it.last)}"
            } ?: "Auto only",
          )
          KeyValueRow(
            "RAW (DNG) Capture",
            if (exp.isRawSupported) {
              val camXNote = if (exp.isCameraXRawJpegSupported) "RAW+JPEG active" else "Hardware RAW_SENSOR present"
              "$camXNote (${exp.rawOutputSizes.firstOrNull()?.formattedLabel() ?: "DNG"})"
            } else {
              exp.unsupportedRawReason ?: "Unsupported"
            },
          )
        }

        InspectorSectionCard("IMAGE RESOLUTIONS (${profile.supportedJpegResolutions.size})") {
          KeyValueRow(
            "Max Native JPEG",
            profile.maxJpegResolution?.formattedLabel() ?: "None reported",
          )
          if (profile.supportedJpegResolutions.isNotEmpty()) {
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              profile.supportedJpegResolutions.take(16).forEach { res ->
                val isMax = res == profile.maxJpegResolution
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (isMax) OpticalCyan.copy(alpha = 0.14f) else ObsidianElevated,
                  border = BorderStroke(1.dp, if (isMax) OpticalCyan.copy(alpha = 0.45f) else HairlineSubtle),
                ) {
                  Text(
                    text = "${res.width}×${res.height} · ${String.format(Locale.US, "%.1fMP", res.megapixels)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isMax) OpticalCyan else SilverSecondary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  )
                }
              }
            }
          }
        }

        InspectorSectionCard("FRAME RATES, VIDEO & STABILIZATION") {
          val vid = profile.videoAndStabilization
          KeyValueRow(
            "AE FPS Ranges",
            if (vid.supportedFpsRanges.isEmpty()) "Unavailable"
            else vid.supportedFpsRanges.joinToString(", ") { "${it.first}–${it.last} fps" },
          )
          if (vid.highSpeedFpsRanges.isNotEmpty()) {
            KeyValueRow(
              "High-Speed FPS",
              vid.highSpeedFpsRanges.joinToString(", ") { "${it.first}–${it.last} fps" },
            )
          }
          KeyValueRow(
            "Video Sizes",
            if (vid.supportedVideoSizes.isEmpty()) "Unavailable"
            else vid.supportedVideoSizes.take(6).joinToString(", ") { "${it.width}×${it.height}" },
          )
          KeyValueRow("Optical Stab (OIS)", if (vid.isOisSupported) "Supported" else "Not supported")
          KeyValueRow("Electronic Stab (EIS)", if (vid.isEisSupported) "Supported" else "Not supported")
          KeyValueRow(
            "Preview Stabilization",
            if (vid.isPreviewStabilizationSupported) "Supported" else "Not supported",
          )
        }

        if (profile.capabilityTags.isNotEmpty()) {
          InspectorSectionCard("CAMERA2 CAPABILITY FLAGS") {
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              profile.capabilityTags.forEach { tag ->
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = ObsidianElevated,
                  border = BorderStroke(1.dp, HairlineSubtle),
                ) {
                  Text(
                    text = tag,
                    style = MaterialTheme.typography.labelSmall,
                    color = SilverSecondary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }
}

private fun rememberInspectableCameras(inventory: DeviceCameraInventory): List<CameraHardwareProfile> {
  return (inventory.allLogicalAndStandaloneCameras + inventory.allPhysicalSensors)
    .distinctBy { it.cameraId }
    .sortedWith(
      compareBy<CameraHardwareProfile>(
        {
          when (it.lensFacing) {
            CameraMetadata.LENS_FACING_BACK -> 0
            CameraMetadata.LENS_FACING_FRONT -> 1
            else -> 2
          }
        },
        { if (it.isPhysicalOnlySensor) 1 else 0 },
        { it.cameraId },
      )
    )
}

@Composable
private fun InventoryMetric(label: String, value: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(text = value, style = MaterialTheme.typography.headlineMedium, color = TitaniumWhite)
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = SilverMuted)
  }
}

@Composable
private fun PresenceChip(label: String, detected: Boolean) {
  Surface(
    shape = CircleShape,
    color = if (detected) CaptureEmerald.copy(alpha = 0.14f) else ObsidianBlack,
    border =
      BorderStroke(
        1.dp,
        if (detected) CaptureEmerald.copy(alpha = 0.45f) else HairlineSubtle,
      ),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = if (detected) Icons.Outlined.CheckCircle else Icons.Outlined.Close,
        contentDescription = null,
        tint = if (detected) CaptureEmerald else SilverMuted,
        modifier = Modifier.size(14.dp),
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = if (detected) "$label Detected" else "No $label",
        style = MaterialTheme.typography.labelSmall,
        color = if (detected) TitaniumWhite else SilverMuted,
      )
    }
  }
}

@Composable
private fun InspectorSectionCard(
  title: String,
  content: @Composable () -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(18.dp),
    color = ObsidianSurface,
    border = BorderStroke(1.dp, HairlineSubtle),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        color = ProAmber,
      )
      content()
    }
  }
}

@Composable
private fun KeyValueRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.Top,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium,
      color = SilverMuted,
      modifier = Modifier.weight(0.42f),
    )
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = value,
      style = MaterialTheme.typography.labelMedium,
      color = TitaniumWhite,
      modifier = Modifier.weight(0.58f),
    )
  }
}
