package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraMetadata
import android.hardware.display.DisplayManager
import android.net.Uri
import android.view.OrientationEventListener
import android.view.Surface
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalZeroShutterLag
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.view.PreviewView
import android.graphics.Bitmap
import androidx.core.app.ActivityCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.camera.AppCaptureDomain
import com.example.camera.AudioPermissionStatus
import com.example.camera.CameraCapabilitiesHelper
import com.example.camera.CameraModeCapabilities
import com.example.camera.CameraUiState
import com.example.camera.CameraVideoCapabilities
import com.example.camera.CaptureOutputFormat
import com.example.camera.CaptureSpeedMode
import com.example.camera.DeviceCameraInventory
import com.example.camera.DynamicCameraCapabilityManager
import com.example.camera.FrameAnalysisData
import com.example.camera.LensOption
import com.example.camera.LiveExposureTelemetry
import com.example.camera.LiveFrameAnalyzer
import com.example.camera.ModeCaptureExecutor
import com.example.camera.PanoramaStitcher
import com.example.camera.PhotographyMode
import com.example.camera.PhotographyModeManager
import com.example.camera.PreviewAspectRatio
import com.example.camera.ProControlTab
import com.example.camera.ProPreset
import com.example.camera.SavedCaptureResult
import com.example.camera.SensorCapabilities
import com.example.camera.StabilizationSelection
import com.example.camera.VideoBitrateOption
import com.example.camera.VideoCaptureController
import com.example.camera.VideoFpsOption
import com.example.camera.VideoQualityOption
import com.example.camera.WhiteBalanceOption
import com.example.ui.theme.CaptureEmerald
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.HairlineLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianGlass
import com.example.ui.theme.ProAmber
import com.example.ui.theme.TitaniumWhite
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

@Composable
fun CameraScreen(
  uiState: CameraUiState,
  volumeShutterEvents: Flow<Unit>,
  onInventoryScanned: (DeviceCameraInventory) -> Unit,
  onSelectCaptureDomain: (AppCaptureDomain) -> Unit,
  onSelectCameraId: (String) -> Unit,
  onSwitchCamera: () -> Unit,
  onSelectAspectRatio: (PreviewAspectRatio) -> Unit,
  onCycleFlash: () -> Unit,
  onCycleTimer: () -> Unit,
  onStartCountdown: (onTick: () -> Unit, onComplete: () -> Unit) -> Unit,
  onCancelCountdown: () -> Unit,
  onToggleQuickCapture: () -> Unit,
  onToggleBurstMode: () -> Unit,
  onBurstProgress: (Int?) -> Unit,
  onToggleGrid: () -> Unit,
  onToggleLevel: () -> Unit,
  onToggleFrontMirror: () -> Unit,
  onToggleVolumeShutter: () -> Unit,
  onToggleExposureLock: () -> Unit,
  onExposureCompChanged: (Int) -> Unit,
  onToggleProPanel: () -> Unit,
  onSelectProTab: (ProControlTab) -> Unit,
  onSetManualIso: (Boolean, Int?) -> Unit,
  onSetManualShutter: (Boolean, Long?) -> Unit,
  onSetWhiteBalance: (WhiteBalanceOption) -> Unit,
  onSetManualKelvin: (Int) -> Unit,
  onSetManualFocus: (Boolean, Float?) -> Unit,
  onSelectCaptureFormat: (CaptureOutputFormat) -> Unit,
  onSelectStabilization: (StabilizationSelection) -> Unit,
  onToggleFocusPeaking: () -> Unit,
  onCycleFocusPeakingColor: () -> Unit,
  onToggleHistogram: () -> Unit,
  onToggleZebra: () -> Unit,
  onSetZebraThreshold: (Int) -> Unit,
  onLiveTelemetry: (LiveExposureTelemetry) -> Unit,
  onFrameAnalysis: (FrameAnalysisData) -> Unit,
  onModeCapabilitiesEvaluated: (CameraModeCapabilities) -> Unit,
  onSelectPhotographyMode: (PhotographyMode) -> Unit,
  onPanoramaProgress: (Boolean, Int, Float, Float, Boolean, String) -> Unit,
  onPanoramaMotion: (Float, Float) -> Unit,
  onResetPanorama: () -> Unit,
  onVideoCapabilitiesUpdated: (CameraVideoCapabilities) -> Unit,
  onToggleVideoSettings: () -> Unit,
  onSelectVideoQuality: (VideoQualityOption) -> Unit,
  onSelectVideoFps: (VideoFpsOption) -> Unit,
  onSelectVideoBitrate: (VideoBitrateOption) -> Unit,
  onSelectVideoStabilization: (StabilizationSelection) -> Unit,
  onToggleVideoHdr: () -> Unit,
  onToggleVideoAudio: () -> Unit,
  onEnableSilentVideo: () -> Unit,
  onToggleVideoTorch: () -> Unit,
  onToggleSlowMoBaked: () -> Unit,
  onUpdateAudioPermissionStatus: (AudioPermissionStatus, Boolean?) -> Unit,
  onVideoRecordingStarted: (Boolean) -> Unit,
  onVideoRecordingStatus: (Long, Long, Float, Boolean) -> Unit,
  onVideoRecordingPaused: () -> Unit,
  onVideoRecordingResumed: () -> Unit,
  onVideoRecordingFinalizing: () -> Unit,
  onVideoRecordingSaved: (Uri, String, Long, Int?, Boolean) -> Unit,
  onVideoRecordingFailed: (String) -> Unit,
  onSavePreset: (String) -> Unit,
  onApplyPreset: (ProPreset, (Int) -> Unit) -> Unit,
  onDeletePreset: (String) -> Unit,
  onResetAllToAuto: ((Int) -> Unit) -> Unit,
  onOpenHardwareInspector: () -> Unit,
  onOpenLastPhoto: () -> Unit,
  onOpenGallery: () -> Unit,
  onCameraAvailabilityChecked: (Boolean, Boolean) -> Unit,
  onCapabilitiesUpdated: (SensorCapabilities) -> Unit,
  onZoomChanged: (Float) -> Unit,
  onFocusTap: (Float, Float, Boolean?) -> Unit,
  onCaptureStarted: () -> Unit,
  onCaptureSucceeded: (Uri, String, Boolean, String?) -> Unit,
  onCaptureFailed: (String) -> Unit,
  onCameraBindError: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val hapticFeedback = LocalHapticFeedback.current
  val coroutineScope = rememberCoroutineScope()

  val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
  var boundCamera by remember { mutableStateOf<Camera?>(null) }
  var boundPreview by remember { mutableStateOf<Preview?>(null) }
  var boundImageCapture by remember { mutableStateOf<ImageCapture?>(null) }
  var boundVideoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
  var activeRecording by remember { mutableStateOf<Recording?>(null) }

  DisposableEffect(Unit) {
    onDispose {
      runCatching { activeRecording?.stop() }
      cameraExecutor.shutdown()
    }
  }

  val previewView =
    remember(context) {
      PreviewView(context).apply {
        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        scaleType = PreviewView.ScaleType.FILL_CENTER
      }
    }

  var extensionsManager by remember { mutableStateOf<ExtensionsManager?>(null) }
  var isModesDetailOpen by remember { mutableStateOf(false) }
  var currentSensorRotation by remember { mutableIntStateOf(Surface.ROTATION_0) }
  var targetIconDegrees by remember { mutableFloatStateOf(0f) }
  var levelRollDegrees by remember { mutableFloatStateOf(0f) }

  val panoramaBitmaps = remember { mutableListOf<Bitmap>() }
  var panoramaCapturingSlice by remember { mutableStateOf(false) }

  val animatedIconRotation by
    animateFloatAsState(
      targetValue = targetIconDegrees,
      animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
      label = "hudIconRotation",
    )

  // Latest values for zero-rebind ImageAnalysis callback
  val latestIsFront by rememberUpdatedState(uiState.lensOption == LensOption.FRONT)
  val latestHistOn by rememberUpdatedState(uiState.manualSettings.isHistogramEnabled)
  val latestZebraOn by rememberUpdatedState(uiState.manualSettings.isZebraEnabled)
  val latestZebraThresh by rememberUpdatedState(uiState.manualSettings.zebraThresholdPercent)
  val latestPeakOn by rememberUpdatedState(uiState.manualSettings.isFocusPeakingEnabled)
  val latestAutoSceneOn by rememberUpdatedState(uiState.photographyMode == PhotographyMode.AUTO_SCENE)
  val latestIsVideoRecording by rememberUpdatedState(uiState.videoRecordingState.isRecording)

  // Physical camera level indicator using device gravity / accelerometer sensor
  DisposableEffect(context, uiState.isLevelEnabled, uiState.deviceInventory.hasLevelSensor) {
    if (!uiState.isLevelEnabled || !uiState.deviceInventory.hasLevelSensor) {
      return@DisposableEffect onDispose {}
    }
    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    val sensor =
      sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
        ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    if (sensorManager == null || sensor == null) {
      return@DisposableEffect onDispose {}
    }

    var filteredAngle = 0f
    var initialized = false
    val listener =
      object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
          val gx = event.values[0]
          val gy = event.values[1]
          val rawAngle = (atan2(gx.toDouble(), gy.toDouble()) * 180.0 / PI).toFloat()
          if (!initialized) {
            filteredAngle = rawAngle
            initialized = true
          } else {
            var diff = rawAngle - filteredAngle
            if (diff > 180f) diff -= 360f
            if (diff < -180f) diff += 360f
            filteredAngle += 0.2f * diff
          }
          levelRollDegrees = filteredAngle
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
      }
    sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
    onDispose { sensorManager.unregisterListener(listener) }
  }

  // Continuous orientation & display listener for accurate EXIF rotation
  DisposableEffect(context, previewView) {
    val orientationListener =
      object : OrientationEventListener(context) {
        override fun onOrientationChanged(orientation: Int) {
          if (orientation == ORIENTATION_UNKNOWN) return
          val rotation =
            when (orientation) {
              in 45 until 135 -> Surface.ROTATION_270
              in 135 until 225 -> Surface.ROTATION_180
              in 225 until 315 -> Surface.ROTATION_90
              else -> Surface.ROTATION_0
            }
          currentSensorRotation = rotation
          boundImageCapture?.targetRotation = rotation
          if (!latestIsVideoRecording) {
            boundVideoCapture?.targetRotation = rotation
          }

          targetIconDegrees =
            when (rotation) {
              Surface.ROTATION_90 -> 90f
              Surface.ROTATION_180 -> 180f
              Surface.ROTATION_270 -> -90f
              else -> 0f
            }
        }
      }
    if (orientationListener.canDetectOrientation()) {
      orientationListener.enable()
    }

    val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    val displayListener =
      object : DisplayManager.DisplayListener {
        override fun onDisplayChanged(displayId: Int) {
          val display = previewView.display ?: return
          if (display.displayId == displayId) {
            boundPreview?.targetRotation = display.rotation
            boundImageCapture?.targetRotation = currentSensorRotation
            if (!latestIsVideoRecording) {
              boundVideoCapture?.targetRotation = currentSensorRotation
            }
          }
        }

        override fun onDisplayAdded(displayId: Int) = Unit

        override fun onDisplayRemoved(displayId: Int) = Unit
      }
    displayManager.registerDisplayListener(displayListener, null)

    onDispose {
      orientationListener.disable()
      displayManager.unregisterDisplayListener(displayListener)
    }
  }

  // Shutter flash animation
  val shutterFlashAlpha = remember { Animatable(0f) }
  LaunchedEffect(uiState.shutterBlinkCounter) {
    if (uiState.shutterBlinkCounter > 0) {
      shutterFlashAlpha.snapTo(0.85f)
      shutterFlashAlpha.animateTo(0f, animationSpec = tween(durationMillis = 180))
    }
  }

  // Dynamic Hardware Discovery + ExtensionsManager probe on entry
  LaunchedEffect(Unit) {
    try {
      val cameraProvider = awaitCameraProvider(context)
      val extMgr = PhotographyModeManager.probeExtensionsManager(context, cameraProvider)
      extensionsManager = extMgr
      val inventory =
        withContext(Dispatchers.Default) {
          DynamicCameraCapabilityManager.scanDeviceHardware(context, cameraProvider)
        }
      onInventoryScanned(inventory)
    } catch (e: Exception) {
      onCameraBindError(
        context.getString(R.string.error_camera_bind_failed, e.localizedMessage ?: "Hardware scan failed")
      )
    }
  }

  val activeExp = uiState.activeHardwareProfile?.exposureAndRaw
  val resolvedOutputFormat =
    when (uiState.manualSettings.captureOutputFormat) {
      CaptureOutputFormat.RAW_DNG ->
        when {
          activeExp?.isRawSupported == true && activeExp.isCameraXRawOnlySupported ->
            CaptureOutputFormat.RAW_DNG
          activeExp?.isRawSupported == true && activeExp.isCameraXRawJpegSupported ->
            CaptureOutputFormat.RAW_PLUS_JPEG
          else -> CaptureOutputFormat.JPEG
        }
      CaptureOutputFormat.RAW_PLUS_JPEG ->
        when {
          activeExp?.isRawSupported == true && activeExp.isCameraXRawJpegSupported ->
            CaptureOutputFormat.RAW_PLUS_JPEG
          activeExp?.isRawSupported == true && activeExp.isCameraXRawOnlySupported ->
            CaptureOutputFormat.RAW_DNG
          else -> CaptureOutputFormat.JPEG
        }
      CaptureOutputFormat.JPEG -> CaptureOutputFormat.JPEG
    }
  val needFrameAnalysis =
    uiState.manualSettings.isHistogramEnabled ||
      uiState.manualSettings.isZebraEnabled ||
      uiState.manualSettings.isFocusPeakingEnabled ||
      uiState.photographyMode == PhotographyMode.AUTO_SCENE

  val activeModeAvailability = uiState.modeCapabilities.availabilityOf(uiState.photographyMode)
  val requestedExtensionMode =
    if (resolvedOutputFormat == CaptureOutputFormat.JPEG && activeModeAvailability.isSupported) {
      activeModeAvailability.extensionMode
    } else {
      ExtensionMode.NONE
    }

  // Re-evaluate 10 mode compatibilities whenever camera sensor, inventory, or ExtensionsManager updates
  LaunchedEffect(uiState.activeHardwareProfile, uiState.deviceInventory, extensionsManager, boundCamera) {
    val profile = uiState.activeHardwareProfile ?: return@LaunchedEffect
    val selector =
      uiState.activeCameraId?.let { DynamicCameraCapabilityManager.buildCameraSelectorForId(it) }
        ?: uiState.lensOption.selector
    val evaluated =
      PhotographyModeManager.evaluateModeCapabilities(
        profile = profile,
        inventory = uiState.deviceInventory,
        selector = selector,
        cameraInfo = boundCamera?.cameraInfo,
        extensionsManager = extensionsManager,
      )
    onModeCapabilitiesEvaluated(evaluated)
  }

  // Bind CameraX for PHOTO mode (Preview + ImageCapture + optional ImageAnalysis)
  // OR for VIDEO mode (Preview + VideoCapture / HighSpeedVideoSessionConfig)
  LaunchedEffect(
    uiState.captureDomain,
    uiState.activeCameraId,
    uiState.lensOption,
    uiState.aspectRatio,
    uiState.captureSpeedMode,
    uiState.photographyMode,
    requestedExtensionMode,
    resolvedOutputFormat,
    needFrameAnalysis,
    uiState.videoSettings.quality,
    uiState.videoSettings.fps,
    uiState.videoSettings.bitrate,
    uiState.videoSettings.isHdrEnabled,
    uiState.videoSettings.stabilization,
    uiState.videoSettings.isSlowMotionBakedIn,
    uiState.isFrontMirrorEnabled,
    lifecycleOwner,
  ) {
    // Never interrupt an active video recording with a camera rebind
    if (activeRecording != null || uiState.videoRecordingState.isRecording) return@LaunchedEffect

    try {
      val cameraProvider = awaitCameraProvider(context)
      val hasBack = cameraProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)
      val hasFront = cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
      onCameraAvailabilityChecked(hasBack, hasFront)

      if (!hasBack && !hasFront && cameraProvider.availableCameraInfos.isEmpty()) {
        onCameraBindError(context.getString(R.string.error_no_camera))
        return@LaunchedEffect
      }

      val baseSelector =
        uiState.activeCameraId?.let { id ->
          val selector = DynamicCameraCapabilityManager.buildCameraSelectorForId(id)
          if (cameraProvider.hasCamera(selector)) selector else null
        }
          ?: when (uiState.lensOption) {
            LensOption.BACK ->
              if (hasBack) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
            LensOption.FRONT ->
              if (hasFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
          }

      val displayRotation = previewView.display?.rotation ?: Surface.ROTATION_0

      if (uiState.captureDomain == AppCaptureDomain.VIDEO) {
        val videoSession =
          VideoCaptureController.bindVideoUseCases(
            lifecycleOwner = lifecycleOwner,
            cameraProvider = cameraProvider,
            selector = baseSelector,
            cameraExecutor = cameraExecutor,
            profile = uiState.activeHardwareProfile,
            previewAspectRatio = uiState.aspectRatio,
            displayRotation = displayRotation,
            sensorRotation = currentSensorRotation,
            mirrorFront = uiState.isFrontMirrorEnabled,
            videoSettings = uiState.videoSettings,
            onLiveTelemetry = onLiveTelemetry,
          )
        videoSession.preview.surfaceProvider = previewView.surfaceProvider
        boundCamera = videoSession.camera
        boundPreview = videoSession.preview
        boundImageCapture = null
        boundVideoCapture = videoSession.videoCapture

        onVideoCapabilitiesUpdated(videoSession.capabilities)
        val activeRes = videoSession.capabilities.availabilityOf(uiState.videoSettings.quality).resolvedSize
        val capabilities =
          CameraCapabilitiesHelper.extractSensorCapabilities(
            camera = videoSession.camera,
            activeCaptureSize = activeRes,
            aspectRatio = PreviewAspectRatio.RATIO_16_9,
          )
        onCapabilitiesUpdated(capabilities)
        VideoCaptureController.applyVideoCamera2Options(
          camera = videoSession.camera,
          profile = uiState.activeHardwareProfile,
          stabilization = uiState.videoSettings.stabilization,
        )
        if (capabilities.hasFlash) {
          videoSession.camera.cameraControl.enableTorch(uiState.videoSettings.isTorchEnabled)
        }
        return@LaunchedEffect
      }

      boundVideoCapture = null

      val extMgr = extensionsManager
      val extensionReadySelector =
        if (
          requestedExtensionMode != ExtensionMode.NONE &&
            extMgr != null &&
            try {
              extMgr.isExtensionAvailable(baseSelector, requestedExtensionMode)
            } catch (_: Exception) {
              false
            }
        ) {
          try {
            extMgr.getExtensionEnabledCameraSelector(baseSelector, requestedExtensionMode)
          } catch (_: Exception) {
            baseSelector
          }
        } else {
          baseSelector
        }

      val previewBuilder =
        Preview.Builder()
          .setResolutionSelector(
            CameraCapabilitiesHelper.buildPreviewResolutionSelector(uiState.aspectRatio)
          )
          .setTargetRotation(displayRotation)
      CameraCapabilitiesHelper.attachLiveTelemetryCallback(previewBuilder, onLiveTelemetry)
      val previewUseCase = previewBuilder.build()

      val captureMode =
        resolveImageCaptureMode(
          speedMode = uiState.captureSpeedMode,
          isZslSupported = uiState.activeHardwareProfile?.isZslSupported == true,
          rawActive = resolvedOutputFormat != CaptureOutputFormat.JPEG,
        )

      val imageCaptureBuilder =
        ImageCapture.Builder()
          .setCaptureMode(captureMode)
          .setJpegQuality(100)
          .setFlashMode(uiState.flashSetting.imageCaptureMode)
          .setResolutionSelector(
            PhotographyModeManager.buildCaptureResolutionSelectorForMode(
              mode = uiState.photographyMode,
              aspectRatio = uiState.aspectRatio,
              profile = uiState.activeHardwareProfile,
            )
          )
          .setTargetRotation(currentSensorRotation)

      when (resolvedOutputFormat) {
        CaptureOutputFormat.RAW_DNG ->
          imageCaptureBuilder.setOutputFormat(ImageCapture.OUTPUT_FORMAT_RAW)
        CaptureOutputFormat.RAW_PLUS_JPEG ->
          imageCaptureBuilder.setOutputFormat(ImageCapture.OUTPUT_FORMAT_RAW_JPEG)
        CaptureOutputFormat.JPEG -> Unit
      }

      val imageCaptureUseCase = imageCaptureBuilder.build()

      // Extensions may restrict concurrent ImageAnalysis on some OEMs
      val allowAnalysisWithMode = requestedExtensionMode == ExtensionMode.NONE
      val imageAnalysisUseCase =
        if (needFrameAnalysis && allowAnalysisWithMode) {
          ImageAnalysis.Builder()
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .apply {
              setAnalyzer(
                cameraExecutor,
                LiveFrameAnalyzer(
                  isFrontCamera = { latestIsFront },
                  isHistogramEnabled = { latestHistOn },
                  isZebraEnabled = { latestZebraOn },
                  zebraThresholdPercent = { latestZebraThresh },
                  isFocusPeakingEnabled = { latestPeakOn },
                  isAutoSceneEnabled = { latestAutoSceneOn },
                  onAnalysisReady = onFrameAnalysis,
                ),
              )
            }
        } else {
          null
        }

      cameraProvider.unbindAll()
      val camera =
        try {
          if (imageAnalysisUseCase != null) {
            try {
              cameraProvider.bindToLifecycle(
                lifecycleOwner,
                extensionReadySelector,
                previewUseCase,
                imageCaptureUseCase,
                imageAnalysisUseCase,
              )
            } catch (_: IllegalArgumentException) {
              cameraProvider.unbindAll()
              cameraProvider.bindToLifecycle(
                lifecycleOwner,
                extensionReadySelector,
                previewUseCase,
                imageCaptureUseCase,
              )
            }
          } else {
            cameraProvider.bindToLifecycle(
              lifecycleOwner,
              extensionReadySelector,
              previewUseCase,
              imageCaptureUseCase,
            )
          }
        } catch (_: IllegalArgumentException) {
          cameraProvider.unbindAll()
          cameraProvider.bindToLifecycle(
            lifecycleOwner,
            baseSelector,
            previewUseCase,
            imageCaptureUseCase,
          )
        }

      previewUseCase.surfaceProvider = previewView.surfaceProvider
      boundCamera = camera
      boundPreview = previewUseCase
      boundImageCapture = imageCaptureUseCase

      val activeRes = imageCaptureUseCase.resolutionInfo?.resolution
      val capabilities =
        CameraCapabilitiesHelper.extractSensorCapabilities(
          camera = camera,
          activeCaptureSize = activeRes,
          aspectRatio = uiState.aspectRatio,
        )
      onCapabilitiesUpdated(capabilities)
    } catch (e: Exception) {
      onCameraBindError(
        context.getString(R.string.error_camera_bind_failed, e.localizedMessage ?: "Unknown error")
      )
    }
  }

  // Update flash mode without rebinding (Photo Mode)
  LaunchedEffect(uiState.flashSetting, boundImageCapture) {
    boundImageCapture?.flashMode = uiState.flashSetting.imageCaptureMode
  }

  // Update Video Torch continuously without rebinding (Video Mode)
  LaunchedEffect(uiState.captureDomain, uiState.videoSettings.isTorchEnabled, boundCamera) {
    val cam = boundCamera ?: return@LaunchedEffect
    if (uiState.captureDomain == AppCaptureDomain.VIDEO && cam.cameraInfo.hasFlashUnit()) {
      cam.cameraControl.enableTorch(uiState.videoSettings.isTorchEnabled)
    }
  }

  // Apply manual Pro parameters AND active mode hardware pipeline controls
  LaunchedEffect(
    boundCamera,
    uiState.captureDomain,
    uiState.activeHardwareProfile,
    uiState.manualSettings,
    uiState.photographyMode,
    uiState.modeCapabilities,
    uiState.detectedAutoScene,
    uiState.videoSettings.stabilization,
  ) {
    val cam = boundCamera ?: return@LaunchedEffect
    if (uiState.captureDomain == AppCaptureDomain.VIDEO) {
      VideoCaptureController.applyVideoCamera2Options(
        camera = cam,
        profile = uiState.activeHardwareProfile,
        stabilization = uiState.videoSettings.stabilization,
      )
      return@LaunchedEffect
    }
    CameraCapabilitiesHelper.applyManualCaptureOptions(
      camera = cam,
      profile = uiState.activeHardwareProfile,
      manual = uiState.manualSettings,
      liveTelemetry = uiState.liveTelemetry,
    )
    PhotographyModeManager.applyModeHardwareOptions(
      camera = cam,
      mode = uiState.photographyMode,
      modeCapabilities = uiState.modeCapabilities,
      profile = uiState.activeHardwareProfile,
      manual = uiState.manualSettings,
      liveTelemetry = uiState.liveTelemetry,
      detectedScene = uiState.detectedAutoScene,
    )
  }

  val finishAndStitchPanorama: () -> Unit = {
    val frames = panoramaBitmaps.toList()
    panoramaBitmaps.clear()
    if (frames.size < 2) {
      frames.forEach { it.recycle() }
      onResetPanorama()
      onCaptureFailed("Panorama requires at least 2 overlapping frames.")
    } else {
      onPanoramaProgress(false, frames.size, uiState.panoramaState.currentYawDeg, uiState.panoramaState.pitchTiltDeg, true, context.getString(R.string.pano_stitching_status))
      onCaptureStarted()
      coroutineScope.launch {
        val stitched =
          withContext(Dispatchers.Default) {
            try {
              PanoramaStitcher.stitchAndSaveToMediaStore(context, frames)
            } finally {
              frames.forEach { it.recycle() }
            }
          }
        onResetPanorama()
        if (stitched != null) {
          onCaptureSucceeded(
            stitched.uri,
            stitched.displayName,
            false,
            "Panorama ${stitched.width}×${stitched.height} (${stitched.stitchedFrames} frames)",
          )
        } else {
          onCaptureFailed("Panorama alignment failed — sweep smoothly right with ~30% overlap")
        }
      }
    }
  }

  val cancelPanoramaSweep: () -> Unit = {
    panoramaBitmaps.forEach { it.recycle() }
    panoramaBitmaps.clear()
    onResetPanorama()
  }

  // Real gyroscope / rotation-vector sweep tracking when in Panorama mode
  DisposableEffect(
    context,
    uiState.photographyMode,
    uiState.panoramaState.isActive,
    uiState.panoramaState.isStitching,
  ) {
    if (uiState.photographyMode != PhotographyMode.PANORAMA) {
      if (panoramaBitmaps.isNotEmpty()) {
        panoramaBitmaps.forEach { it.recycle() }
        panoramaBitmaps.clear()
      }
      return@DisposableEffect onDispose {}
    }

    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    val rotSensor =
      sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        ?: sensorManager?.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
        ?: sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    if (sensorManager == null || rotSensor == null) {
      return@DisposableEffect onDispose {}
    }

    var baseAzimuthDeg: Float? = null
    var lastTimestampNs = 0L
    var accumGyroYawDeg = 0f
    var nextCaptureStep = 1
    val rotMatrix = FloatArray(9)
    val orientationVals = FloatArray(3)

    val listener =
      object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
          val yawDeg: Float
          val tiltDeg: Float
          if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            if (lastTimestampNs != 0L) {
              val dt = (event.timestamp - lastTimestampNs) / 1_000_000_000f
              accumGyroYawDeg += abs(event.values[1] * (180f / PI.toFloat()) * dt)
            }
            lastTimestampNs = event.timestamp
            yawDeg = accumGyroYawDeg
            tiltDeg = 0f
          } else {
            SensorManager.getRotationMatrixFromVector(rotMatrix, event.values)
            SensorManager.getOrientation(rotMatrix, orientationVals)
            val azimuthDeg = (orientationVals[0] * 180.0 / PI).toFloat()
            val pitchDeg = (orientationVals[2] * 180.0 / PI).toFloat()
            if (baseAzimuthDeg == null) baseAzimuthDeg = azimuthDeg
            var delta = azimuthDeg - (baseAzimuthDeg ?: azimuthDeg)
            if (delta > 180f) delta -= 360f
            if (delta < -180f) delta += 360f
            yawDeg = abs(delta)
            tiltDeg = (pitchDeg + 90f).coerceIn(-15f, 15f)
          }

          onPanoramaMotion(yawDeg, tiltDeg)

          val panoState = uiState.panoramaState
          if (
            panoState.isActive &&
              !panoState.isStitching &&
              !panoramaCapturingSlice &&
              panoramaBitmaps.size < panoState.maxSlices &&
              yawDeg >= nextCaptureStep * panoState.targetStepDeg
          ) {
            val captureUseCase = boundImageCapture ?: return
            nextCaptureStep++
            panoramaCapturingSlice = true
            coroutineScope.launch {
              captureUseCase.targetRotation = currentSensorRotation
              val cap = ModeCaptureExecutor.captureInMemoryJpeg(captureUseCase, cameraExecutor)
              cap.onSuccess { (bytes, rot) ->
                val bmp =
                  withContext(Dispatchers.Default) {
                    PanoramaStitcher.decodeScaledFrame(
                      jpegBytes = bytes,
                      rotationDegrees = rot,
                      mirrorHorizontal =
                        uiState.lensOption == LensOption.FRONT && uiState.isFrontMirrorEnabled,
                    )
                  }
                if (bmp != null) {
                  panoramaBitmaps.add(bmp)
                  hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                  val count = panoramaBitmaps.size
                  onPanoramaProgress(
                    true,
                    count,
                    yawDeg,
                    tiltDeg,
                    false,
                    if (count >= panoState.maxSlices) "Max frames reached — stitching…"
                    else context.getString(R.string.pano_keep_level_hint),
                  )
                  if (count >= panoState.maxSlices) {
                    finishAndStitchPanorama()
                  }
                }
              }
              panoramaCapturingSlice = false
            }
          }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
      }
    sensorManager.registerListener(listener, rotSensor, SensorManager.SENSOR_DELAY_GAME)
    onDispose { sensorManager.unregisterListener(listener) }
  }

  val executeCaptureNow: () -> Unit = {
    val imageCapture = boundImageCapture
    if (imageCapture != null && !uiState.isCapturing) {
      val isFrontCamera = uiState.lensOption == LensOption.FRONT
      val mirrorFront = uiState.isFrontMirrorEnabled
      val aspectRatio = uiState.aspectRatio
      val mode = uiState.photographyMode
      val modeCaps = uiState.modeCapabilities

      if (mode == PhotographyMode.PANORAMA) {
        if (uiState.panoramaState.isActive) {
          if (panoramaBitmaps.size >= 2) {
            finishAndStitchPanorama()
          } else {
            cancelPanoramaSweep()
          }
        } else if (!panoramaCapturingSlice) {
          panoramaCapturingSlice = true
          coroutineScope.launch {
            imageCapture.targetRotation = currentSensorRotation
            hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
            val firstCap = ModeCaptureExecutor.captureInMemoryJpeg(imageCapture, cameraExecutor)
            firstCap.fold(
              onSuccess = { (bytes, rot) ->
                val bmp =
                  withContext(Dispatchers.Default) {
                    PanoramaStitcher.decodeScaledFrame(bytes, rot, isFrontCamera && mirrorFront)
                  }
                if (bmp != null) {
                  panoramaBitmaps.clear()
                  panoramaBitmaps.add(bmp)
                  onPanoramaProgress(
                    true,
                    1,
                    0f,
                    0f,
                    false,
                    context.getString(R.string.pano_keep_level_hint),
                  )
                } else {
                  onCaptureFailed("Unable to decode initial panorama frame")
                }
              },
              onFailure = { err ->
                onCaptureFailed(err.localizedMessage ?: "Panorama start failed")
              },
            )
            panoramaCapturingSlice = false
          }
        }
      } else {
        val rawActive = resolvedOutputFormat != CaptureOutputFormat.JPEG
        val burstEnabled =
          mode == PhotographyMode.STANDARD &&
            uiState.isBurstModeEnabled &&
            uiState.activeHardwareProfile?.isBurstSupported == true &&
            !rawActive

        coroutineScope.launch {
          imageCapture.targetRotation = currentSensorRotation
          onCaptureStarted()

          if (burstEnabled) {
            val totalShots = 5
            var savedCount = 0
            var lastResult: SavedCaptureResult? = null
            var lastError: String? = null

            for (shot in 1..totalShots) {
              onBurstProgress(shot)
              hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
              val result =
                ModeCaptureExecutor.executeStandardSingleCapture(
                  context = context,
                  imageCapture = imageCapture,
                  cameraExecutor = cameraExecutor,
                  isFrontCamera = isFrontCamera,
                  mirrorFrontCamera = mirrorFront,
                  aspectRatio = aspectRatio,
                  outputFormat = CaptureOutputFormat.JPEG,
                )
              result.fold(
                onSuccess = {
                  savedCount++
                  lastResult = it
                },
                onFailure = { err ->
                  lastError = err.localizedMessage ?: "Burst capture failed"
                },
              )
            }

            val finalShot = lastResult
            if (finalShot != null) {
              onCaptureSucceeded(
                finalShot.uri,
                finalShot.displayName,
                false,
                "Burst: $savedCount/$totalShots saved",
              )
            } else {
              onCaptureFailed(lastError ?: context.getString(R.string.error_capture_failed, "Burst failed"))
            }
          } else {
            hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
            val result =
              ModeCaptureExecutor.executeCaptureForMode(
                context = context,
                imageCapture = imageCapture,
                cameraExecutor = cameraExecutor,
                photographyMode = mode,
                modeCapabilities = modeCaps,
                isFrontCamera = isFrontCamera,
                mirrorFrontCamera = mirrorFront,
                aspectRatio = aspectRatio,
                outputFormat = resolvedOutputFormat,
              )
            result.fold(
              onSuccess = { saved ->
                val summary =
                  if (mode != PhotographyMode.STANDARD && !saved.rawSaved) {
                    "${mode.label} saved · ${saved.displayName}"
                  } else {
                    null
                  }
                onCaptureSucceeded(saved.uri, saved.displayName, saved.rawSaved, summary)
              },
              onFailure = { err ->
                onCaptureFailed(
                  context.getString(
                    R.string.error_capture_failed,
                    err.localizedMessage ?: "Capture failed",
                  )
                )
              },
            )
          }
        }
      }
    }
  }

  val startVideoRecordingNow: (Boolean) -> Unit = { withAudio ->
    val videoCapture = boundVideoCapture
    if (videoCapture != null && activeRecording == null && !uiState.videoRecordingState.isRecording) {
      hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
      val activeFps = uiState.videoSettings.fps.fps
      val activeHdr =
        !uiState.videoSettings.fps.isHighSpeed &&
          uiState.videoSettings.isHdrEnabled &&
          uiState.videoCapabilities.hdrAvailability.isSupported
      val rec =
        VideoCaptureController.startVideoRecording(
          context = context,
          videoCapture = videoCapture,
          withAudio = withAudio,
          sensorRotation = currentSensorRotation,
          onStarted = { onVideoRecordingStarted(withAudio) },
          onPaused = onVideoRecordingPaused,
          onResumed = onVideoRecordingResumed,
          onStatus = onVideoRecordingStatus,
          onFinalizedSuccess = { uri, name, durationMs ->
            activeRecording = null
            onVideoRecordingSaved(uri, name, durationMs, activeFps, activeHdr)
          },
          onFinalizedError = { msg ->
            activeRecording = null
            onVideoRecordingFailed(msg)
          },
        )
      activeRecording = rec
    }
  }

  val audioPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
      if (isGranted) {
        onUpdateAudioPermissionStatus(AudioPermissionStatus.GRANTED, false)
        onStartCountdown(
          { hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove) },
          { startVideoRecordingNow(true) },
        )
      } else {
        val activity = context as? Activity
        val canAskAgain =
          activity != null &&
            ActivityCompat.shouldShowRequestPermissionRationale(
              activity,
              Manifest.permission.RECORD_AUDIO,
            )
        onUpdateAudioPermissionStatus(
          if (canAskAgain) AudioPermissionStatus.DENIED
          else AudioPermissionStatus.PERMANENTLY_DENIED,
          false,
        )
        onVideoRecordingFailed(context.getString(R.string.mic_permission_needed_banner))
      }
    }

  val triggerVideoRecordOrStop by
    rememberUpdatedState<() -> Unit> {
      val recState = uiState.videoRecordingState
      when {
        recState.isRecording -> {
          hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
          onVideoRecordingFinalizing()
          activeRecording?.stop()
        }
        uiState.countdownRemainingSeconds != null -> {
          onCancelCountdown()
        }
        boundVideoCapture != null && !recState.isFinalizing -> {
          if (!uiState.videoSettings.isAudioEnabled) {
            onStartCountdown(
              { hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove) },
              { startVideoRecordingNow(false) },
            )
          } else {
            val hasMic =
              ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            if (hasMic) {
              onUpdateAudioPermissionStatus(AudioPermissionStatus.GRANTED, false)
              onStartCountdown(
                { hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove) },
                { startVideoRecordingNow(true) },
              )
            } else {
              onUpdateAudioPermissionStatus(AudioPermissionStatus.NOT_REQUESTED, true)
              audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
          }
        }
      }
    }

  val toggleVideoPauseResume: () -> Unit = {
    val rec = activeRecording
    if (rec != null && uiState.videoRecordingState.canPauseOrResume) {
      hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      if (uiState.videoRecordingState.isPaused) {
        runCatching { rec.resume() }
      } else {
        runCatching { rec.pause() }
      }
    }
  }

  val triggerShutterOrCancel by
    rememberUpdatedState<() -> Unit> {
      if (uiState.captureDomain == AppCaptureDomain.VIDEO) {
        triggerVideoRecordOrStop()
      } else if (uiState.countdownRemainingSeconds != null) {
        onCancelCountdown()
      } else if (boundImageCapture != null && !uiState.isCapturing) {
        onStartCountdown(
          { hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove) },
          executeCaptureNow,
        )
      }
    }

  // Listen for hardware Volume Up / Down shutter presses
  LaunchedEffect(volumeShutterEvents) {
    volumeShutterEvents.collect {
      triggerShutterOrCancel()
    }
  }

  val currentFacingInt =
    if (uiState.lensOption == LensOption.FRONT) CameraMetadata.LENS_FACING_FRONT
    else CameraMetadata.LENS_FACING_BACK
  val sameFacingCameras =
    remember(uiState.deviceInventory, currentFacingInt) {
      uiState.deviceInventory.selectableForFacing(currentFacingInt)
    }

  val hasAnyManualActive =
    uiState.manualSettings.isManualIsoEnabled ||
      uiState.manualSettings.isManualShutterEnabled ||
      uiState.manualSettings.whiteBalanceMode != WhiteBalanceOption.AUTO ||
      uiState.manualSettings.isManualFocusEnabled ||
      uiState.manualSettings.isExposureLockEnabled ||
      uiState.manualSettings.isRawCaptureEnabled ||
      uiState.manualSettings.isFocusPeakingEnabled ||
      uiState.manualSettings.isHistogramEnabled ||
      uiState.manualSettings.isZebraEnabled ||
      uiState.sensorCapabilities.currentExposureIndex != 0

  val supportsZoom =
    uiState.sensorCapabilities.maxZoomRatio > uiState.sensorCapabilities.minZoomRatio + 0.01f

  val applyEvIndex: (Int) -> Unit = { idx ->
    boundCamera?.cameraControl?.setExposureCompensationIndex(idx)
    onExposureCompChanged(idx)
  }

  BoxWithConstraints(
    modifier = modifier.fillMaxSize().background(ObsidianBlack)
  ) {
    val isLandscapeWide = maxWidth >= 600.dp && maxWidth > maxHeight
    val isPortraitWindow = maxHeight >= maxWidth
    val effectiveAspectRatio =
      if (uiState.captureDomain == AppCaptureDomain.VIDEO && uiState.aspectRatio != PreviewAspectRatio.FULL) {
        PreviewAspectRatio.RATIO_16_9
      } else {
        uiState.aspectRatio
      }

    val targetFrameAspect =
      when (effectiveAspectRatio) {
        PreviewAspectRatio.RATIO_4_3 -> if (isPortraitWindow) 3f / 4f else 4f / 3f
        PreviewAspectRatio.RATIO_16_9 -> if (isPortraitWindow) 9f / 16f else 16f / 9f
        PreviewAspectRatio.RATIO_1_1 -> 1f
        PreviewAspectRatio.FULL -> null
      }

    val stageWidth = if (isLandscapeWide) maxWidth - 132.dp else maxWidth
    val stageHeight = maxHeight

    val (frameWidth, frameHeight) =
      if (targetFrameAspect == null) {
        stageWidth to stageHeight
      } else {
        val candidateW = min(stageWidth, stageHeight * targetFrameAspect)
        val candidateH = candidateW / targetFrameAspect
        candidateW to candidateH
      }

    val animatedFrameWidth by
      animateDpAsState(
        targetValue = frameWidth,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "frameWidth",
      )
    val animatedFrameHeight by
      animateDpAsState(
        targetValue = frameHeight,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "frameHeight",
      )

    // Viewfinder Stage
    Box(
      contentAlignment = Alignment.Center,
      modifier =
        Modifier.then(
          if (isLandscapeWide) Modifier.fillMaxHeight().width(stageWidth).align(Alignment.CenterStart)
          else Modifier.fillMaxSize()
        ),
    ) {
      val cornerRadius = if (uiState.aspectRatio == PreviewAspectRatio.FULL) 0.dp else 18.dp
      Box(
        modifier =
          Modifier.size(width = animatedFrameWidth, height = animatedFrameHeight)
            .clip(RoundedCornerShape(cornerRadius))
            .background(ObsidianBlack)
            .pointerInput(
              boundCamera,
              previewView,
              uiState.manualSettings.isManualFocusEnabled,
              uiState.activeHardwareProfile,
            ) {
              detectTapGestures { offset ->
                val camera = boundCamera ?: return@detectTapGestures
                if (uiState.manualSettings.isManualFocusEnabled) return@detectTapGestures
                onFocusTap(offset.x, offset.y, null)
                val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                val afSupported =
                  uiState.activeHardwareProfile?.focusCapabilities?.isAutoFocusSupported != false
                val meteringFlags =
                  if (afSupported) {
                    FocusMeteringAction.FLAG_AF or
                      FocusMeteringAction.FLAG_AE or
                      FocusMeteringAction.FLAG_AWB
                  } else {
                    FocusMeteringAction.FLAG_AE or FocusMeteringAction.FLAG_AWB
                  }
                val action =
                  FocusMeteringAction.Builder(point, meteringFlags)
                    .setAutoCancelDuration(4, TimeUnit.SECONDS)
                    .build()
                val future = camera.cameraControl.startFocusAndMetering(action)
                future.addListener(
                  {
                    val success =
                      try {
                        future.get().isFocusSuccessful
                      } catch (_: Exception) {
                        false
                      }
                    onFocusTap(offset.x, offset.y, success)
                  },
                  ContextCompat.getMainExecutor(context),
                )
              }
            }
            .pointerInput(boundCamera, uiState.sensorCapabilities) {
              detectTransformGestures { _, _, zoom, _ ->
                val camera = boundCamera ?: return@detectTransformGestures
                val minZ = uiState.sensorCapabilities.minZoomRatio
                val maxZ = uiState.sensorCapabilities.maxZoomRatio
                if (maxZ > minZ + 0.01f) {
                  val currentZ = camera.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                  val nextZ = (currentZ * zoom).coerceIn(minZ, maxZ)
                  camera.cameraControl.setZoomRatio(nextZ)
                  onZoomChanged(nextZ)
                }
              }
            }
      ) {
        AndroidView(
          factory = { previewView },
          modifier = Modifier.fillMaxSize(),
        )

        val analysis = uiState.frameAnalysis
        if (uiState.manualSettings.isZebraEnabled && analysis != null) {
          ZebraExposureOverlay(
            highlightPoints = analysis.zebraHighlightPoints,
            shadowPoints = analysis.zebraShadowPoints,
          )
        }

        if (uiState.manualSettings.isFocusPeakingEnabled && analysis != null) {
          FocusPeakingOverlay(
            points = analysis.focusPeakingPoints,
            peakingColor = uiState.manualSettings.focusPeakingColor,
          )
        }

        if (uiState.isGridEnabled) {
          RuleOfThirdsGrid()
        }

        if (uiState.isLevelEnabled && uiState.deviceInventory.hasLevelSensor) {
          CameraLevelOverlay(rollDegrees = levelRollDegrees)
        }

        FocusReticleOverlay(focusPoint = uiState.focusPoint)

        TimerCountdownOverlay(remainingSeconds = uiState.countdownRemainingSeconds)

        if (shutterFlashAlpha.value > 0.01f) {
          Box(
            modifier =
              Modifier.fillMaxSize()
                .background(ObsidianBlack.copy(alpha = shutterFlashAlpha.value))
          )
        }
      }
    }

    // Top Telemetry, DSLR Exposure Info Bar & Settings Overlay
    Column(
      modifier =
        Modifier.then(
            if (isLandscapeWide) Modifier.width(stageWidth).align(Alignment.TopStart)
            else Modifier.fillMaxWidth().align(Alignment.TopCenter)
          )
          .background(
            Brush.verticalGradient(
              colors = listOf(ObsidianBlack.copy(alpha = 0.78f), Color.Transparent)
            )
          )
          .statusBarsPadding()
          .padding(horizontal = 14.dp, vertical = 10.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        if (uiState.captureDomain == AppCaptureDomain.VIDEO) {
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            if (uiState.sensorCapabilities.hasFlash) {
              VideoTorchButton(
                isTorchEnabled = uiState.videoSettings.isTorchEnabled,
                iconRotation = animatedIconRotation,
                onClick = onToggleVideoTorch,
              )
            }
            TimerToggleButton(
              shutterTimer = uiState.shutterTimer,
              iconRotation = animatedIconRotation,
              onClick = onCycleTimer,
            )
            VideoAudioToggleButton(
              isAudioEnabled = uiState.videoSettings.isAudioEnabled,
              isRecording = uiState.videoRecordingState.isRecording,
              iconRotation = animatedIconRotation,
              onClick = onToggleVideoAudio,
            )
          }

          VideoQuickSpecPill(
            settings = uiState.videoSettings,
            capabilities = uiState.videoCapabilities,
            isSettingsOpen = uiState.isVideoSettingsOpen,
            enabled = !uiState.videoRecordingState.isRecording,
            onClick = onToggleVideoSettings,
          )
        } else {
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            if (uiState.sensorCapabilities.hasFlash) {
              FlashToggleButton(
                flashSetting = uiState.flashSetting,
                iconRotation = animatedIconRotation,
                onClick = onCycleFlash,
              )
            }

            TimerToggleButton(
              shutterTimer = uiState.shutterTimer,
              iconRotation = animatedIconRotation,
              onClick = onCycleTimer,
            )
          }

          AspectRatioSelectorPill(
            selected = uiState.aspectRatio,
            onSelect = onSelectAspectRatio,
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        val profile = uiState.activeHardwareProfile
        val res = uiState.sensorCapabilities.displayedResolution
        val resLabel =
          if (uiState.captureDomain == AppCaptureDomain.VIDEO) {
            val vSize = uiState.videoCapabilities.availabilityOf(uiState.videoSettings.quality).resolvedSize
            if (vSize != null) "${vSize.width}×${vSize.height} @${uiState.videoSettings.fps.fps}"
            else "${uiState.videoSettings.quality.shortLabel} @${uiState.videoSettings.fps.fps}fps"
          } else if (res != null) {
            val mp = uiState.sensorCapabilities.megapixels ?: 0.0
            String.format(Locale.US, "%d×%d (%.1fMP)", res.width, res.height, mp)
          } else {
            "NATIVE SENSOR"
          }
        val lensTag =
          if (profile != null) {
            "${profile.facingLabel.uppercase(Locale.US)} ${profile.role.shortTag}"
          } else {
            uiState.lensOption.label
          }

        SensorTelemetryPill(
          resolutionText = resLabel,
          lensLabel = lensTag,
          onClick = onOpenHardwareInspector,
        )

        if (uiState.captureDomain == AppCaptureDomain.PHOTO) {
          if (uiState.activeHardwareProfile?.isBurstSupported == true && resolvedOutputFormat == CaptureOutputFormat.JPEG) {
            BurstModePill(
              isEnabled = uiState.isBurstModeEnabled,
              onClick = onToggleBurstMode,
            )
          }

          QuickCapturePill(
            mode = uiState.captureSpeedMode,
            onClick = onToggleQuickCapture,
          )

          ProToggleButton(
            isOpen = uiState.manualSettings.isProPanelOpen,
            hasAnyManualActive = hasAnyManualActive,
            onClick = onToggleProPanel,
          )
        }

        HardwareInspectorButton(
          onClick = onOpenHardwareInspector,
        )
      }

      // Live Recording Duration Counter + Audio Meter HUD
      AnimatedVisibility(
        visible =
          uiState.captureDomain == AppCaptureDomain.VIDEO &&
            (uiState.videoRecordingState.isRecording || uiState.videoRecordingState.isFinalizing),
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
      ) {
        VideoRecordingStatusHud(
          recordingState = uiState.videoRecordingState,
          videoSettings = uiState.videoSettings,
          modifier = Modifier.padding(top = 8.dp),
        )
      }

      // Quick Silent Video fallback chip if mic permission was denied
      if (
        uiState.captureDomain == AppCaptureDomain.VIDEO &&
          uiState.videoSettings.isAudioEnabled &&
          (uiState.videoRecordingState.audioPermissionStatus == AudioPermissionStatus.DENIED ||
            uiState.videoRecordingState.audioPermissionStatus == AudioPermissionStatus.PERMANENTLY_DENIED) &&
          !uiState.videoRecordingState.isRecording
      ) {
        Surface(
          onClick = onEnableSilentVideo,
          shape = CircleShape,
          color = ProAmber.copy(alpha = 0.22f),
          border = BorderStroke(1.dp, ProAmber.copy(alpha = 0.65f)),
          modifier = Modifier.padding(top = 8.dp).testTag("silent_video_fallback_chip"),
        ) {
          Text(
            text = "Record Silent Video Instead",
            style = MaterialTheme.typography.labelMedium,
            color = ProAmber,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          )
        }
      }

      // DSLR Live Exposure Info Bar (Photo Pro Mode only)
      AnimatedVisibility(
        visible =
          uiState.captureDomain == AppCaptureDomain.PHOTO &&
            (uiState.manualSettings.isProPanelOpen || hasAnyManualActive),
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
      ) {
        ProExposureInfoBar(
          profile = uiState.activeHardwareProfile,
          sensorCapabilities = uiState.sensorCapabilities,
          manualSettings = uiState.manualSettings,
          liveTelemetry = uiState.liveTelemetry,
          onSelectProTab = { tab ->
            if (!uiState.manualSettings.isProPanelOpen) onToggleProPanel()
            onSelectProTab(tab)
          },
          modifier = Modifier.padding(top = 8.dp),
        )
      }

      // Live Histogram floating strip below Top HUD
      if (uiState.captureDomain == AppCaptureDomain.PHOTO && uiState.manualSettings.isHistogramEnabled) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
          horizontalArrangement = Arrangement.End,
        ) {
          LiveHistogramCard(
            analysis = uiState.frameAnalysis,
            zebraThresholdPercent = uiState.manualSettings.zebraThresholdPercent,
          )
        }
      }

      // Feedback toast / error banner
      AnimatedVisibility(
        visible = uiState.statusBanner != null || uiState.errorMessage != null || uiState.isCapturing,
        enter = fadeIn(),
        exit = fadeOut(),
      ) {
        val isError = uiState.errorMessage != null
        val bannerText =
          when {
            uiState.errorMessage != null -> uiState.errorMessage
            uiState.burstProgressCount != null -> "BURST ${uiState.burstProgressCount}/5…"
            uiState.isCapturing -> stringResource(R.string.status_capturing)
            uiState.statusBanner != null -> uiState.statusBanner
            else -> ""
          }
        Surface(
          shape = CircleShape,
          color =
            when {
              isError -> ErrorCoral.copy(alpha = 0.18f)
              uiState.isCapturing -> ObsidianGlass
              else -> CaptureEmerald.copy(alpha = 0.18f)
            },
          border =
            BorderStroke(
              1.dp,
              when {
                isError -> ErrorCoral.copy(alpha = 0.5f)
                uiState.isCapturing -> HairlineLight
                else -> CaptureEmerald.copy(alpha = 0.5f)
              },
            ),
          modifier = Modifier.padding(top = 8.dp),
        ) {
          Text(
            text = bannerText,
            style = MaterialTheme.typography.labelMedium,
            color = TitaniumWhite,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          )
        }
      }
    }

    // Bottom Control Deck (Portrait / Compact) OR Right Control Rail (Landscape Wide)
    if (isLandscapeWide) {
      Column(
        modifier =
          Modifier.width(132.dp)
            .fillMaxHeight()
            .align(Alignment.CenterEnd)
            .background(ObsidianBlack.copy(alpha = 0.82f))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(vertical = 20.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        SwitchCameraButton(
          enabled =
            uiState.hasBackCamera &&
              uiState.hasFrontCamera &&
              !uiState.videoRecordingState.isRecording,
          iconRotation = animatedIconRotation,
          onClick = onSwitchCamera,
        )

        if (uiState.captureDomain == AppCaptureDomain.VIDEO) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            VideoRecordButton(
              isRecording = uiState.videoRecordingState.isRecording,
              isPaused = uiState.videoRecordingState.isPaused,
              isFinalizing = uiState.videoRecordingState.isFinalizing,
              isCountingDown = uiState.countdownRemainingSeconds != null,
              enabled = boundVideoCapture != null,
              onClick = triggerVideoRecordOrStop,
            )
            if (uiState.videoRecordingState.canPauseOrResume) {
              VideoPauseResumeButton(
                isPaused = uiState.videoRecordingState.isPaused,
                enabled = uiState.videoRecordingState.canPauseOrResume,
                onClick = toggleVideoPauseResume,
              )
            }
          }
        } else {
          ShutterButton(
            isCapturing = uiState.isCapturing,
            isCountingDown = uiState.countdownRemainingSeconds != null,
            burstProgressCount = uiState.burstProgressCount,
            isBurstMode = uiState.isBurstModeEnabled,
            enabled = boundImageCapture != null,
            onClick = triggerShutterOrCancel,
          )
        }

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          LastPhotoThumbnailButton(
            lastPhoto = uiState.lastCapturedPhoto,
            iconRotation = animatedIconRotation,
            onClick = {
              if (uiState.lastCapturedPhoto != null) onOpenLastPhoto() else onOpenGallery()
            },
          )
          if (uiState.lastCapturedPhoto != null) {
            GalleryIconButton(
              iconRotation = animatedIconRotation,
              onClick = onOpenGallery,
            )
          }
        }
      }

      if (uiState.captureDomain == AppCaptureDomain.PHOTO && uiState.manualSettings.isProPanelOpen) {
        Box(
          modifier =
            Modifier.width(stageWidth)
              .align(Alignment.BottomStart)
              .navigationBarsPadding()
              .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
          ProControlsPanel(
            profile = uiState.activeHardwareProfile,
            sensorCapabilities = uiState.sensorCapabilities,
            settings = uiState.manualSettings,
            liveTelemetry = uiState.liveTelemetry,
            customPresets = uiState.customPresets,
            hasLevelSensor = uiState.deviceInventory.hasLevelSensor,
            isFrontCamera = uiState.lensOption == LensOption.FRONT,
            isGridEnabled = uiState.isGridEnabled,
            isLevelEnabled = uiState.isLevelEnabled,
            isFrontMirrorEnabled = uiState.isFrontMirrorEnabled,
            isVolumeShutterEnabled = uiState.isVolumeShutterEnabled,
            onSelectProTab = onSelectProTab,
            onSetManualIso = onSetManualIso,
            onSetManualShutter = onSetManualShutter,
            onSetWhiteBalance = onSetWhiteBalance,
            onSetManualKelvin = onSetManualKelvin,
            onSetManualFocus = onSetManualFocus,
            onExposureCompChange = applyEvIndex,
            onSelectCaptureFormat = onSelectCaptureFormat,
            onToggleExposureLock = onToggleExposureLock,
            onSelectStabilization = onSelectStabilization,
            onToggleFocusPeaking = onToggleFocusPeaking,
            onCycleFocusPeakingColor = onCycleFocusPeakingColor,
            onToggleHistogram = onToggleHistogram,
            onToggleZebra = onToggleZebra,
            onSetZebraThreshold = onSetZebraThreshold,
            onToggleGrid = onToggleGrid,
            onToggleLevel = onToggleLevel,
            onToggleFrontMirror = onToggleFrontMirror,
            onToggleVolumeShutter = onToggleVolumeShutter,
            onSavePreset = onSavePreset,
            onApplyPreset = { preset -> onApplyPreset(preset, applyEvIndex) },
            onDeletePreset = onDeletePreset,
            onResetAllToAuto = { onResetAllToAuto(applyEvIndex) },
            modifier = Modifier.widthIn(max = 560.dp).heightIn(max = 280.dp),
          )
        }
      } else {
        Column(
          modifier =
            Modifier.width(stageWidth)
              .align(Alignment.BottomStart)
              .navigationBarsPadding()
              .padding(horizontal = 16.dp, vertical = 14.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          if (
            uiState.captureDomain == AppCaptureDomain.VIDEO &&
              uiState.isVideoSettingsOpen &&
              !uiState.videoRecordingState.isRecording
          ) {
            VideoSettingsDeck(
              settings = uiState.videoSettings,
              capabilities = uiState.videoCapabilities,
              sensorCapabilities = uiState.sensorCapabilities,
              onSelectQuality = onSelectVideoQuality,
              onSelectFps = onSelectVideoFps,
              onSelectBitrate = onSelectVideoBitrate,
              onToggleHdr = onToggleVideoHdr,
              onSelectStabilization = onSelectVideoStabilization,
              onToggleAudio = onToggleVideoAudio,
              onToggleSlowMoBaked = onToggleSlowMoBaked,
              onExposureCompChange = applyEvIndex,
              modifier = Modifier.widthIn(max = 560.dp).heightIn(max = 270.dp),
            )
          }

          if (supportsZoom) {
            ZoomSliderBar(
              currentZoom = uiState.sensorCapabilities.currentZoomRatio,
              minZoom = uiState.sensorCapabilities.minZoomRatio,
              maxZoom = uiState.sensorCapabilities.maxZoomRatio,
              onZoomChange = { z ->
                boundCamera?.cameraControl?.setZoomRatio(z)
                onZoomChanged(z)
              },
              modifier = Modifier.widthIn(max = 360.dp).fillMaxWidth(),
            )
          }
          if (!uiState.videoRecordingState.isRecording) {
            DynamicLensSelectorBar(
              activeProfile = uiState.activeHardwareProfile,
              sameFacingSelectableCameras = sameFacingCameras,
              currentZoomRatio = uiState.sensorCapabilities.currentZoomRatio,
              maxZoomRatio = uiState.sensorCapabilities.maxZoomRatio,
              onSelectCameraId = onSelectCameraId,
              onSelectZoomRatio = { ratio ->
                boundCamera?.cameraControl?.setZoomRatio(ratio)
                onZoomChanged(ratio)
              },
            )
          }
          if (uiState.captureDomain == AppCaptureDomain.PHOTO) {
            PhotographyModeCarousel(
              activeMode = uiState.photographyMode,
              modeCapabilities = uiState.modeCapabilities,
              detectedScene = uiState.detectedAutoScene,
              onSelectMode = onSelectPhotographyMode,
              onOpenModesDetail = { isModesDetailOpen = true },
              modifier = Modifier.widthIn(max = 520.dp),
            )
          }
          CaptureDomainTogglePill(
            activeDomain = uiState.captureDomain,
            enabled = !uiState.videoRecordingState.isRecording && !uiState.isCapturing,
            onSelectDomain = onSelectCaptureDomain,
          )
        }
      }
    } else {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .align(Alignment.BottomCenter)
            .background(
              Brush.verticalGradient(
                colors = listOf(Color.Transparent, ObsidianBlack.copy(alpha = 0.88f))
              )
            )
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        if (uiState.captureDomain == AppCaptureDomain.PHOTO) {
          AnimatedVisibility(
            visible = uiState.manualSettings.isProPanelOpen,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
          ) {
            ProControlsPanel(
              profile = uiState.activeHardwareProfile,
              sensorCapabilities = uiState.sensorCapabilities,
              settings = uiState.manualSettings,
              liveTelemetry = uiState.liveTelemetry,
              customPresets = uiState.customPresets,
              hasLevelSensor = uiState.deviceInventory.hasLevelSensor,
              isFrontCamera = uiState.lensOption == LensOption.FRONT,
              isGridEnabled = uiState.isGridEnabled,
              isLevelEnabled = uiState.isLevelEnabled,
              isFrontMirrorEnabled = uiState.isFrontMirrorEnabled,
              isVolumeShutterEnabled = uiState.isVolumeShutterEnabled,
              onSelectProTab = onSelectProTab,
              onSetManualIso = onSetManualIso,
              onSetManualShutter = onSetManualShutter,
              onSetWhiteBalance = onSetWhiteBalance,
              onSetManualKelvin = onSetManualKelvin,
              onSetManualFocus = onSetManualFocus,
              onExposureCompChange = applyEvIndex,
              onSelectCaptureFormat = onSelectCaptureFormat,
              onToggleExposureLock = onToggleExposureLock,
              onSelectStabilization = onSelectStabilization,
              onToggleFocusPeaking = onToggleFocusPeaking,
              onCycleFocusPeakingColor = onCycleFocusPeakingColor,
              onToggleHistogram = onToggleHistogram,
              onToggleZebra = onToggleZebra,
              onSetZebraThreshold = onSetZebraThreshold,
              onToggleGrid = onToggleGrid,
              onToggleLevel = onToggleLevel,
              onToggleFrontMirror = onToggleFrontMirror,
              onToggleVolumeShutter = onToggleVolumeShutter,
              onSavePreset = onSavePreset,
              onApplyPreset = { preset -> onApplyPreset(preset, applyEvIndex) },
              onDeletePreset = onDeletePreset,
              onResetAllToAuto = { onResetAllToAuto(applyEvIndex) },
              modifier = Modifier.padding(bottom = 10.dp).heightIn(max = 320.dp),
            )
          }

          if (uiState.photographyMode == PhotographyMode.PANORAMA && !uiState.manualSettings.isProPanelOpen) {
            PanoramaSweepHud(
              state = uiState.panoramaState,
              onFinishStitch = finishAndStitchPanorama,
              onCancelSweep = cancelPanoramaSweep,
              modifier = Modifier.padding(bottom = 10.dp),
            )
          }
        } else {
          AnimatedVisibility(
            visible = uiState.isVideoSettingsOpen && !uiState.videoRecordingState.isRecording,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
          ) {
            VideoSettingsDeck(
              settings = uiState.videoSettings,
              capabilities = uiState.videoCapabilities,
              sensorCapabilities = uiState.sensorCapabilities,
              onSelectQuality = onSelectVideoQuality,
              onSelectFps = onSelectVideoFps,
              onSelectBitrate = onSelectVideoBitrate,
              onToggleHdr = onToggleVideoHdr,
              onSelectStabilization = onSelectVideoStabilization,
              onToggleAudio = onToggleVideoAudio,
              onToggleSlowMoBaked = onToggleSlowMoBaked,
              onExposureCompChange = applyEvIndex,
              modifier = Modifier.padding(bottom = 10.dp).heightIn(max = 310.dp),
            )
          }
        }

        if (
          supportsZoom &&
            !uiState.manualSettings.isProPanelOpen &&
            !(uiState.captureDomain == AppCaptureDomain.PHOTO && uiState.photographyMode == PhotographyMode.PANORAMA)
        ) {
          ZoomSliderBar(
            currentZoom = uiState.sensorCapabilities.currentZoomRatio,
            minZoom = uiState.sensorCapabilities.minZoomRatio,
            maxZoom = uiState.sensorCapabilities.maxZoomRatio,
            onZoomChange = { z ->
              boundCamera?.cameraControl?.setZoomRatio(z)
              onZoomChanged(z)
            },
            modifier = Modifier.widthIn(max = 360.dp).fillMaxWidth().padding(bottom = 8.dp),
          )
        }

        if (!uiState.videoRecordingState.isRecording) {
          DynamicLensSelectorBar(
            activeProfile = uiState.activeHardwareProfile,
            sameFacingSelectableCameras = sameFacingCameras,
            currentZoomRatio = uiState.sensorCapabilities.currentZoomRatio,
            maxZoomRatio = uiState.sensorCapabilities.maxZoomRatio,
            onSelectCameraId = onSelectCameraId,
            onSelectZoomRatio = { ratio ->
              boundCamera?.cameraControl?.setZoomRatio(ratio)
              onZoomChanged(ratio)
            },
            modifier = Modifier.padding(bottom = 8.dp),
          )
        }

        if (uiState.captureDomain == AppCaptureDomain.PHOTO && !uiState.manualSettings.isProPanelOpen) {
          PhotographyModeCarousel(
            activeMode = uiState.photographyMode,
            modeCapabilities = uiState.modeCapabilities,
            detectedScene = uiState.detectedAutoScene,
            onSelectMode = onSelectPhotographyMode,
            onOpenModesDetail = { isModesDetailOpen = true },
            modifier = Modifier.padding(bottom = 8.dp),
          )
        }

        CaptureDomainTogglePill(
          activeDomain = uiState.captureDomain,
          enabled = !uiState.videoRecordingState.isRecording && !uiState.isCapturing,
          onSelectDomain = onSelectCaptureDomain,
          modifier = Modifier.padding(bottom = 10.dp),
        )

        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f),
          ) {
            LastPhotoThumbnailButton(
              lastPhoto = uiState.lastCapturedPhoto,
              iconRotation = animatedIconRotation,
              onClick = {
                if (uiState.lastCapturedPhoto != null) onOpenLastPhoto() else onOpenGallery()
              },
            )
            if (uiState.lastCapturedPhoto != null && !uiState.videoRecordingState.isRecording) {
              GalleryIconButton(
                iconRotation = animatedIconRotation,
                onClick = onOpenGallery,
              )
            }
          }

          if (uiState.captureDomain == AppCaptureDomain.VIDEO) {
            VideoRecordButton(
              isRecording = uiState.videoRecordingState.isRecording,
              isPaused = uiState.videoRecordingState.isPaused,
              isFinalizing = uiState.videoRecordingState.isFinalizing,
              isCountingDown = uiState.countdownRemainingSeconds != null,
              enabled = boundVideoCapture != null,
              onClick = triggerVideoRecordOrStop,
            )
          } else {
            ShutterButton(
              isCapturing = uiState.isCapturing,
              isCountingDown = uiState.countdownRemainingSeconds != null,
              burstProgressCount = uiState.burstProgressCount,
              isBurstMode = uiState.isBurstModeEnabled,
              enabled = boundImageCapture != null,
              onClick = triggerShutterOrCancel,
            )
          }

          Box(
            contentAlignment = Alignment.CenterEnd,
            modifier = Modifier.weight(1f),
          ) {
            if (
              uiState.captureDomain == AppCaptureDomain.VIDEO &&
                uiState.videoRecordingState.canPauseOrResume
            ) {
              VideoPauseResumeButton(
                isPaused = uiState.videoRecordingState.isPaused,
                enabled = uiState.videoRecordingState.canPauseOrResume,
                onClick = toggleVideoPauseResume,
              )
            } else {
              SwitchCameraButton(
                enabled =
                  uiState.hasBackCamera &&
                    uiState.hasFrontCamera &&
                    !uiState.videoRecordingState.isRecording,
                iconRotation = animatedIconRotation,
                onClick = onSwitchCamera,
              )
            }
          }
        }
      }
    }

    if (isModesDetailOpen) {
      PhotographyModesDetailDialog(
        activeMode = uiState.photographyMode,
        capabilities = uiState.modeCapabilities,
        onSelectMode = onSelectPhotographyMode,
        onDismiss = { isModesDetailOpen = false },
      )
    }
  }
}

@OptIn(ExperimentalZeroShutterLag::class)
private fun resolveImageCaptureMode(
  speedMode: CaptureSpeedMode,
  isZslSupported: Boolean,
  rawActive: Boolean,
): Int {
  if (rawActive || speedMode == CaptureSpeedMode.MAX_QUALITY) {
    return ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
  }
  return if (isZslSupported) {
    ImageCapture.CAPTURE_MODE_ZERO_SHUTTER_LAG
  } else {
    ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
  }
}

private suspend fun awaitCameraProvider(context: Context): ProcessCameraProvider =
  suspendCancellableCoroutine { continuation ->
    val future = ProcessCameraProvider.getInstance(context)
    future.addListener(
      {
        try {
          continuation.resume(future.get())
        } catch (e: Exception) {
          if (continuation.isActive) continuation.resumeWithException(e)
        }
      },
      ContextCompat.getMainExecutor(context),
    )
  }
