package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.CenterFocusStrong
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Flare
import androidx.compose.material.icons.outlined.HdrOn
import androidx.compose.material.icons.outlined.HighQuality
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Panorama
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.camera.CameraModeCapabilities
import com.example.camera.DetectedSceneType
import com.example.camera.PanoramaSessionState
import com.example.camera.PhotographyMode
import com.example.ui.theme.CaptureEmerald
import com.example.ui.theme.HairlineLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianGlass
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.OpticalCyan
import com.example.ui.theme.ProAmber
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.SilverSecondary
import com.example.ui.theme.TitaniumWhite
import java.util.Locale
import kotlin.math.abs

@Composable
fun PhotographyModeCarousel(
  activeMode: PhotographyMode,
  modeCapabilities: CameraModeCapabilities,
  detectedScene: DetectedSceneType,
  onSelectMode: (PhotographyMode) -> Unit,
  onOpenModesDetail: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxWidth(),
  ) {
    if (activeMode == PhotographyMode.AUTO_SCENE) {
      Surface(
        shape = CircleShape,
        color = OpticalCyan.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, OpticalCyan.copy(alpha = 0.45f)),
        modifier = Modifier.padding(bottom = 6.dp).testTag("auto_scene_badge"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
          Icon(
            imageVector = Icons.Outlined.AutoAwesome,
            contentDescription = null,
            tint = OpticalCyan,
            modifier = Modifier.size(13.dp),
          )
          Text(
            text = "SCENE · ${detectedScene.label.uppercase(Locale.US)}",
            style = MaterialTheme.typography.labelSmall,
            color = TitaniumWhite,
          )
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(
        modifier =
          Modifier.weight(1f)
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        PhotographyMode.entries.forEach { mode ->
          val avail = modeCapabilities.availabilityOf(mode)
          val selected = activeMode == mode
          val supported = avail.isSupported
          val bgColor =
            when {
              selected -> ProAmber
              supported -> ObsidianGlass
              else -> ObsidianGlass.copy(alpha = 0.45f)
            }
          val borderColor =
            when {
              selected -> ProAmber
              supported -> HairlineLight
              else -> HairlineLight.copy(alpha = 0.35f)
            }
          val textColor =
            when {
              selected -> ObsidianBlack
              supported -> TitaniumWhite
              else -> SilverMuted
            }

          Surface(
            shape = CircleShape,
            color = bgColor,
            border = BorderStroke(1.dp, borderColor),
            modifier =
              Modifier.minimumInteractiveComponentSize()
                .clip(CircleShape)
                .clickable { onSelectMode(mode) }
                .testTag("mode_chip_${mode.name.lowercase()}"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Icon(
                imageVector = if (supported) iconForMode(mode) else Icons.Outlined.Lock,
                contentDescription = mode.label,
                tint = textColor,
                modifier = Modifier.size(13.dp),
              )
              Text(
                text = mode.shortTag,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = textColor,
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.width(6.dp))

      Surface(
        shape = CircleShape,
        color = ObsidianGlass,
        border = BorderStroke(1.dp, HairlineLight),
        modifier = Modifier.size(38.dp),
      ) {
        IconButton(
          onClick = onOpenModesDetail,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("modes_info_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.Info,
            contentDescription = stringResource(R.string.cd_photography_modes_info),
            tint = OpticalCyan,
            modifier = Modifier.size(17.dp),
          )
        }
      }
    }
  }
}

@Composable
fun PanoramaSweepHud(
  state: PanoramaSessionState,
  onFinishStitch: () -> Unit,
  onCancelSweep: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = ObsidianBlack.copy(alpha = 0.80f),
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp).testTag("panorama_sweep_hud"),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text =
            if (state.isStitching) stringResource(R.string.pano_stitching_status)
            else if (state.isActive) "SWEEP · ${state.capturedSlicesCount}/${state.maxSlices} FRAMES"
            else "PANORAMA READY",
          style = MaterialTheme.typography.labelMedium,
          color = if (state.isActive) ProAmber else OpticalCyan,
        )
        Text(
          text = String.format(Locale.US, "%.0f°", state.currentYawDeg),
          style = MaterialTheme.typography.labelMedium,
          color = TitaniumWhite,
        )
      }

      // Guide Horizon Level Bar
      val tilt = state.pitchTiltDeg.coerceIn(-12f, 12f)
      val isLevel = abs(tilt) <= 2.5f
      Canvas(modifier = Modifier.fillMaxWidth().height(18.dp)) {
        val midY = size.height / 2f
        val leftX = 12.dp.toPx()
        val rightX = size.width - 12.dp.toPx()
        drawLine(
          color = TitaniumWhite.copy(alpha = 0.25f),
          start = Offset(leftX, midY),
          end = Offset(rightX, midY),
          strokeWidth = 2.dp.toPx(),
          cap = StrokeCap.Round,
        )
        val dotY = midY + (tilt / 12f) * (size.height * 0.35f)
        val dotColor = if (isLevel) CaptureEmerald else ProAmber
        drawCircle(
          color = dotColor,
          radius = 4.5.dp.toPx(),
          center = Offset(size.width / 2f, dotY),
        )
      }

      // Slice Progress Dots
      Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        for (i in 0 until state.maxSlices) {
          val filled = i < state.capturedSlicesCount
          Box(
            modifier =
              Modifier.size(width = 24.dp, height = 5.dp)
                .clip(CircleShape)
                .background(if (filled) CaptureEmerald else HairlineLight)
          )
        }
      }

      Text(
        text = state.statusHint,
        style = MaterialTheme.typography.bodySmall,
        color = SilverSecondary,
      )

      if (state.isStitching) {
        CircularProgressIndicator(
          modifier = Modifier.size(22.dp),
          color = ProAmber,
          strokeWidth = 2.dp,
        )
      } else if (state.isActive) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          OutlinedButton(
            onClick = onCancelSweep,
            border = BorderStroke(1.dp, HairlineLight),
            modifier = Modifier.minimumInteractiveComponentSize().testTag("pano_cancel_button"),
          ) {
            Text(
              text = stringResource(R.string.pano_cancel_btn),
              color = TitaniumWhite,
              style = MaterialTheme.typography.labelSmall,
            )
          }
          if (state.canFinishStitch) {
            Button(
              onClick = onFinishStitch,
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = CaptureEmerald,
                  contentColor = ObsidianBlack,
                ),
              modifier = Modifier.minimumInteractiveComponentSize().testTag("pano_stitch_button"),
            ) {
              Text(
                text = stringResource(R.string.pano_stitch_btn, state.capturedSlicesCount),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun PhotographyModesDetailDialog(
  activeMode: PhotographyMode,
  capabilities: CameraModeCapabilities,
  onSelectMode: (PhotographyMode) -> Unit,
  onDismiss: () -> Unit,
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    Surface(
      shape = RoundedCornerShape(22.dp),
      color = ObsidianSurface,
      border = BorderStroke(1.dp, HairlineLight),
      modifier = Modifier.fillMaxWidth().padding(18.dp).heightIn(max = 620.dp),
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = stringResource(R.string.modes_dialog_title),
              style = MaterialTheme.typography.titleMedium,
              color = TitaniumWhite,
            )
            Text(
              text = stringResource(R.string.modes_dialog_subtitle),
              style = MaterialTheme.typography.bodySmall,
              color = SilverSecondary,
            )
          }
          IconButton(onClick = onDismiss, modifier = Modifier.minimumInteractiveComponentSize()) {
            Icon(
              imageVector = Icons.Outlined.Close,
              contentDescription = "Close",
              tint = TitaniumWhite,
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(
          modifier = Modifier.verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          PhotographyMode.entries.forEach { mode ->
            val avail = capabilities.availabilityOf(mode)
            val isSelected = activeMode == mode
            Surface(
              shape = RoundedCornerShape(14.dp),
              color =
                when {
                  isSelected -> ProAmber.copy(alpha = 0.16f)
                  avail.isSupported -> ObsidianGlass
                  else -> ObsidianBlack.copy(alpha = 0.65f)
                },
              border =
                BorderStroke(
                  1.dp,
                  when {
                    isSelected -> ProAmber
                    avail.isSupported -> HairlineLight
                    else -> HairlineLight.copy(alpha = 0.3f)
                  },
                ),
              modifier =
                Modifier.fillMaxWidth()
                  .clip(RoundedCornerShape(14.dp))
                  .clickable {
                    onSelectMode(mode)
                    if (avail.isSupported) onDismiss()
                  },
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                Icon(
                  imageVector = iconForMode(mode),
                  contentDescription = mode.label,
                  tint =
                    when {
                      isSelected -> ProAmber
                      avail.isSupported -> OpticalCyan
                      else -> SilverMuted
                    },
                  modifier = Modifier.size(22.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                  ) {
                    Text(
                      text = mode.label,
                      style = MaterialTheme.typography.labelLarge,
                      color = if (avail.isSupported) TitaniumWhite else SilverMuted,
                    )
                    Text(
                      text = avail.backendLabel,
                      style = MaterialTheme.typography.labelSmall,
                      color = if (avail.isSupported) CaptureEmerald else SilverMuted,
                    )
                  }
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = avail.reason,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (avail.isSupported) SilverSecondary else SilverMuted,
                  )
                }
                Icon(
                  imageVector =
                    if (avail.isSupported) Icons.Outlined.CheckCircle else Icons.Outlined.Lock,
                  contentDescription = if (avail.isSupported) "Supported" else "Unavailable",
                  tint =
                    when {
                      isSelected -> ProAmber
                      avail.isSupported -> CaptureEmerald
                      else -> SilverMuted
                    },
                  modifier = Modifier.size(18.dp),
                )
              }
            }
          }
        }
      }
    }
  }
}

private fun iconForMode(mode: PhotographyMode): ImageVector =
  when (mode) {
    PhotographyMode.STANDARD -> Icons.Outlined.PhotoCamera
    PhotographyMode.HDR -> Icons.Outlined.HdrOn
    PhotographyMode.NIGHT -> Icons.Outlined.Bedtime
    PhotographyMode.PORTRAIT -> Icons.Outlined.Face
    PhotographyMode.MACRO -> Icons.Outlined.CenterFocusStrong
    PhotographyMode.HIGH_RES -> Icons.Outlined.HighQuality
    PhotographyMode.PANORAMA -> Icons.Outlined.Panorama
    PhotographyMode.LOW_LIGHT -> Icons.Outlined.Flare
    PhotographyMode.AUTO_SCENE -> Icons.Outlined.AutoAwesome
    PhotographyMode.NATURAL_COLOR -> Icons.Outlined.Palette
  }
