package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val UltraCamDarkColorScheme =
  darkColorScheme(
    primary = TitaniumWhite,
    onPrimary = ObsidianBlack,
    primaryContainer = ObsidianElevated,
    onPrimaryContainer = TitaniumWhite,
    secondary = OpticalCyan,
    onSecondary = ObsidianBlack,
    secondaryContainer = ObsidianSurface,
    onSecondaryContainer = OpticalCyan,
    tertiary = ProAmber,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = TitaniumWhite,
    surface = ObsidianSurface,
    onSurface = TitaniumWhite,
    surfaceVariant = ObsidianElevated,
    onSurfaceVariant = SilverSecondary,
    outline = HairlineLight,
    outlineVariant = HairlineSubtle,
    error = ErrorCoral,
    onError = ObsidianBlack,
  )

@Composable
fun UltraCamProTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = UltraCamDarkColorScheme,
    typography = UltraCamTypography,
    content = content,
  )
}
