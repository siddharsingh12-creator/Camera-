package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.HighQuality
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.camera.CameraPermissionStatus
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.HairlineLight
import com.example.ui.theme.HairlineSubtle
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.OpticalCyan
import com.example.ui.theme.ProAmber
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.SilverSecondary
import com.example.ui.theme.TitaniumWhite
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PermissionWelcomeScreen(
  permissionStatus: CameraPermissionStatus,
  onOpenCameraClick: () -> Unit,
  onOpenSettingsClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(ObsidianBlack)
        .drawBehind {
          drawCircle(
            brush =
              Brush.radialGradient(
                colors =
                  listOf(
                    OpticalCyan.copy(alpha = 0.08f),
                    ProAmber.copy(alpha = 0.03f),
                    Color.Transparent,
                  ),
                center = Offset(size.width * 0.5f, size.height * 0.24f),
                radius = size.minDimension * 0.85f,
              )
          )
        }
        .windowInsetsPadding(WindowInsets.safeDrawing)
  ) {
    Column(
      modifier =
        Modifier.fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 24.dp, vertical = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(
        modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Precision optical tagline chip
        Surface(
          shape = CircleShape,
          color = ObsidianSurface,
          border = BorderStroke(1.dp, HairlineLight),
        ) {
          Text(
            text = stringResource(R.string.tagline_pro_optics),
            style = MaterialTheme.typography.labelSmall,
            color = OpticalCyan,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
          )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Custom geometric optical aperture emblem
        OpticalLensEmblem(modifier = Modifier.size(124.dp))

        Spacer(modifier = Modifier.height(24.dp))

        Text(
          text = stringResource(R.string.app_name),
          style = MaterialTheme.typography.displaySmall,
          color = TitaniumWhite,
          textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = stringResource(R.string.permission_title),
          style = MaterialTheme.typography.titleMedium,
          color = SilverSecondary,
          textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = stringResource(R.string.permission_subtitle),
          style = MaterialTheme.typography.bodyLarge,
          color = SilverMuted,
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(horizontal = 8.dp),
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Hardware capabilities spec cards
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          HardwareSpecRow(
            icon = Icons.Outlined.HighQuality,
            accent = OpticalCyan,
            title = stringResource(R.string.feature_max_res_title),
            description = stringResource(R.string.feature_max_res_desc),
          )
          HardwareSpecRow(
            icon = Icons.Outlined.AutoAwesome,
            accent = ProAmber,
            title = stringResource(R.string.feature_max_quality_title),
            description = stringResource(R.string.feature_max_quality_desc),
          )
          HardwareSpecRow(
            icon = Icons.Outlined.PhotoLibrary,
            accent = TitaniumWhite,
            title = stringResource(R.string.feature_mediastore_title),
            description = stringResource(R.string.feature_mediastore_desc),
          )
        }
      }

      Column(
        modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth().padding(top = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        AnimatedVisibility(
          visible =
            permissionStatus == CameraPermissionStatus.DENIED ||
              permissionStatus == CameraPermissionStatus.PERMANENTLY_DENIED,
          enter = fadeIn(),
          exit = fadeOut(),
        ) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = ErrorCoral.copy(alpha = 0.12f),
            border = BorderStroke(1.dp, ErrorCoral.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
          ) {
            Text(
              text =
                if (permissionStatus == CameraPermissionStatus.PERMANENTLY_DENIED) {
                  stringResource(R.string.permission_permanently_denied_notice)
                } else {
                  stringResource(R.string.permission_denied_notice)
                },
              style = MaterialTheme.typography.bodyMedium,
              color = TitaniumWhite,
              textAlign = TextAlign.Center,
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            )
          }
        }

        Button(
          onClick = onOpenCameraClick,
          shape = CircleShape,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = TitaniumWhite,
              contentColor = ObsidianBlack,
            ),
          modifier =
            Modifier.fillMaxWidth()
              .height(58.dp)
              .testTag("open_camera_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.CameraAlt,
            contentDescription = null,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = stringResource(R.string.btn_open_camera),
            style = MaterialTheme.typography.labelLarge,
          )
        }

        if (permissionStatus == CameraPermissionStatus.PERMANENTLY_DENIED) {
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedButton(
            onClick = onOpenSettingsClick,
            shape = CircleShape,
            border = BorderStroke(1.dp, HairlineLight),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TitaniumWhite),
            modifier =
              Modifier.fillMaxWidth()
                .height(52.dp)
                .testTag("open_settings_button"),
          ) {
            Icon(
              imageVector = Icons.Outlined.Settings,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.btn_open_settings),
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun HardwareSpecRow(
  icon: ImageVector,
  accent: Color,
  title: String,
  description: String,
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = ObsidianSurface,
    border = BorderStroke(1.dp, HairlineSubtle),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = ObsidianElevated,
        modifier = Modifier.size(40.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(20.dp),
          )
        }
      }
      Spacer(modifier = Modifier.width(14.dp))
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = TitaniumWhite,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = description,
          style = MaterialTheme.typography.bodyMedium,
          color = SilverMuted,
        )
      }
    }
  }
}

@Composable
private fun OpticalLensEmblem(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val radius = size.minDimension / 2f

    // Outer precision lens barrel ring
    drawCircle(
      color = ObsidianElevated,
      radius = radius,
      center = Offset(cx, cy),
    )
    drawCircle(
      color = HairlineLight,
      radius = radius - 2.dp.toPx(),
      center = Offset(cx, cy),
      style = Stroke(width = 1.5.dp.toPx()),
    )

    // Subtle calibration tick marks
    val tickCount = 24
    for (i in 0 until tickCount) {
      val angleRad = Math.toRadians((i * (360.0 / tickCount)))
      val innerR = radius * 0.84f
      val outerR = radius * 0.91f
      drawLine(
        color = if (i % 6 == 0) TitaniumWhite.copy(alpha = 0.5f) else HairlineLight,
        start = Offset(cx + (innerR * cos(angleRad)).toFloat(), cy + (innerR * sin(angleRad)).toFloat()),
        end = Offset(cx + (outerR * cos(angleRad)).toFloat(), cy + (outerR * sin(angleRad)).toFloat()),
        strokeWidth = if (i % 6 == 0) 1.5.dp.toPx() else 1.dp.toPx(),
        cap = StrokeCap.Round,
      )
    }

    // Optical glass ring
    drawCircle(
      brush =
        Brush.sweepGradient(
          colors =
            listOf(
              OpticalCyan.copy(alpha = 0.7f),
              TitaniumWhite.copy(alpha = 0.4f),
              OpticalCyan.copy(alpha = 0.25f),
              TitaniumWhite.copy(alpha = 0.8f),
              OpticalCyan.copy(alpha = 0.7f),
            ),
          center = Offset(cx, cy),
        ),
      radius = radius * 0.68f,
      center = Offset(cx, cy),
      style = Stroke(width = 2.5.dp.toPx()),
    )

    // Inner aperture diaphragm blades
    val bladeCount = 6
    val innerAperture = radius * 0.25f
    val outerAperture = radius * 0.60f
    for (i in 0 until bladeCount) {
      val startAngle = Math.toRadians(i * 60.0 + 18.0)
      val endAngle = Math.toRadians(i * 60.0 + 78.0)
      val p1 =
        Offset(
          cx + (innerAperture * cos(startAngle)).toFloat(),
          cy + (innerAperture * sin(startAngle)).toFloat(),
        )
      val p2 =
        Offset(
          cx + (outerAperture * cos(endAngle)).toFloat(),
          cy + (outerAperture * sin(endAngle)).toFloat(),
        )
      drawLine(
        color = TitaniumWhite.copy(alpha = 0.75f),
        start = p1,
        end = p2,
        strokeWidth = 1.6.dp.toPx(),
        cap = StrokeCap.Round,
      )
    }

    // Center sensor core dot + amber pro dot
    drawCircle(
      color = ObsidianBlack,
      radius = radius * 0.20f,
      center = Offset(cx, cy),
    )
    drawCircle(
      color = ProAmber,
      radius = 3.5.dp.toPx(),
      center = Offset(cx, cy - radius * 0.77f),
    )
  }
}
