package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BurstMode
import androidx.compose.material.icons.outlined.FlashAuto
import androidx.compose.material.icons.outlined.FlashOff
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.GridOff
import androidx.compose.material.icons.outlined.GridOn
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.camera.CameraHardwareProfile
import com.example.camera.CaptureSpeedMode
import com.example.camera.CapturedPhotoInfo
import com.example.camera.FlashSetting
import com.example.camera.FocusPointState
import com.example.camera.PreviewAspectRatio
import com.example.camera.ShutterTimer
import com.example.ui.theme.CaptureEmerald
import com.example.ui.theme.HairlineLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianGlass
import com.example.ui.theme.OpticalCyan
import com.example.ui.theme.ProAmber
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.SilverSecondary
import com.example.ui.theme.TitaniumWhite
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import com.example.camera.MediaStoreVideoSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun ShutterButton(
  isCapturing: Boolean,
  isCountingDown: Boolean,
  burstProgressCount: Int?,
  isBurstMode: Boolean,
  enabled: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val innerScale by
    animateFloatAsState(
      targetValue =
        when {
          isCapturing -> 0.84f
          isPressed -> 0.88f
          else -> 1f
        },
      animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
      label = "shutterInnerScale",
    )
  val shutterCd = stringResource(R.string.cd_shutter_button)

  Box(
    contentAlignment = Alignment.Center,
    modifier =
      modifier
        .size(82.dp)
        .minimumInteractiveComponentSize()
        .clip(CircleShape)
        .clickable(
          enabled = enabled && (!isCapturing || isCountingDown),
          interactionSource = interactionSource,
          indication = null,
          role = Role.Button,
          onClick = onClick,
        )
        .semantics { contentDescription = shutterCd }
        .testTag("shutter_button"),
  ) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .border(
            width = 3.dp,
            color = if (isBurstMode) ProAmber else TitaniumWhite.copy(alpha = 0.92f),
            shape = CircleShape,
          )
    )

    Box(
      contentAlignment = Alignment.Center,
      modifier =
        Modifier.size(66.dp)
          .scale(innerScale)
          .clip(CircleShape)
          .background(
            when {
              !enabled -> SilverMuted
              isCountingDown -> ProAmber
              else -> TitaniumWhite
            }
          ),
    ) {
      when {
        isCountingDown -> {
          Text(
            text = "STOP",
            style = MaterialTheme.typography.labelSmall,
            color = ObsidianBlack,
          )
        }
        burstProgressCount != null -> {
          Text(
            text = "$burstProgressCount",
            style = MaterialTheme.typography.titleMedium,
            color = ObsidianBlack,
          )
        }
        isCapturing -> {
          CircularProgressIndicator(
            modifier = Modifier.size(26.dp),
            color = ObsidianBlack,
            strokeWidth = 2.5.dp,
          )
        }
      }
    }
  }
}

@Composable
fun LastPhotoThumbnailButton(
  lastPhoto: CapturedPhotoInfo?,
  iconRotation: Float,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val cd =
    when {
      lastPhoto?.isVideo == true -> stringResource(R.string.cd_last_video_thumbnail)
      lastPhoto != null -> stringResource(R.string.cd_last_photo_thumbnail)
      else -> stringResource(R.string.cd_open_gallery)
    }

  var videoThumb by remember(lastPhoto?.uri, lastPhoto?.isVideo) { mutableStateOf<Bitmap?>(null) }
  LaunchedEffect(lastPhoto?.uri, lastPhoto?.isVideo) {
    if (lastPhoto != null && lastPhoto.isVideo) {
      videoThumb =
        withContext(Dispatchers.IO) {
          MediaStoreVideoSaver.extractVideoThumbnail(context, lastPhoto.uri)
        }
    } else {
      videoThumb = null
    }
  }

  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(14.dp),
    color = ObsidianGlass,
    border =
      BorderStroke(
        width = 1.5.dp,
        color = if (lastPhoto != null) TitaniumWhite.copy(alpha = 0.75f) else HairlineLight,
      ),
    modifier =
      modifier
        .size(54.dp)
        .minimumInteractiveComponentSize()
        .semantics { contentDescription = cd }
        .testTag("last_photo_thumbnail"),
  ) {
    if (lastPhoto != null) {
      Box(modifier = Modifier.fillMaxSize()) {
        if (lastPhoto.isVideo && videoThumb != null) {
          Image(
            bitmap = videoThumb!!.asImageBitmap(),
            contentDescription = cd,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().rotate(iconRotation),
          )
        } else {
          AsyncImage(
            model =
              ImageRequest.Builder(context)
                .data(lastPhoto.uri)
                .size(256)
                .crossfade(true)
                .build(),
            contentDescription = cd,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().rotate(iconRotation),
          )
        }

        if (lastPhoto.isVideo) {
          Box(
            contentAlignment = Alignment.Center,
            modifier =
              Modifier.align(Alignment.Center)
                .size(22.dp)
                .clip(CircleShape)
                .background(ObsidianBlack.copy(alpha = 0.65f)),
          ) {
            Icon(
              imageVector = Icons.Rounded.PlayArrow,
              contentDescription = null,
              tint = TitaniumWhite,
              modifier = Modifier.size(15.dp),
            )
          }
          Surface(
            color = ObsidianBlack.copy(alpha = 0.80f),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp),
          ) {
            Text(
              text = MediaStoreVideoSaver.formatDurationMs(lastPhoto.durationMs),
              style = MaterialTheme.typography.labelSmall,
              color = TitaniumWhite,
              modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
            )
          }
        } else if (lastPhoto.displayName.endsWith(".dng", ignoreCase = true)) {
          Surface(
            color = ObsidianBlack.copy(alpha = 0.78f),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp),
          ) {
            Text(
              text = "DNG",
              style = MaterialTheme.typography.labelSmall,
              color = ProAmber,
              modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
            )
          }
        }
      }
    } else {
      Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Icon(
          imageVector = Icons.Outlined.PhotoLibrary,
          contentDescription = cd,
          tint = TitaniumWhite,
          modifier = Modifier.size(22.dp).rotate(iconRotation),
        )
      }
    }
  }
}

@Composable
fun GalleryIconButton(
  iconRotation: Float,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val cd = stringResource(R.string.cd_open_gallery)
  Surface(
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.size(48.dp),
  ) {
    IconButton(
      onClick = onClick,
      modifier = Modifier.fillMaxSize().testTag("gallery_button"),
    ) {
      Icon(
        imageVector = Icons.Outlined.PhotoLibrary,
        contentDescription = cd,
        tint = TitaniumWhite,
        modifier = Modifier.size(20.dp).rotate(iconRotation),
      )
    }
  }
}

@Composable
fun SwitchCameraButton(
  enabled: Boolean,
  iconRotation: Float,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val cd = stringResource(R.string.cd_switch_camera)
  Surface(
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.size(54.dp),
  ) {
    IconButton(
      onClick = onClick,
      enabled = enabled,
      modifier = Modifier.fillMaxSize().testTag("switch_camera_button"),
    ) {
      Icon(
        imageVector = Icons.Rounded.Cameraswitch,
        contentDescription = cd,
        tint = if (enabled) TitaniumWhite else SilverMuted,
        modifier = Modifier.size(24.dp).rotate(iconRotation),
      )
    }
  }
}

@Composable
fun AspectRatioSelectorPill(
  selected: PreviewAspectRatio,
  onSelect: (PreviewAspectRatio) -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier,
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 3.dp, vertical = 3.dp),
      horizontalArrangement = Arrangement.spacedBy(2.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      PreviewAspectRatio.entries.forEach { option ->
        val isSelected = option == selected
        Surface(
          onClick = { onSelect(option) },
          shape = CircleShape,
          color = if (isSelected) TitaniumWhite else Color.Transparent,
          modifier =
            Modifier.minimumInteractiveComponentSize()
              .testTag("aspect_ratio_${option.name.lowercase()}"),
        ) {
          Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
          ) {
            Text(
              text = option.label,
              style = MaterialTheme.typography.labelSmall,
              color = if (isSelected) ObsidianBlack else TitaniumWhite,
            )
          }
        }
      }
    }
  }
}

@Composable
fun FlashToggleButton(
  flashSetting: FlashSetting,
  iconRotation: Float,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val icon =
    when (flashSetting) {
      FlashSetting.OFF -> Icons.Outlined.FlashOff
      FlashSetting.AUTO -> Icons.Outlined.FlashAuto
      FlashSetting.ON -> Icons.Outlined.FlashOn
    }
  val tint =
    when (flashSetting) {
      FlashSetting.ON -> ProAmber
      FlashSetting.AUTO -> OpticalCyan
      FlashSetting.OFF -> TitaniumWhite
    }

  Surface(
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.size(48.dp),
  ) {
    IconButton(
      onClick = onClick,
      modifier = Modifier.fillMaxSize().testTag("flash_toggle_button"),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = stringResource(R.string.cd_flash_mode),
        tint = tint,
        modifier = Modifier.size(20.dp).rotate(iconRotation),
      )
    }
  }
}

@Composable
fun TimerToggleButton(
  shutterTimer: ShutterTimer,
  iconRotation: Float,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val isActive = shutterTimer != ShutterTimer.OFF
  Surface(
    onClick = onClick,
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, if (isActive) ProAmber.copy(alpha = 0.65f) else HairlineLight),
    modifier = modifier.minimumInteractiveComponentSize().testTag("timer_toggle_button"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Outlined.Timer,
        contentDescription = stringResource(R.string.cd_timer_mode),
        tint = if (isActive) ProAmber else TitaniumWhite,
        modifier = Modifier.size(18.dp).rotate(iconRotation),
      )
      if (isActive) {
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = shutterTimer.label,
          style = MaterialTheme.typography.labelSmall,
          color = ProAmber,
        )
      }
    }
  }
}

@Composable
fun BurstModePill(
  isEnabled: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    onClick = onClick,
    shape = CircleShape,
    color = if (isEnabled) ProAmber else ObsidianGlass,
    border = BorderStroke(1.dp, if (isEnabled) ProAmber else HairlineLight),
    modifier = modifier.minimumInteractiveComponentSize().testTag("burst_mode_button"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Outlined.BurstMode,
        contentDescription = stringResource(R.string.cd_burst_mode),
        tint = if (isEnabled) ObsidianBlack else TitaniumWhite,
        modifier = Modifier.size(15.dp),
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = "BURST",
        style = MaterialTheme.typography.labelSmall,
        color = if (isEnabled) ObsidianBlack else TitaniumWhite,
      )
    }
  }
}

@Composable
fun QuickCapturePill(
  mode: CaptureSpeedMode,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val isQuick = mode == CaptureSpeedMode.QUICK
  Surface(
    onClick = onClick,
    shape = CircleShape,
    color = if (isQuick) OpticalCyan else ObsidianGlass,
    border = BorderStroke(1.dp, if (isQuick) OpticalCyan else HairlineLight),
    modifier = modifier.minimumInteractiveComponentSize().testTag("quick_capture_button"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Outlined.Speed,
        contentDescription = stringResource(R.string.cd_quick_capture),
        tint = if (isQuick) ObsidianBlack else TitaniumWhite,
        modifier = Modifier.size(15.dp),
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = if (isQuick) "QUICK" else "MAX",
        style = MaterialTheme.typography.labelSmall,
        color = if (isQuick) ObsidianBlack else TitaniumWhite,
      )
    }
  }
}

@Composable
fun ProToggleButton(
  isOpen: Boolean,
  hasAnyManualActive: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val isHighlighted = isOpen || hasAnyManualActive
  Surface(
    onClick = onClick,
    shape = CircleShape,
    color = if (isHighlighted) ProAmber else ObsidianGlass,
    border = BorderStroke(1.dp, if (isHighlighted) ProAmber else HairlineLight),
    modifier = modifier.minimumInteractiveComponentSize().testTag("pro_controls_button"),
  ) {
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
      Text(
        text = stringResource(R.string.pro_label),
        style = MaterialTheme.typography.labelMedium,
        color = if (isHighlighted) ObsidianBlack else TitaniumWhite,
      )
    }
  }
}

@Composable
fun HardwareInspectorButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.size(48.dp),
  ) {
    IconButton(
      onClick = onClick,
      modifier = Modifier.fillMaxSize().testTag("hardware_inspector_button"),
    ) {
      Icon(
        imageVector = Icons.Outlined.Memory,
        contentDescription = stringResource(R.string.cd_hardware_inspector),
        tint = OpticalCyan,
        modifier = Modifier.size(20.dp),
      )
    }
  }
}

@Composable
fun SensorTelemetryPill(
  resolutionText: String,
  lensLabel: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    onClick = onClick,
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.testTag("sensor_telemetry_pill"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier =
          Modifier.size(6.dp)
            .clip(CircleShape)
            .background(OpticalCyan)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = "$lensLabel · $resolutionText",
        style = MaterialTheme.typography.labelSmall,
        color = TitaniumWhite,
      )
    }
  }
}

@Composable
fun ZoomSliderBar(
  currentZoom: Float,
  minZoom: Float,
  maxZoom: Float,
  onZoomChange: (Float) -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.testTag("zoom_slider_bar"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = String.format(Locale.US, "%.1f×", currentZoom),
        style = MaterialTheme.typography.labelSmall,
        color = OpticalCyan,
        modifier = Modifier.width(38.dp),
      )
      Slider(
        value = currentZoom.coerceIn(minZoom, maxZoom),
        onValueChange = onZoomChange,
        valueRange = minZoom..maxZoom,
        colors =
          SliderDefaults.colors(
            thumbColor = TitaniumWhite,
            activeTrackColor = OpticalCyan,
            inactiveTrackColor = HairlineLight,
          ),
        modifier = Modifier.weight(1f).height(28.dp).testTag("zoom_slider"),
      )
      Text(
        text = String.format(Locale.US, "%.0f×", maxZoom),
        style = MaterialTheme.typography.labelSmall,
        color = SilverSecondary,
      )
    }
  }
}

@Composable
fun DynamicLensSelectorBar(
  activeProfile: CameraHardwareProfile?,
  sameFacingSelectableCameras: List<CameraHardwareProfile>,
  currentZoomRatio: Float,
  maxZoomRatio: Float,
  onSelectCameraId: (String) -> Unit,
  onSelectZoomRatio: (Float) -> Unit,
  modifier: Modifier = Modifier,
) {
  val opticalStops = activeProfile?.opticalZoomStops.orEmpty()
  val hasMultipleBindableLenses = sameFacingSelectableCameras.size >= 2
  val hasVerifiedOpticalStops = opticalStops.size >= 2

  Surface(
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.testTag("dynamic_lens_bar"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(4.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      when {
        hasMultipleBindableLenses -> {
          sameFacingSelectableCameras.forEach { cam ->
            val selected = cam.cameraId == activeProfile?.cameraId
            val focalLabel =
              cam.focalLengthsMm.firstOrNull()?.let {
                "${String.format(Locale.US, "%.1f", it)}mm"
              } ?: ""
            val label =
              if (focalLabel.isNotEmpty()) "${cam.role.shortTag} $focalLabel"
              else cam.role.shortTag
            Surface(
              onClick = { onSelectCameraId(cam.cameraId) },
              shape = CircleShape,
              color = if (selected) TitaniumWhite else Color.Transparent,
              modifier = Modifier.testTag("lens_option_${cam.cameraId}"),
            ) {
              Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = if (selected) ObsidianBlack else TitaniumWhite,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              )
            }
          }
        }
        hasVerifiedOpticalStops -> {
          opticalStops.forEach { stop ->
            val targetZoom = stop.zoomRatio ?: 1f
            val isClosest =
              opticalStops.minByOrNull { abs((it.zoomRatio ?: 1f) - currentZoomRatio) } == stop
            Surface(
              onClick = { onSelectZoomRatio(targetZoom) },
              shape = CircleShape,
              color = if (isClosest) TitaniumWhite else Color.Transparent,
              modifier = Modifier.testTag("optical_stop_${stop.label}"),
            ) {
              Text(
                text = stop.label,
                style = MaterialTheme.typography.labelMedium,
                color = if (isClosest) ObsidianBlack else TitaniumWhite,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              )
            }
          }
        }
        else -> {
          val focalText =
            activeProfile?.focalLengthsMm?.firstOrNull()?.let {
              String.format(Locale.US, " · %.1fmm", it)
            } ?: ""
          val zoomLabel =
            if (maxZoomRatio > 1.05f) {
              String.format(Locale.US, "%.1f×%s", currentZoomRatio, focalText)
            } else {
              "1.0×$focalText"
            }
          Text(
            text = zoomLabel,
            style = MaterialTheme.typography.labelMedium,
            color = TitaniumWhite,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          )
        }
      }
    }
  }
}

@Composable
fun RuleOfThirdsGrid(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier.fillMaxSize()) {
    val lineColor = TitaniumWhite.copy(alpha = 0.24f)
    val strokeWidth = 0.75.dp.toPx()

    val thirdW = size.width / 3f
    val twoThirdW = thirdW * 2f
    val thirdH = size.height / 3f
    val twoThirdH = thirdH * 2f

    drawLine(lineColor, Offset(thirdW, 0f), Offset(thirdW, size.height), strokeWidth)
    drawLine(lineColor, Offset(twoThirdW, 0f), Offset(twoThirdW, size.height), strokeWidth)
    drawLine(lineColor, Offset(0f, thirdH), Offset(size.width, thirdH), strokeWidth)
    drawLine(lineColor, Offset(0f, twoThirdH), Offset(size.width, twoThirdH), strokeWidth)
  }
}

@Composable
fun CameraLevelOverlay(
  rollDegrees: Float,
  modifier: Modifier = Modifier,
) {
  val nearestCardinal =
    when {
      abs(rollDegrees) <= 45f -> 0f
      rollDegrees in 45f..135f -> 90f
      rollDegrees in -135f..-45f -> -90f
      else -> if (rollDegrees > 0f) 180f else -180f
    }
  val deltaFromLevel = rollDegrees - nearestCardinal
  val isLevel = abs(deltaFromLevel) <= 1.5f
  val accent = if (isLevel) CaptureEmerald else TitaniumWhite.copy(alpha = 0.78f)

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.size(140.dp)) {
      val cx = size.width / 2f
      val cy = size.height / 2f
      val lineSpan = 42.dp.toPx()

      // Fixed horizontal reference ticks
      drawLine(
        color = TitaniumWhite.copy(alpha = 0.35f),
        start = Offset(cx - lineSpan - 12.dp.toPx(), cy),
        end = Offset(cx - lineSpan - 3.dp.toPx(), cy),
        strokeWidth = 1.5.dp.toPx(),
        cap = StrokeCap.Round,
      )
      drawLine(
        color = TitaniumWhite.copy(alpha = 0.35f),
        start = Offset(cx + lineSpan + 3.dp.toPx(), cy),
        end = Offset(cx + lineSpan + 12.dp.toPx(), cy),
        strokeWidth = 1.5.dp.toPx(),
        cap = StrokeCap.Round,
      )

      // Rotating horizon line reflecting physical tilt
      rotate(degrees = -deltaFromLevel, pivot = Offset(cx, cy)) {
        drawLine(
          color = accent,
          start = Offset(cx - lineSpan, cy),
          end = Offset(cx - 10.dp.toPx(), cy),
          strokeWidth = 2.dp.toPx(),
          cap = StrokeCap.Round,
        )
        drawLine(
          color = accent,
          start = Offset(cx + 10.dp.toPx(), cy),
          end = Offset(cx + lineSpan, cy),
          strokeWidth = 2.dp.toPx(),
          cap = StrokeCap.Round,
        )
        drawCircle(
          color = accent,
          radius = 3.dp.toPx(),
          center = Offset(cx, cy),
        )
      }
    }
  }
}

@Composable
fun TimerCountdownOverlay(
  remainingSeconds: Int?,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
    AnimatedVisibility(
      visible = remainingSeconds != null,
      enter = fadeIn() + scaleIn(initialScale = 1.25f),
      exit = fadeOut(),
    ) {
      remainingSeconds?.let { sec ->
        Surface(
          shape = CircleShape,
          color = ObsidianBlack.copy(alpha = 0.6f),
          border = BorderStroke(2.dp, ProAmber),
          modifier = Modifier.size(110.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text(
              text = "$sec",
              style = MaterialTheme.typography.displaySmall,
              color = TitaniumWhite,
            )
          }
        }
      }
    }
  }
}

@Composable
fun FocusReticleOverlay(
  focusPoint: FocusPointState?,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize()) {
    AnimatedVisibility(
      visible = focusPoint != null,
      enter = fadeIn() + scaleIn(initialScale = 1.35f),
      exit = fadeOut(),
    ) {
      focusPoint?.let { point ->
        val reticleSize = 68.dp
        val halfPx = with(LocalDensity.current) { (reticleSize / 2).toPx() }
        val ringColor =
          when (point.isLockedSuccess) {
            true -> OpticalCyan
            false -> ProAmber
            null -> TitaniumWhite
          }

        Canvas(
          modifier =
            Modifier.offset {
                IntOffset(
                  x = (point.x - halfPx).roundToInt(),
                  y = (point.y - halfPx).roundToInt(),
                )
              }
              .size(reticleSize)
        ) {
          drawCircle(
            color = ringColor.copy(alpha = 0.9f),
            radius = size.minDimension / 2f,
            style = Stroke(width = 1.5.dp.toPx()),
          )
          drawCircle(
            color = ringColor,
            radius = 3.dp.toPx(),
            center = Offset(size.width / 2f, size.height / 2f),
          )
        }
      }
    }
  }
}
