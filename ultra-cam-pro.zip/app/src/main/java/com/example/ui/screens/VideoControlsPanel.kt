package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FlashlightOff
import androidx.compose.material.icons.outlined.FlashlightOn
import androidx.compose.material.icons.outlined.HdrOn
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.SlowMotionVideo
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.camera.AppCaptureDomain
import com.example.camera.CameraVideoCapabilities
import com.example.camera.MediaStoreVideoSaver
import com.example.camera.SensorCapabilities
import com.example.camera.StabilizationSelection
import com.example.camera.VideoBitrateOption
import com.example.camera.VideoFpsOption
import com.example.camera.VideoQualityOption
import com.example.camera.VideoRecordingState
import com.example.camera.VideoSettings
import com.example.ui.theme.CaptureEmerald
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.HairlineLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianGlass
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.OpticalCyan
import com.example.ui.theme.ProAmber
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.SilverSecondary
import com.example.ui.theme.TitaniumWhite
import java.util.Locale
import kotlin.math.roundToInt

private val CinemaCrimson = Color(0xFFFF3B30)

@Composable
fun CaptureDomainTogglePill(
  activeDomain: AppCaptureDomain,
  enabled: Boolean,
  onSelectDomain: (AppCaptureDomain) -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = CircleShape,
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier,
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 4.dp, vertical = 3.dp),
      horizontalArrangement = Arrangement.spacedBy(4.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      AppCaptureDomain.entries.forEach { domain ->
        val selected = activeDomain == domain
        val bgColor =
          when {
            selected && domain == AppCaptureDomain.VIDEO -> CinemaCrimson
            selected -> TitaniumWhite
            else -> Color.Transparent
          }
        val fgColor =
          when {
            selected && domain == AppCaptureDomain.VIDEO -> TitaniumWhite
            selected -> ObsidianBlack
            enabled -> TitaniumWhite
            else -> SilverMuted
          }
        Surface(
          onClick = { if (enabled) onSelectDomain(domain) },
          enabled = enabled,
          shape = CircleShape,
          color = bgColor,
          modifier =
            Modifier.minimumInteractiveComponentSize()
              .testTag("capture_mode_${domain.name.lowercase(Locale.US)}"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
          ) {
            Icon(
              imageVector =
                if (domain == AppCaptureDomain.VIDEO) Icons.Outlined.Videocam
                else Icons.Outlined.PhotoCamera,
              contentDescription = domain.label,
              tint = fgColor,
              modifier = Modifier.size(15.dp),
            )
            Text(
              text = domain.label,
              style = MaterialTheme.typography.labelMedium,
              fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
              color = fgColor,
            )
          }
        }
      }
    }
  }
}

@Composable
fun VideoRecordButton(
  isRecording: Boolean,
  isPaused: Boolean,
  isFinalizing: Boolean,
  isCountingDown: Boolean,
  enabled: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by
    animateFloatAsState(
      targetValue = if (isPressed) 0.9f else 1f,
      animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
      label = "videoRecordScale",
    )
  val innerSize by
    animateDpAsState(
      targetValue = if (isRecording) 30.dp else 64.dp,
      animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
      label = "videoInnerSize",
    )
  val innerRadius by
    animateDpAsState(
      targetValue = if (isRecording) 8.dp else 32.dp,
      animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
      label = "videoInnerCorner",
    )
  val ringColor by
    animateColorAsState(
      targetValue =
        when {
          isCountingDown -> ProAmber
          isPaused -> ProAmber
          isRecording -> CinemaCrimson
          else -> TitaniumWhite.copy(alpha = 0.92f)
        },
      label = "videoRingColor",
    )
  val cd =
    if (isRecording) stringResource(R.string.cd_stop_video)
    else stringResource(R.string.cd_record_video)

  Box(
    contentAlignment = Alignment.Center,
    modifier =
      modifier
        .size(82.dp)
        .minimumInteractiveComponentSize()
        .clip(CircleShape)
        .clickable(
          enabled = enabled && (!isFinalizing || isCountingDown),
          interactionSource = interactionSource,
          indication = null,
          role = Role.Button,
          onClick = onClick,
        )
        .semantics { contentDescription = cd }
        .testTag("video_record_button"),
  ) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .border(width = 3.dp, color = ringColor, shape = CircleShape)
    )

    if (isFinalizing) {
      CircularProgressIndicator(
        modifier = Modifier.size(32.dp),
        color = CinemaCrimson,
        strokeWidth = 3.dp,
      )
    } else if (isCountingDown) {
      Box(
        contentAlignment = Alignment.Center,
        modifier =
          Modifier.size(64.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(ProAmber),
      ) {
        Text(
          text = "STOP",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = ObsidianBlack,
        )
      }
    } else {
      Box(
        modifier =
          Modifier.size(innerSize)
            .scale(scale)
            .clip(RoundedCornerShape(innerRadius))
            .background(if (enabled) CinemaCrimson else SilverMuted)
      )
    }
  }
}

@Composable
fun VideoPauseResumeButton(
  isPaused: Boolean,
  enabled: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val cd =
    if (isPaused) stringResource(R.string.cd_resume_video)
    else stringResource(R.string.cd_pause_video)
  Surface(
    shape = CircleShape,
    color = if (isPaused) ProAmber else ObsidianGlass,
    border = BorderStroke(1.5.dp, if (isPaused) ProAmber else HairlineLight),
    modifier = modifier.size(54.dp),
  ) {
    IconButton(
      onClick = onClick,
      enabled = enabled,
      modifier = Modifier.fillMaxSize().testTag("video_pause_resume_button"),
    ) {
      Icon(
        imageVector = if (isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
        contentDescription = cd,
        tint = if (isPaused) ObsidianBlack else TitaniumWhite,
        modifier = Modifier.size(26.dp),
      )
    }
  }
}

@Composable
fun VideoRecordingStatusHud(
  recordingState: VideoRecordingState,
  videoSettings: VideoSettings,
  modifier: Modifier = Modifier,
) {
  val pulseTransition = rememberInfiniteTransition(label = "recPulse")
  val pulseAlpha by
    pulseTransition.animateFloat(
      initialValue = 1f,
      targetValue = 0.25f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(650),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "recDotAlpha",
    )

  val durationText = MediaStoreVideoSaver.formatDurationMs(recordingState.elapsedDurationMs)
  val mbRecorded = recordingState.recordedBytes / (1024.0 * 1024.0)
  val sizeText = String.format(Locale.US, "%.1f MB", mbRecorded)

  Surface(
    shape = CircleShape,
    color = ObsidianBlack.copy(alpha = 0.82f),
    border =
      BorderStroke(
        1.dp,
        if (recordingState.isPaused) ProAmber.copy(alpha = 0.7f)
        else CinemaCrimson.copy(alpha = 0.75f),
      ),
    modifier = modifier.testTag("video_recording_hud"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Box(
        modifier =
          Modifier.size(9.dp)
            .alpha(if (recordingState.isPaused) 1f else pulseAlpha)
            .clip(CircleShape)
            .background(if (recordingState.isPaused) ProAmber else CinemaCrimson)
      )

      Text(
        text = if (recordingState.isPaused) "PAUSED" else "REC",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = if (recordingState.isPaused) ProAmber else CinemaCrimson,
      )

      Text(
        text = durationText,
        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
        color = TitaniumWhite,
        modifier = Modifier.testTag("video_duration_counter"),
      )

      Text(
        text = "· $sizeText",
        style = MaterialTheme.typography.labelSmall,
        color = SilverSecondary,
      )

      if (videoSettings.isAudioEnabled && recordingState.hasAudioTrack) {
        val level = recordingState.audioAmplitude.coerceIn(0f, 1f)
        Row(
          horizontalArrangement = Arrangement.spacedBy(2.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          for (bar in 1..4) {
            val active = level >= (bar * 0.18f)
            Box(
              modifier =
                Modifier.size(width = 3.dp, height = (6 + bar * 2).dp)
                  .clip(RoundedCornerShape(1.dp))
                  .background(if (active) CaptureEmerald else HairlineLight)
            )
          }
        }
      } else {
        Text(
          text = "SILENT",
          style = MaterialTheme.typography.labelSmall,
          color = SilverMuted,
        )
      }
    }
  }
}

@Composable
fun VideoAudioToggleButton(
  isAudioEnabled: Boolean,
  isRecording: Boolean,
  iconRotation: Float,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    onClick = onClick,
    enabled = !isRecording,
    shape = CircleShape,
    color = if (isAudioEnabled) ObsidianGlass else ObsidianBlack.copy(alpha = 0.85f),
    border =
      BorderStroke(
        1.dp,
        if (isAudioEnabled) CaptureEmerald.copy(alpha = 0.6f) else ProAmber.copy(alpha = 0.55f),
      ),
    modifier = modifier.minimumInteractiveComponentSize().testTag("video_audio_toggle_button"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Icon(
        imageVector = if (isAudioEnabled) Icons.Outlined.Mic else Icons.Outlined.MicOff,
        contentDescription = stringResource(R.string.cd_video_audio_toggle),
        tint = if (isAudioEnabled) CaptureEmerald else ProAmber,
        modifier = Modifier.size(18.dp).rotate(iconRotation),
      )
      Text(
        text = if (isAudioEnabled) "MIC" else "SILENT",
        style = MaterialTheme.typography.labelSmall,
        color = if (isAudioEnabled) TitaniumWhite else ProAmber,
      )
    }
  }
}

@Composable
fun VideoTorchButton(
  isTorchEnabled: Boolean,
  iconRotation: Float,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = CircleShape,
    color = if (isTorchEnabled) ProAmber else ObsidianGlass,
    border = BorderStroke(1.dp, if (isTorchEnabled) ProAmber else HairlineLight),
    modifier = modifier.size(48.dp),
  ) {
    IconButton(
      onClick = onClick,
      modifier = Modifier.fillMaxSize().testTag("video_torch_button"),
    ) {
      Icon(
        imageVector =
          if (isTorchEnabled) Icons.Outlined.FlashlightOn else Icons.Outlined.FlashlightOff,
        contentDescription = stringResource(R.string.cd_video_torch),
        tint = if (isTorchEnabled) ObsidianBlack else TitaniumWhite,
        modifier = Modifier.size(20.dp).rotate(iconRotation),
      )
    }
  }
}

@Composable
fun VideoQuickSpecPill(
  settings: VideoSettings,
  capabilities: CameraVideoCapabilities,
  isSettingsOpen: Boolean,
  enabled: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val hdrTag = if (settings.isHdrEnabled) " · ${capabilities.hdrAvailability.label}" else ""
  val bitrateTag =
    if (settings.bitrate != VideoBitrateOption.AUTO) " · ${settings.bitrate.label}" else ""
  val specText = "${settings.quality.shortLabel} · ${settings.fps.fps}fps$hdrTag$bitrateTag"

  Surface(
    onClick = onClick,
    enabled = enabled,
    shape = CircleShape,
    color = if (isSettingsOpen) ProAmber else ObsidianGlass,
    border = BorderStroke(1.dp, if (isSettingsOpen) ProAmber else HairlineLight),
    modifier = modifier.minimumInteractiveComponentSize().testTag("video_spec_pill"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Icon(
        imageVector = Icons.Outlined.Tune,
        contentDescription = stringResource(R.string.cd_video_settings),
        tint = if (isSettingsOpen) ObsidianBlack else OpticalCyan,
        modifier = Modifier.size(16.dp),
      )
      Text(
        text = specText,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.SemiBold,
        color = if (isSettingsOpen) ObsidianBlack else TitaniumWhite,
      )
    }
  }
}

@Composable
fun VideoSettingsDeck(
  settings: VideoSettings,
  capabilities: CameraVideoCapabilities,
  sensorCapabilities: SensorCapabilities,
  onSelectQuality: (VideoQualityOption) -> Unit,
  onSelectFps: (VideoFpsOption) -> Unit,
  onSelectBitrate: (VideoBitrateOption) -> Unit,
  onToggleHdr: () -> Unit,
  onSelectStabilization: (StabilizationSelection) -> Unit,
  onToggleAudio: () -> Unit,
  onToggleSlowMoBaked: () -> Unit,
  onExposureCompChange: (Int) -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(20.dp),
    color = ObsidianSurface.copy(alpha = 0.94f),
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.fillMaxWidth().testTag("video_settings_deck"),
  ) {
    Column(
      modifier = Modifier.verticalScroll(rememberScrollState()).padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      // Resolution / Quality selector
      VideoSectionHeader(
        title = stringResource(R.string.video_quality_label),
        detail = capabilities.availabilityOf(settings.quality).reason,
      )
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        VideoQualityOption.entries.forEach { q ->
          val avail = capabilities.availabilityOf(q)
          VideoOptionChip(
            label = q.shortLabel,
            selected = settings.quality == q,
            supported = avail.isSupported,
            onClick = { onSelectQuality(q) },
            testTag = "video_quality_${q.name.lowercase(Locale.US)}",
          )
        }
      }

      // Frame Rate (24, 30, 60, 120, 240)
      VideoSectionHeader(
        title = stringResource(R.string.video_fps_label),
        detail = capabilities.availabilityOf(settings.fps).reason,
      )
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        VideoFpsOption.entries.forEach { fps ->
          val avail = capabilities.availabilityOf(fps)
          VideoOptionChip(
            label = "${fps.label}fps",
            selected = settings.fps == fps,
            supported = avail.isSupported,
            onClick = { onSelectFps(fps) },
            testTag = "video_fps_${fps.fps}",
          )
        }
      }

      if (settings.fps.isHighSpeed) {
        Surface(
          onClick = onToggleSlowMoBaked,
          shape = RoundedCornerShape(12.dp),
          color = ObsidianGlass,
          border = BorderStroke(1.dp, HairlineLight),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Icon(
                imageVector = Icons.Outlined.SlowMotionVideo,
                contentDescription = null,
                tint = OpticalCyan,
                modifier = Modifier.size(16.dp),
              )
              Text(
                text =
                  if (settings.isSlowMotionBakedIn) "Slow-Mo Playback (30fps output)"
                  else "Native High-Frame-Rate (${settings.fps.fps}fps file)",
                style = MaterialTheme.typography.labelSmall,
                color = TitaniumWhite,
              )
            }
            Text(
              text = if (settings.isSlowMotionBakedIn) "SLOW-MO" else "HFR",
              style = MaterialTheme.typography.labelSmall,
              color = ProAmber,
            )
          }
        }
      }

      // Bitrate Selection
      val maxMbps = capabilities.maxEncoderBitrateBps / 1_000_000
      VideoSectionHeader(
        title = stringResource(R.string.video_bitrate_label),
        detail =
          if (settings.bitrate == VideoBitrateOption.AUTO) "Encoder Auto (max ${maxMbps}Mbps)"
          else "${settings.bitrate.label}bps target encoding",
      )
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        VideoBitrateOption.entries.forEach { br ->
          VideoOptionChip(
            label = br.label,
            selected = settings.bitrate == br,
            supported = capabilities.isBitrateSupported(br),
            onClick = { onSelectBitrate(br) },
            testTag = "video_bitrate_${br.name.lowercase(Locale.US)}",
          )
        }
      }

      // Stabilization + Video HDR + Audio Track Row
      VideoSectionHeader(
        title = stringResource(R.string.video_pipeline_label),
        detail = capabilities.hdrAvailability.reason,
      )
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        StabilizationSelection.entries.forEach { stab ->
          val supported =
            when (stab) {
              StabilizationSelection.AUTO,
              StabilizationSelection.OFF -> true
              StabilizationSelection.OIS -> capabilities.isOisSupported
              StabilizationSelection.EIS -> capabilities.isEisSupported
            }
          VideoOptionChip(
            label = "STAB ${stab.label}",
            selected = settings.stabilization == stab,
            supported = supported,
            onClick = { onSelectStabilization(stab) },
            testTag = "video_stab_${stab.name.lowercase(Locale.US)}",
          )
        }

        val hdrAllowed =
          capabilities.hdrAvailability.isSupported && !settings.fps.isHighSpeed
        VideoOptionChip(
          label =
            if (capabilities.hdrAvailability.isSupported) "HDR ${capabilities.hdrAvailability.label}"
            else "HDR",
          selected = settings.isHdrEnabled,
          supported = hdrAllowed,
          icon = Icons.Outlined.HdrOn,
          onClick = onToggleHdr,
          testTag = "video_hdr_toggle",
        )

        VideoOptionChip(
          label = if (settings.isAudioEnabled) "Audio ON" else "Silent Video",
          selected = !settings.isAudioEnabled,
          supported = true,
          icon = if (settings.isAudioEnabled) Icons.Outlined.Mic else Icons.Outlined.MicOff,
          onClick = onToggleAudio,
          testTag = "video_audio_option",
        )
      }

      // Exposure Compensation Control (EV) in Video Mode
      val evRange = sensorCapabilities.exposureRange
      if (evRange.first < evRange.last) {
        val evValue = sensorCapabilities.currentExposureIndex * sensorCapabilities.exposureStep
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = stringResource(R.string.pro_ev_label),
            style = MaterialTheme.typography.labelMedium,
            color = SilverSecondary,
          )
          Text(
            text = String.format(Locale.US, "%+.1f EV", evValue),
            style = MaterialTheme.typography.labelMedium,
            color = if (sensorCapabilities.currentExposureIndex == 0) TitaniumWhite else ProAmber,
          )
        }
        Slider(
          value = sensorCapabilities.currentExposureIndex.toFloat(),
          onValueChange = { onExposureCompChange(it.roundToInt()) },
          valueRange = evRange.first.toFloat()..evRange.last.toFloat(),
          colors =
            SliderDefaults.colors(
              thumbColor = TitaniumWhite,
              activeTrackColor = ProAmber,
              inactiveTrackColor = HairlineLight,
            ),
          modifier = Modifier.fillMaxWidth().height(28.dp).testTag("video_ev_slider"),
        )
      }
    }
  }
}

@Composable
private fun VideoSectionHeader(
  title: String,
  detail: String,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.labelMedium,
      color = TitaniumWhite,
    )
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = detail,
      style = MaterialTheme.typography.labelSmall,
      color = SilverSecondary,
      maxLines = 1,
    )
  }
}

@Composable
private fun VideoOptionChip(
  label: String,
  selected: Boolean,
  supported: Boolean,
  onClick: () -> Unit,
  testTag: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
) {
  val bgColor =
    when {
      selected -> ProAmber
      supported -> ObsidianGlass
      else -> ObsidianBlack.copy(alpha = 0.6f)
    }
  val borderColor =
    when {
      selected -> ProAmber
      supported -> HairlineLight
      else -> HairlineLight.copy(alpha = 0.35f)
    }
  val textColor =
    when {
      selected -> ObsidianBlack
      supported -> TitaniumWhite
      else -> SilverMuted
    }

  Surface(
    shape = CircleShape,
    color = bgColor,
    border = BorderStroke(1.dp, borderColor),
    modifier =
      Modifier.minimumInteractiveComponentSize()
        .clip(CircleShape)
        .clickable(onClick = onClick)
        .testTag(testTag),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      if (!supported) {
        Icon(
          imageVector = Icons.Outlined.Lock,
          contentDescription = "Unavailable",
          tint = SilverMuted,
          modifier = Modifier.size(13.dp),
        )
      } else if (icon != null) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = textColor,
          modifier = Modifier.size(14.dp),
        )
      }
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        color = textColor,
      )
    }
  }
}
