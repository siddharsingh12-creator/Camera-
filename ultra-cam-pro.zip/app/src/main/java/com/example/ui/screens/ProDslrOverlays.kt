package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.camera.CameraHardwareProfile
import com.example.camera.FocusPeakingColor
import com.example.camera.FrameAnalysisData
import com.example.camera.LiveExposureTelemetry
import com.example.camera.ManualProSettings
import com.example.camera.SensorCapabilities
import com.example.camera.WhiteBalanceOption
import com.example.ui.theme.CaptureEmerald
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.HairlineLight
import com.example.ui.theme.HairlineSubtle
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianGlass
import com.example.ui.theme.OpticalCyan
import com.example.ui.theme.ProAmber
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.SilverSecondary
import com.example.ui.theme.TitaniumWhite
import java.util.Locale

@Composable
fun ProExposureInfoBar(
  profile: CameraHardwareProfile?,
  sensorCapabilities: SensorCapabilities,
  manualSettings: ManualProSettings,
  liveTelemetry: LiveExposureTelemetry,
  onSelectProTab: (com.example.camera.ProControlTab) -> Unit,
  modifier: Modifier = Modifier,
) {
  val exp = profile?.exposureAndRaw
  val isManualAe =
    exp?.isManualExposureSupported == true &&
      (manualSettings.isManualIsoEnabled || manualSettings.isManualShutterEnabled)

  val isoValue =
    if (manualSettings.isManualIsoEnabled && manualSettings.manualIso != null) {
      "ISO ${manualSettings.manualIso}"
    } else if (liveTelemetry.iso != null) {
      "ISO ${liveTelemetry.iso}"
    } else {
      "ISO AUTO"
    }

  val shutterNs =
    if (manualSettings.isManualShutterEnabled && manualSettings.manualShutterNs != null) {
      manualSettings.manualShutterNs
    } else {
      liveTelemetry.shutterNs
    }
  val shutterValue = shutterNs?.let { formatShutterSpeed(it) } ?: "SS AUTO"

  val apertureVal = liveTelemetry.aperture ?: profile?.apertures?.firstOrNull()
  val apertureText = apertureVal?.let { String.format(Locale.US, "f/%.1f", it) }

  val evStep = sensorCapabilities.exposureStep.takeIf { it > 0f } ?: (1f / 3f)
  val evText =
    if (isManualAe) {
      "EV M"
    } else if (sensorCapabilities.exposureRange.first >= sensorCapabilities.exposureRange.last) {
      "EV —"
    } else {
      val idx = sensorCapabilities.currentExposureIndex
      if (idx == 0) "0.0 EV" else String.format(Locale.US, "%+.1f EV", idx * evStep)
    }

  val wbText =
    when (manualSettings.whiteBalanceMode) {
      WhiteBalanceOption.MANUAL_KELVIN -> "${manualSettings.manualKelvin}K"
      else -> manualSettings.whiteBalanceMode.shortTag
    }

  val focusText =
    if (manualSettings.isManualFocusEnabled) {
      val d = manualSettings.manualFocusDiopters
      if (d <= 0.05f) "MF ∞"
      else {
        val cm = 100f / d
        if (cm >= 100f) String.format(Locale.US, "MF %.1fm", cm / 100f)
        else String.format(Locale.US, "MF %.0fcm", cm)
      }
    } else {
      val liveD = liveTelemetry.focusDistanceDiopters
      if (liveD != null && liveD > 0.05f) {
        val cm = 100f / liveD
        if (cm >= 100f) String.format(Locale.US, "AF %.1fm", cm / 100f)
        else String.format(Locale.US, "AF %.0fcm", cm)
      } else {
        "AF"
      }
    }

  Surface(
    shape = RoundedCornerShape(14.dp),
    color = ObsidianBlack.copy(alpha = 0.78f),
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.fillMaxWidth().testTag("pro_exposure_info_bar"),
  ) {
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .horizontalScroll(rememberScrollState())
          .padding(horizontal = 10.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      MeterCell(
        text = isoValue,
        accent =
          when {
            manualSettings.isManualIsoEnabled -> ProAmber
            liveTelemetry.iso != null -> TitaniumWhite
            else -> SilverSecondary
          },
        onClick = { onSelectProTab(com.example.camera.ProControlTab.ISO) },
      )
      MeterDivider()
      MeterCell(
        text = shutterValue,
        accent =
          when {
            manualSettings.isManualShutterEnabled -> ProAmber
            liveTelemetry.shutterNs != null -> TitaniumWhite
            else -> SilverSecondary
          },
        onClick = { onSelectProTab(com.example.camera.ProControlTab.SHUTTER) },
      )
      if (apertureText != null) {
        MeterDivider()
        MeterCell(text = apertureText, accent = SilverSecondary, onClick = null)
      }
      MeterDivider()
      MeterCell(
        text = evText,
        accent = if (!isManualAe && sensorCapabilities.currentExposureIndex != 0) OpticalCyan else TitaniumWhite,
        onClick = { onSelectProTab(com.example.camera.ProControlTab.EV) },
      )
      MeterDivider()
      MeterCell(
        text = wbText,
        accent =
          if (manualSettings.whiteBalanceMode != WhiteBalanceOption.AUTO) ProAmber else TitaniumWhite,
        onClick = { onSelectProTab(com.example.camera.ProControlTab.WB) },
      )
      MeterDivider()
      MeterCell(
        text = focusText,
        accent = if (manualSettings.isManualFocusEnabled) OpticalCyan else TitaniumWhite,
        onClick = { onSelectProTab(com.example.camera.ProControlTab.FOCUS) },
      )
      MeterDivider()
      MeterCell(
        text = manualSettings.captureOutputFormat.shortTag,
        accent =
          if (manualSettings.isRawCaptureEnabled) ProAmber else CaptureEmerald,
        onClick = { onSelectProTab(com.example.camera.ProControlTab.FORMAT) },
      )
      if (manualSettings.isExposureLockEnabled) {
        Surface(
          shape = CircleShape,
          color = ProAmber.copy(alpha = 0.2f),
          border = BorderStroke(1.dp, ProAmber),
        ) {
          Text(
            text = "AE-L",
            style = MaterialTheme.typography.labelSmall,
            color = ProAmber,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun MeterCell(
  text: String,
  accent: Color,
  onClick: (() -> Unit)?,
) {
  if (onClick != null) {
    Surface(
      onClick = onClick,
      color = Color.Transparent,
      shape = RoundedCornerShape(6.dp),
    ) {
      Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        color = accent,
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
      )
    }
  } else {
    Text(
      text = text,
      style = MaterialTheme.typography.labelMedium,
      color = accent,
      modifier = Modifier.padding(horizontal = 2.dp, vertical = 2.dp),
    )
  }
}

@Composable
private fun MeterDivider() {
  Text(
    text = "·",
    style = MaterialTheme.typography.labelSmall,
    color = SilverMuted,
  )
}

@Composable
fun FocusPeakingOverlay(
  points: FloatArray,
  peakingColor: FocusPeakingColor,
  modifier: Modifier = Modifier,
) {
  val strokeColor =
    when (peakingColor) {
      FocusPeakingColor.CYAN -> OpticalCyan
      FocusPeakingColor.RED -> ErrorCoral
      FocusPeakingColor.YELLOW -> ProAmber
    }

  Canvas(modifier = modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height
    val markerLen = 3.dp.toPx()
    val strokeW = 1.6.dp.toPx()
    var i = 0
    while (i + 1 < points.size) {
      val px = points[i] * w
      val py = points[i + 1] * h
      drawLine(
        color = strokeColor.copy(alpha = 0.88f),
        start = Offset(px - markerLen, py),
        end = Offset(px + markerLen, py),
        strokeWidth = strokeW,
        cap = StrokeCap.Round,
      )
      drawLine(
        color = strokeColor.copy(alpha = 0.88f),
        start = Offset(px, py - markerLen),
        end = Offset(px, py + markerLen),
        strokeWidth = strokeW,
        cap = StrokeCap.Round,
      )
      i += 2
    }
  }
}

@Composable
fun ZebraExposureOverlay(
  highlightPoints: FloatArray,
  shadowPoints: FloatArray,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height
    val stripeHalf = 4.dp.toPx()
    val strokeW = 1.5.dp.toPx()

    // Overexposed highlight clipping warning stripes
    var i = 0
    while (i + 1 < highlightPoints.size) {
      val px = highlightPoints[i] * w
      val py = highlightPoints[i + 1] * h
      drawLine(
        color = ErrorCoral.copy(alpha = 0.78f),
        start = Offset(px - stripeHalf, py + stripeHalf),
        end = Offset(px + stripeHalf, py - stripeHalf),
        strokeWidth = strokeW,
        cap = StrokeCap.Round,
      )
      i += 2
    }

    // Shadow crush warning stripes
    var j = 0
    while (j + 1 < shadowPoints.size) {
      val px = shadowPoints[j] * w
      val py = shadowPoints[j + 1] * h
      drawLine(
        color = OpticalCyan.copy(alpha = 0.55f),
        start = Offset(px - stripeHalf, py - stripeHalf),
        end = Offset(px + stripeHalf, py + stripeHalf),
        strokeWidth = 1.1.dp.toPx(),
        cap = StrokeCap.Round,
      )
      j += 2
    }
  }
}

@Composable
fun LiveHistogramCard(
  analysis: FrameAnalysisData?,
  zebraThresholdPercent: Int,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = ObsidianGlass,
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.width(156.dp).testTag("live_histogram_card"),
  ) {
    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        val shPct = analysis?.shadowClippedPercent ?: 0f
        val hiPct = analysis?.highlightClippedPercent ?: 0f
        Text(
          text = String.format(Locale.US, "SH %.0f%%", shPct),
          style = MaterialTheme.typography.labelSmall,
          color = if (shPct >= 5f) OpticalCyan else SilverMuted,
        )
        Text(
          text = "RGB",
          style = MaterialTheme.typography.labelSmall,
          color = SilverSecondary,
        )
        Text(
          text = String.format(Locale.US, "HI %.0f%%", hiPct),
          style = MaterialTheme.typography.labelSmall,
          color = if (hiPct >= 2f) ErrorCoral else SilverMuted,
        )
      }

      Spacer(modifier = Modifier.height(4.dp))

      Canvas(modifier = Modifier.fillMaxWidth().height(54.dp)) {
        val w = size.width
        val h = size.height

        // Subtle DSLR exposure zone grid lines (25%, 50%, 75%)
        val gridLineColor = HairlineSubtle
        for (q in 1..3) {
          val gx = (w * q) / 4f
          drawLine(gridLineColor, Offset(gx, 0f), Offset(gx, h), strokeWidth = 0.8.dp.toPx())
        }

        // Highlight zebra threshold line
        val thresholdX = (zebraThresholdPercent.coerceIn(75, 100) / 100f) * w
        drawLine(
          color = ProAmber.copy(alpha = 0.45f),
          start = Offset(thresholdX, 0f),
          end = Offset(thresholdX, h),
          strokeWidth = 1.dp.toPx(),
        )

        if (analysis != null && analysis.lumaBins.isNotEmpty()) {
          val n = analysis.lumaBins.size
          val lumaFill = Path().apply {
            moveTo(0f, h)
            for (i in 0 until n) {
              val x = (i.toFloat() / (n - 1).coerceAtLeast(1)) * w
              val y = h - (analysis.lumaBins[i] * h * 0.92f)
              lineTo(x, y)
            }
            lineTo(w, h)
            close()
          }
          drawPath(path = lumaFill, color = TitaniumWhite.copy(alpha = 0.24f))

          drawChannelStroke(analysis.redBins, Color(0xCCEF4444), w, h)
          drawChannelStroke(analysis.greenBins, Color(0xCC22C55E), w, h)
          drawChannelStroke(analysis.blueBins, Color(0xCC3B82F6), w, h)
        }
      }
    }
  }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawChannelStroke(
  bins: FloatArray,
  color: Color,
  w: Float,
  h: Float,
) {
  if (bins.size < 2) return
  val path = Path()
  for (i in bins.indices) {
    val x = (i.toFloat() / (bins.size - 1)) * w
    val y = h - (bins[i] * h * 0.92f)
    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
  }
  drawPath(path = path, color = color, style = Stroke(width = 1.25.dp.toPx()))
}
