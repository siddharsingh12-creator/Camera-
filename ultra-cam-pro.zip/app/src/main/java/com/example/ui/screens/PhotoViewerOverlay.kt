package com.example.ui.screens

import android.content.Intent
import android.media.MediaPlayer
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.camera.CapturedPhotoInfo
import com.example.camera.MediaStoreVideoSaver
import com.example.ui.theme.CaptureEmerald
import com.example.ui.theme.HairlineLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianGlass
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.OpticalCyan
import com.example.ui.theme.ProAmber
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.TitaniumWhite
import java.util.Locale
import kotlinx.coroutines.delay

@Composable
fun PhotoViewerOverlay(
  photo: CapturedPhotoInfo,
  onClose: () -> Unit,
  onOpenInSystemGallery: (CapturedPhotoInfo) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  BackHandler(onBack = onClose)

  var scale by remember(photo.uri) { mutableFloatStateOf(1f) }
  var offset by remember(photo.uri) { mutableStateOf(Offset.Zero) }

  // Video playback state when photo.isVideo == true
  var videoViewRef by remember(photo.uri) { mutableStateOf<VideoView?>(null) }
  var isVideoPlaying by remember(photo.uri) { mutableStateOf(false) }
  var videoPositionMs by remember(photo.uri) { mutableIntStateOf(0) }
  var videoTotalMs by remember(photo.uri) {
    mutableIntStateOf(photo.durationMs.toInt().coerceAtLeast(0))
  }

  LaunchedEffect(photo.uri, isVideoPlaying, videoViewRef) {
    val vv = videoViewRef ?: return@LaunchedEffect
    while (isVideoPlaying) {
      videoPositionMs = runCatching { vv.currentPosition }.getOrDefault(videoPositionMs)
      delay(200L)
    }
  }

  DisposableEffect(photo.uri) {
    onDispose {
      runCatching { videoViewRef?.stopPlayback() }
    }
  }

  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(ObsidianBlack)
  ) {
    if (photo.isVideo) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxSize().padding(bottom = 170.dp),
      ) {
        AndroidView(
          factory = { ctx ->
            VideoView(ctx).apply {
              setVideoURI(photo.uri)
              setOnPreparedListener { mp: MediaPlayer ->
                mp.isLooping = false
                if (mp.duration > 0) videoTotalMs = mp.duration
                start()
                isVideoPlaying = true
              }
              setOnCompletionListener {
                isVideoPlaying = false
                videoPositionMs = videoTotalMs
              }
              videoViewRef = this
            }
          },
          modifier = Modifier.fillMaxSize(),
        )

        // Centered Play / Pause overlay toggle
        Surface(
          shape = CircleShape,
          color = ObsidianBlack.copy(alpha = 0.58f),
          border = BorderStroke(1.5.dp, TitaniumWhite.copy(alpha = 0.7f)),
          modifier = Modifier.size(64.dp),
        ) {
          IconButton(
            onClick = {
              val vv = videoViewRef ?: return@IconButton
              if (vv.isPlaying) {
                vv.pause()
                isVideoPlaying = false
              } else {
                if (videoPositionMs >= videoTotalMs && videoTotalMs > 0) {
                  vv.seekTo(0)
                  videoPositionMs = 0
                }
                vv.start()
                isVideoPlaying = true
              }
            },
            modifier = Modifier.fillMaxSize().testTag("video_player_play_pause"),
          ) {
            Icon(
              imageVector = if (isVideoPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
              contentDescription = if (isVideoPlaying) "Pause" else "Play",
              tint = TitaniumWhite,
              modifier = Modifier.size(34.dp),
            )
          }
        }
      }
    } else {
      // Interactive pinch-to-zoom full photo canvas
      AsyncImage(
        model =
          ImageRequest.Builder(context)
            .data(photo.uri)
            .crossfade(true)
            .build(),
        contentDescription = photo.displayName,
        contentScale = ContentScale.Fit,
        modifier =
          Modifier.fillMaxSize()
            .pointerInput(photo.uri) {
              detectTapGestures(
                onDoubleTap = {
                  if (scale > 1.2f) {
                    scale = 1f
                    offset = Offset.Zero
                  } else {
                    scale = 2.5f
                  }
                }
              )
            }
            .pointerInput(photo.uri) {
              detectTransformGestures { _, pan, zoom, _ ->
                val nextScale = (scale * zoom).coerceIn(1f, 5f)
                scale = nextScale
                offset =
                  if (nextScale > 1f) {
                    offset + pan
                  } else {
                    Offset.Zero
                  }
              }
            }
            .graphicsLayer {
              scaleX = scale
              scaleY = scale
              translationX = offset.x
              translationY = offset.y
            },
      )
    }

    // Top gradient bar with back button and title
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .align(Alignment.TopCenter)
          .background(
            Brush.verticalGradient(
              colors = listOf(ObsidianBlack.copy(alpha = 0.85f), Color.Transparent)
            )
          )
          .statusBarsPadding()
          .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Surface(
          shape = CircleShape,
          color = ObsidianGlass,
          border = BorderStroke(1.dp, HairlineLight),
        ) {
          IconButton(
            onClick = onClose,
            modifier = Modifier.size(48.dp).testTag("close_photo_viewer_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
              contentDescription = stringResource(R.string.cd_close_preview),
              tint = TitaniumWhite,
            )
          }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text =
              if (photo.isVideo) stringResource(R.string.video_viewer_title)
              else stringResource(R.string.photo_viewer_title),
            style = MaterialTheme.typography.titleMedium,
            color = TitaniumWhite,
          )
          Text(
            text = photo.displayName,
            style = MaterialTheme.typography.labelMedium,
            color = SilverMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }

    // Bottom Inspector & Playback / Actions
    Surface(
      shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
      color = ObsidianSurface.copy(alpha = 0.94f),
      border = BorderStroke(1.dp, HairlineLight),
      modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
    ) {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 18.dp)
      ) {
        if (photo.isVideo && videoTotalMs > 0) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text(
              text = MediaStoreVideoSaver.formatDurationMs(videoPositionMs.toLong()),
              style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
              color = TitaniumWhite,
            )
            Slider(
              value = videoPositionMs.toFloat().coerceIn(0f, videoTotalMs.toFloat()),
              onValueChange = { pos ->
                val targetMs = pos.toInt()
                videoPositionMs = targetMs
                videoViewRef?.seekTo(targetMs)
              },
              valueRange = 0f..videoTotalMs.toFloat(),
              colors =
                SliderDefaults.colors(
                  thumbColor = TitaniumWhite,
                  activeTrackColor = OpticalCyan,
                  inactiveTrackColor = HairlineLight,
                ),
              modifier = Modifier.weight(1f).height(26.dp),
            )
            Text(
              text = MediaStoreVideoSaver.formatDurationMs(videoTotalMs.toLong()),
              style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
              color = SilverMuted,
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(
              text = stringResource(R.string.photo_viewer_resolution_label),
              style = MaterialTheme.typography.labelSmall,
              color = SilverMuted,
            )
            Spacer(modifier = Modifier.height(4.dp))
            val isDng = photo.displayName.endsWith(".dng", ignoreCase = true)
            val resText =
              when {
                photo.width > 0 && photo.height > 0 -> "${photo.width} × ${photo.height} px"
                photo.isVideo -> "Native Video"
                isDng -> "RAW DNG"
                else -> "Native JPEG"
              }
            Text(
              text = resText,
              style = MaterialTheme.typography.titleMedium,
              color = TitaniumWhite,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text =
                if (photo.isVideo) stringResource(R.string.video_saved_gallery_path)
                else stringResource(R.string.status_saved_gallery_path),
              style = MaterialTheme.typography.labelSmall,
              color = OpticalCyan,
            )
          }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (photo.isVideo) {
              val badgeText =
                buildString {
                  if (photo.videoFrameRate != null) append("${photo.videoFrameRate}fps")
                  if (photo.isHdrVideo) {
                    if (isNotEmpty()) append(" · ")
                    append("HDR")
                  }
                  if (isEmpty()) append("MP4")
                }
              Surface(
                shape = CircleShape,
                color = CaptureEmerald.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, CaptureEmerald.copy(alpha = 0.35f)),
              ) {
                Text(
                  text = badgeText,
                  style = MaterialTheme.typography.labelMedium,
                  color = CaptureEmerald,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                )
              }
            } else if (photo.width > 0 && photo.height > 0) {
              Surface(
                shape = CircleShape,
                color = OpticalCyan.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, OpticalCyan.copy(alpha = 0.35f)),
              ) {
                Text(
                  text = String.format(Locale.US, "%.1f MP", photo.megapixels),
                  style = MaterialTheme.typography.labelMedium,
                  color = OpticalCyan,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                )
              }
            }
            if (photo.sizeBytes > 0L) {
              Surface(
                shape = CircleShape,
                color = ObsidianBlack,
                border = BorderStroke(1.dp, HairlineLight),
              ) {
                val mb = photo.sizeBytes / (1024.0 * 1024.0)
                val sizeLabel =
                  if (mb >= 1.0) String.format(Locale.US, "%.2f MB", mb)
                  else String.format(Locale.US, "%d KB", photo.sizeBytes / 1024L)
                Text(
                  text = sizeLabel,
                  style = MaterialTheme.typography.labelMedium,
                  color = TitaniumWhite,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          OutlinedButton(
            onClick = {
              val shareMime =
                when {
                  photo.isVideo -> "video/mp4"
                  photo.displayName.endsWith(".dng", ignoreCase = true) -> "image/x-adobe-dng"
                  else -> "image/jpeg"
                }
              val shareIntent =
                Intent(Intent.ACTION_SEND).apply {
                  type = shareMime
                  putExtra(Intent.EXTRA_STREAM, photo.uri)
                  addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
              context.startActivity(Intent.createChooser(shareIntent, photo.displayName))
            },
            shape = CircleShape,
            border = BorderStroke(1.dp, HairlineLight),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TitaniumWhite),
            modifier = Modifier.weight(1f).height(50.dp).testTag("share_photo_button"),
          ) {
            Icon(
              imageVector = Icons.Outlined.Share,
              contentDescription = stringResource(R.string.cd_share_photo),
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.photo_viewer_share),
              style = MaterialTheme.typography.labelLarge,
            )
          }

          Button(
            onClick = { onOpenInSystemGallery(photo) },
            shape = CircleShape,
            colors =
              ButtonDefaults.buttonColors(
                containerColor = TitaniumWhite,
                contentColor = ObsidianBlack,
              ),
            modifier = Modifier.weight(1.3f).height(50.dp).testTag("open_in_gallery_button"),
          ) {
            Icon(
              imageVector = Icons.Outlined.PhotoLibrary,
              contentDescription = stringResource(R.string.cd_open_in_gallery),
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.photo_viewer_open_system_gallery),
              style = MaterialTheme.typography.labelLarge,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }
  }
}
