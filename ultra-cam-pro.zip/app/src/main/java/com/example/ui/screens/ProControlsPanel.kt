package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CenterFocusStrong
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FlipCameraAndroid
import androidx.compose.material.icons.outlined.GridOff
import androidx.compose.material.icons.outlined.GridOn
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Straighten
import androidx.compose.material.icons.outlined.VolumeOff
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.camera.CameraHardwareProfile
import com.example.camera.CaptureOutputFormat
import com.example.camera.LiveExposureTelemetry
import com.example.camera.ManualProSettings
import com.example.camera.ProControlTab
import com.example.camera.ProPreset
import com.example.camera.SensorCapabilities
import com.example.camera.StabilizationSelection
import com.example.camera.WhiteBalanceOption
import com.example.ui.theme.CaptureEmerald
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.HairlineLight
import com.example.ui.theme.HairlineSubtle
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.OpticalCyan
import com.example.ui.theme.ProAmber
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.SilverSecondary
import com.example.ui.theme.TitaniumWhite
import java.util.Locale
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProControlsPanel(
  profile: CameraHardwareProfile?,
  sensorCapabilities: SensorCapabilities,
  settings: ManualProSettings,
  liveTelemetry: LiveExposureTelemetry,
  customPresets: List<ProPreset>,
  hasLevelSensor: Boolean,
  isFrontCamera: Boolean,
  isGridEnabled: Boolean,
  isLevelEnabled: Boolean,
  isFrontMirrorEnabled: Boolean,
  isVolumeShutterEnabled: Boolean,
  onSelectProTab: (ProControlTab) -> Unit,
  onSetManualIso: (Boolean, Int?) -> Unit,
  onSetManualShutter: (Boolean, Long?) -> Unit,
  onSetWhiteBalance: (WhiteBalanceOption) -> Unit,
  onSetManualKelvin: (Int) -> Unit,
  onSetManualFocus: (Boolean, Float?) -> Unit,
  onExposureCompChange: (Int) -> Unit,
  onSelectCaptureFormat: (CaptureOutputFormat) -> Unit,
  onToggleExposureLock: () -> Unit,
  onSelectStabilization: (StabilizationSelection) -> Unit,
  onToggleFocusPeaking: () -> Unit,
  onCycleFocusPeakingColor: () -> Unit,
  onToggleHistogram: () -> Unit,
  onToggleZebra: () -> Unit,
  onSetZebraThreshold: (Int) -> Unit,
  onToggleGrid: () -> Unit,
  onToggleLevel: () -> Unit,
  onToggleFrontMirror: () -> Unit,
  onToggleVolumeShutter: () -> Unit,
  onSavePreset: (String) -> Unit,
  onApplyPreset: (ProPreset) -> Unit,
  onDeletePreset: (String) -> Unit,
  onResetAllToAuto: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var showSavePresetDialog by remember { mutableStateOf(false) }
  var presetDraftName by remember { mutableStateOf("") }

  val exp = profile?.exposureAndRaw
  val focus = profile?.focusCapabilities
  val stab = profile?.videoAndStabilization
  val evRange = sensorCapabilities.exposureRange

  if (showSavePresetDialog) {
    AlertDialog(
      onDismissRequest = { showSavePresetDialog = false },
      containerColor = ObsidianSurface,
      titleContentColor = TitaniumWhite,
      textContentColor = SilverSecondary,
      title = {
        Text(
          text = stringResource(R.string.pro_save_preset_btn),
          style = MaterialTheme.typography.titleMedium,
        )
      },
      text = {
        OutlinedTextField(
          value = presetDraftName,
          onValueChange = { presetDraftName = it },
          singleLine = true,
          placeholder = {
            Text(
              text = stringResource(R.string.pro_preset_name_hint),
              style = MaterialTheme.typography.bodyMedium,
              color = SilverMuted,
            )
          },
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val chosen =
              presetDraftName.trim().ifEmpty { "Custom ${customPresets.size + 1}" }
            onSavePreset(chosen)
            presetDraftName = ""
            showSavePresetDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = ProAmber, contentColor = ObsidianBlack),
        ) {
          Text("Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { showSavePresetDialog = false }) {
          Text("Cancel", color = SilverSecondary)
        }
      },
    )
  }

  Surface(
    shape = RoundedCornerShape(20.dp),
    color = ObsidianSurface.copy(alpha = 0.95f),
    border = BorderStroke(1.dp, HairlineLight),
    modifier = modifier.fillMaxWidth().testTag("pro_controls_panel"),
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 14.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      // Header Bar: DSLR Mode Status + Hardware Level + Reset Auto
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = stringResource(R.string.pro_controls_title),
            style = MaterialTheme.typography.titleMedium,
            color = TitaniumWhite,
          )
          if (profile != null) {
            Text(
              text =
                "CAM ${profile.cameraId} · ${profile.hardwareLevel.displayName} · ${if (exp?.isManualExposureSupported == true) "MANUAL_SENSOR" else "AUTO SENSOR"}",
              style = MaterialTheme.typography.labelSmall,
              color = OpticalCyan,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }

        Surface(
          onClick = onResetAllToAuto,
          shape = CircleShape,
          color = ObsidianElevated,
          border = BorderStroke(1.dp, HairlineLight),
          modifier = Modifier.testTag("pro_reset_auto_button"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Outlined.Refresh,
              contentDescription = stringResource(R.string.pro_reset_auto_btn),
              tint = SilverSecondary,
              modifier = Modifier.size(14.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = stringResource(R.string.pro_reset_auto_btn),
              style = MaterialTheme.typography.labelSmall,
              color = TitaniumWhite,
            )
          }
        }
      }

      // DSLR Parameter Selector Strip
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        val isoTag =
          when {
            exp?.isManualExposureSupported != true -> "N/A"
            settings.isManualIsoEnabled && settings.manualIso != null -> "${settings.manualIso}"
            liveTelemetry.iso != null -> "A·${liveTelemetry.iso}"
            else -> "AUTO"
          }
        DslrParamTile(
          label = "ISO",
          value = isoTag,
          selected = settings.activeProTab == ProControlTab.ISO,
          isManual = settings.isManualIsoEnabled,
          isUnavailable = exp?.isManualExposureSupported != true,
          testTag = "pro_tab_iso",
          onClick = { onSelectProTab(ProControlTab.ISO) },
        )

        val ssTag =
          when {
            exp?.isManualExposureSupported != true -> "N/A"
            settings.isManualShutterEnabled && settings.manualShutterNs != null ->
              formatShutterSpeed(settings.manualShutterNs)
            liveTelemetry.shutterNs != null -> formatShutterSpeed(liveTelemetry.shutterNs)
            else -> "AUTO"
          }
        DslrParamTile(
          label = "SHUTTER",
          value = ssTag,
          selected = settings.activeProTab == ProControlTab.SHUTTER,
          isManual = settings.isManualShutterEnabled,
          isUnavailable = exp?.isManualExposureSupported != true,
          testTag = "pro_tab_shutter",
          onClick = { onSelectProTab(ProControlTab.SHUTTER) },
        )

        val evStep = sensorCapabilities.exposureStep.takeIf { it > 0f } ?: (1f / 3f)
        val evTag =
          when {
            evRange.first >= evRange.last -> "N/A"
            settings.isManualIsoEnabled || settings.isManualShutterEnabled -> "M"
            sensorCapabilities.currentExposureIndex == 0 -> "0.0"
            else ->
              String.format(
                Locale.US,
                "%+.1f",
                sensorCapabilities.currentExposureIndex * evStep,
              )
          }
        DslrParamTile(
          label = "EV",
          value = evTag,
          selected = settings.activeProTab == ProControlTab.EV,
          isManual =
            !settings.isManualIsoEnabled &&
              !settings.isManualShutterEnabled &&
              sensorCapabilities.currentExposureIndex != 0,
          isUnavailable = evRange.first >= evRange.last,
          testTag = "pro_tab_ev",
          onClick = { onSelectProTab(ProControlTab.EV) },
        )

        val wbTag =
          if (settings.whiteBalanceMode == WhiteBalanceOption.MANUAL_KELVIN) {
            "${settings.manualKelvin}K"
          } else {
            settings.whiteBalanceMode.shortTag
          }
        DslrParamTile(
          label = "WB",
          value = wbTag,
          selected = settings.activeProTab == ProControlTab.WB,
          isManual = settings.whiteBalanceMode != WhiteBalanceOption.AUTO,
          isUnavailable = (exp?.supportedAwbModes?.size ?: 0) <= 1,
          testTag = "pro_tab_wb",
          onClick = { onSelectProTab(ProControlTab.WB) },
        )

        val focusTag =
          when {
            focus?.isManualFocusSupported != true -> "N/A"
            settings.isManualFocusEnabled ->
              if (settings.manualFocusDiopters <= 0.05f) "∞"
              else String.format(Locale.US, "%.1fd", settings.manualFocusDiopters)
            else -> "AF"
          }
        DslrParamTile(
          label = "FOCUS",
          value = focusTag,
          selected = settings.activeProTab == ProControlTab.FOCUS,
          isManual = settings.isManualFocusEnabled,
          isUnavailable = focus?.isManualFocusSupported != true,
          testTag = "pro_tab_focus",
          onClick = { onSelectProTab(ProControlTab.FOCUS) },
        )

        DslrParamTile(
          label = "FORMAT",
          value = settings.captureOutputFormat.shortTag,
          selected = settings.activeProTab == ProControlTab.FORMAT,
          isManual = settings.isRawCaptureEnabled,
          isUnavailable = false,
          testTag = "pro_tab_format",
          onClick = { onSelectProTab(ProControlTab.FORMAT) },
        )

        val activeToolsCount =
          listOf(
              settings.isFocusPeakingEnabled,
              settings.isHistogramEnabled,
              settings.isZebraEnabled,
              settings.isExposureLockEnabled,
              isGridEnabled,
              isLevelEnabled,
            )
            .count { it }
        DslrParamTile(
          label = "TOOLS",
          value = if (activeToolsCount > 0) "$activeToolsCount ON" else "HUD",
          selected = settings.activeProTab == ProControlTab.TOOLS,
          isManual = activeToolsCount > 0,
          isUnavailable = false,
          testTag = "pro_tab_tools",
          onClick = { onSelectProTab(ProControlTab.TOOLS) },
        )

        DslrParamTile(
          label = "PRESETS",
          value = "C(${customPresets.size})",
          selected = settings.activeProTab == ProControlTab.PRESETS,
          isManual = customPresets.isNotEmpty(),
          isUnavailable = false,
          testTag = "pro_tab_presets",
          onClick = { onSelectProTab(ProControlTab.PRESETS) },
        )
      }

      // Active DSLR Control Stage
      when (settings.activeProTab) {
        ProControlTab.ISO -> {
          if (exp?.isManualExposureSupported == true && exp.isoRange != null) {
            val range = exp.isoRange
            val fallbackIso = liveTelemetry.iso?.coerceIn(range) ?: range.first
            val activeIso = (settings.manualIso ?: fallbackIso).coerceIn(range)
            DslrSliderDeck(
              title = stringResource(R.string.pro_iso_label),
              valueLabel =
                if (settings.isManualIsoEnabled) "ISO $activeIso"
                else "AUTO (ISO $fallbackIso)",
              isManualActive = settings.isManualIsoEnabled,
              toggleBadgeText =
                if (settings.isManualIsoEnabled) "SWITCH AUTO"
                else stringResource(R.string.pro_auto_badge),
              onToggleAuto = { onSetManualIso(!settings.isManualIsoEnabled, activeIso) },
              sliderValue = activeIso.toFloat(),
              valueRange = range.first.toFloat()..range.last.toFloat(),
              onValueChange = { newVal ->
                onSetManualIso(true, newVal.roundToInt().coerceIn(range))
              },
              rangeSummary = "Hardware ISO range ${range.first} – ${range.last}",
              sliderTestTag = "slider_manual_iso",
            ) {
              val quickIsos =
                listOf(50, 100, 200, 400, 800, 1600, 3200, 6400).filter { it in range }
              if (quickIsos.isNotEmpty()) {
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  QuickChip(
                    label = "AUTO",
                    selected = !settings.isManualIsoEnabled,
                    accent = OpticalCyan,
                    onClick = { onSetManualIso(false, null) },
                  )
                  quickIsos.forEach { stop ->
                    QuickChip(
                      label = "$stop",
                      selected = settings.isManualIsoEnabled && activeIso == stop,
                      accent = ProAmber,
                      onClick = { onSetManualIso(true, stop) },
                    )
                  }
                }
              }
            }
          } else {
            UnavailableFeatureCard(
              title = stringResource(R.string.pro_iso_label),
              reason =
                exp?.unsupportedManualReason
                  ?: "Unavailable: Sensor does not support manual ISO (MANUAL_SENSOR required)",
            )
          }
        }

        ProControlTab.SHUTTER -> {
          if (exp?.isManualExposureSupported == true && exp.shutterRangeNs != null) {
            val range = exp.shutterRangeNs
            val minLog = ln(range.first.coerceAtLeast(1L).toDouble()).toFloat()
            val maxLog = ln(range.last.coerceAtLeast(range.first + 1L).toDouble()).toFloat()
            val fallbackNs = (liveTelemetry.shutterNs ?: 16_666_666L).coerceIn(range)
            val activeNs = (settings.manualShutterNs ?: fallbackNs).coerceIn(range)
            val currentLog = ln(activeNs.coerceAtLeast(1L).toDouble()).toFloat().coerceIn(minLog, maxLog)

            DslrSliderDeck(
              title = stringResource(R.string.pro_shutter_label),
              valueLabel =
                if (settings.isManualShutterEnabled) formatShutterSpeed(activeNs)
                else "AUTO (${formatShutterSpeed(fallbackNs)})",
              isManualActive = settings.isManualShutterEnabled,
              toggleBadgeText =
                if (settings.isManualShutterEnabled) "SWITCH AUTO"
                else stringResource(R.string.pro_auto_badge),
              onToggleAuto = { onSetManualShutter(!settings.isManualShutterEnabled, activeNs) },
              sliderValue = currentLog,
              valueRange = minLog..maxLog,
              onValueChange = { newLog ->
                val ns = exp(newLog.toDouble()).toLong().coerceIn(range)
                onSetManualShutter(true, ns)
              },
              rangeSummary =
                "Hardware exposure ${formatShutterSpeed(range.first)} – ${formatShutterSpeed(range.last)}",
              sliderTestTag = "slider_manual_shutter",
            ) {
              val shutterStops =
                listOf(
                    250_000L, // 1/4000s
                    1_000_000L, // 1/1000s
                    4_000_000L, // 1/250s
                    8_333_333L, // 1/120s
                    16_666_666L, // 1/60s
                    33_333_333L, // 1/30s
                    125_000_000L, // 1/8s
                    250_000_000L, // 1/4s
                    1_000_000_000L, // 1s
                  )
                  .filter { it in range }
              if (shutterStops.isNotEmpty()) {
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  QuickChip(
                    label = "AUTO",
                    selected = !settings.isManualShutterEnabled,
                    accent = OpticalCyan,
                    onClick = { onSetManualShutter(false, null) },
                  )
                  shutterStops.forEach { stopNs ->
                    QuickChip(
                      label = formatShutterSpeed(stopNs),
                      selected =
                        settings.isManualShutterEnabled &&
                          kotlin.math.abs(activeNs - stopNs) <= (stopNs / 8L),
                      accent = ProAmber,
                      onClick = { onSetManualShutter(true, stopNs) },
                    )
                  }
                }
              }
            }
          } else {
            UnavailableFeatureCard(
              title = stringResource(R.string.pro_shutter_label),
              reason =
                exp?.unsupportedManualReason
                  ?: "Unavailable: Sensor does not support manual shutter speed (MANUAL_SENSOR required)",
            )
          }
        }

        ProControlTab.EV -> {
          if (evRange.first < evRange.last) {
            val step = sensorCapabilities.exposureStep.takeIf { it > 0f } ?: (1f / 3f)
            val currentIdx = sensorCapabilities.currentExposureIndex.coerceIn(evRange)
            val evLabel =
              if (currentIdx == 0) "0.0 EV"
              else String.format(Locale.US, "%+.1f EV", currentIdx * step)
            val manualAeWarning =
              if (settings.isManualIsoEnabled || settings.isManualShutterEnabled) {
                "Manual ISO/Shutter overrides AE · Drag EV to re-enable Auto AE + EV"
              } else {
                String.format(
                  Locale.US,
                  "Hardware EV range %+.1f to %+.1f EV",
                  evRange.first * step,
                  evRange.last * step,
                )
              }

            DslrSliderDeck(
              title = stringResource(R.string.pro_ev_label),
              valueLabel = evLabel,
              isManualActive = currentIdx != 0,
              toggleBadgeText = "ZERO",
              onToggleAuto = { onExposureCompChange(0) },
              sliderValue = currentIdx.toFloat(),
              valueRange = evRange.first.toFloat()..evRange.last.toFloat(),
              onValueChange = { newVal ->
                if (settings.isManualIsoEnabled) onSetManualIso(false, null)
                if (settings.isManualShutterEnabled) onSetManualShutter(false, null)
                val idx = newVal.roundToInt().coerceIn(evRange)
                if (idx != currentIdx) {
                  onExposureCompChange(idx)
                }
              },
              rangeSummary = manualAeWarning,
              sliderTestTag = "slider_exposure_comp",
            )
          } else {
            UnavailableFeatureCard(
              title = stringResource(R.string.pro_ev_label),
              reason = "Unavailable: Exposure compensation range is locked or unsupported on this sensor",
            )
          }
        }

        ProControlTab.WB -> {
          val wbModes = exp?.supportedAwbModes ?: listOf(WhiteBalanceOption.AUTO)
          if (wbModes.size > 1 || exp?.isManualKelvinSupported == true) {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = ObsidianElevated,
              border = BorderStroke(1.dp, HairlineSubtle),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Text(
                    text = stringResource(R.string.pro_wb_label),
                    style = MaterialTheme.typography.titleMedium,
                    color = TitaniumWhite,
                  )
                  Text(
                    text =
                      if (settings.whiteBalanceMode == WhiteBalanceOption.MANUAL_KELVIN) {
                        "${settings.manualKelvin}K"
                      } else {
                        settings.whiteBalanceMode.label
                      },
                    style = MaterialTheme.typography.labelMedium,
                    color =
                      if (settings.whiteBalanceMode != WhiteBalanceOption.AUTO) ProAmber
                      else OpticalCyan,
                  )
                }

                FlowRow(
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                  verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  wbModes.forEach { mode ->
                    val isSelected = settings.whiteBalanceMode == mode
                    QuickChip(
                      label =
                        if (mode == WhiteBalanceOption.MANUAL_KELVIN) "${settings.manualKelvin}K"
                        else mode.label,
                      selected = isSelected,
                      accent = if (mode == WhiteBalanceOption.AUTO) OpticalCyan else ProAmber,
                      onClick = { onSetWhiteBalance(mode) },
                    )
                  }
                }

                if (exp?.isManualKelvinSupported == true) {
                  Column {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                      Text(
                        text = stringResource(R.string.pro_kelvin_label),
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverSecondary,
                      )
                      Text(
                        text = "2200K (Cool) – 8000K (Warm)",
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverMuted,
                      )
                    }
                    Slider(
                      value = settings.manualKelvin.toFloat().coerceIn(2200f, 8000f),
                      onValueChange = { k ->
                        val snapped = (k / 100f).roundToInt() * 100
                        onSetManualKelvin(snapped)
                      },
                      valueRange = 2200f..8000f,
                      colors =
                        SliderDefaults.colors(
                          thumbColor =
                            if (settings.whiteBalanceMode == WhiteBalanceOption.MANUAL_KELVIN) ProAmber
                            else TitaniumWhite,
                          activeTrackColor = ProAmber,
                          inactiveTrackColor = ObsidianBlack,
                        ),
                      modifier = Modifier.fillMaxWidth().height(34.dp).testTag("slider_manual_kelvin"),
                    )
                  }
                } else if (exp?.unsupportedWhiteBalanceReason != null) {
                  Text(
                    text = exp.unsupportedWhiteBalanceReason,
                    style = MaterialTheme.typography.labelSmall,
                    color = SilverMuted,
                  )
                }
              }
            }
          } else {
            UnavailableFeatureCard(
              title = stringResource(R.string.pro_wb_label),
              reason =
                exp?.unsupportedWhiteBalanceReason
                  ?: "Unavailable: Sensor only reports Auto White Balance",
            )
          }
        }

        ProControlTab.FOCUS -> {
          if (focus?.isManualFocusSupported == true && focus.minimumFocusDistanceDiopters > 0f) {
            val maxD = focus.minimumFocusDistanceDiopters
            val currentD = settings.manualFocusDiopters.coerceIn(0f, maxD)
            val distanceText =
              if (!settings.isManualFocusEnabled) {
                "AF (${focus.afModes.firstOrNull() ?: "CONTINUOUS"})"
              } else if (currentD <= 0.05f) {
                "MF ∞ Infinity"
              } else {
                val cm = 100f / currentD
                if (cm >= 100f) String.format(Locale.US, "MF %.2fm", cm / 100f)
                else String.format(Locale.US, "MF %.1fcm", cm)
              }

            DslrSliderDeck(
              title = stringResource(R.string.pro_focus_label),
              valueLabel = distanceText,
              isManualActive = settings.isManualFocusEnabled,
              toggleBadgeText =
                if (settings.isManualFocusEnabled) "SWITCH AF" else "AF",
              onToggleAuto = { onSetManualFocus(!settings.isManualFocusEnabled, currentD) },
              sliderValue = currentD,
              valueRange = 0f..maxD,
              onValueChange = { newD -> onSetManualFocus(true, newD.coerceIn(0f, maxD)) },
              rangeSummary =
                "Min focus: ${focus.minimumFocusDistanceCm?.let { String.format(Locale.US, "%.1f cm", it) } ?: "—"} (${focus.focusCalibrationLabel})",
              sliderTestTag = "slider_manual_focus",
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                QuickChip(
                  label = "AF",
                  selected = !settings.isManualFocusEnabled,
                  accent = OpticalCyan,
                  onClick = { onSetManualFocus(false, currentD) },
                )
                QuickChip(
                  label = "∞ INF",
                  selected = settings.isManualFocusEnabled && currentD <= 0.05f,
                  accent = ProAmber,
                  onClick = { onSetManualFocus(true, 0f) },
                )
                if (maxD >= 1f) {
                  QuickChip(
                    label = "1.0m",
                    selected = settings.isManualFocusEnabled && kotlin.math.abs(currentD - 1f) < 0.25f,
                    accent = ProAmber,
                    onClick = { onSetManualFocus(true, 1f) },
                  )
                }
                if (maxD >= 3.3f) {
                  QuickChip(
                    label = "0.3m",
                    selected = settings.isManualFocusEnabled && kotlin.math.abs(currentD - 3.3f) < 0.4f,
                    accent = ProAmber,
                    onClick = { onSetManualFocus(true, 3.33f) },
                  )
                }
                QuickChip(
                  label = "MACRO",
                  selected = settings.isManualFocusEnabled && currentD >= maxD * 0.9f,
                  accent = ProAmber,
                  onClick = { onSetManualFocus(true, maxD) },
                )
                ControlIconChip(
                  icon = Icons.Outlined.CenterFocusStrong,
                  label = "PEAK",
                  selected = settings.isFocusPeakingEnabled,
                  accentColor = OpticalCyan,
                  contentDescription = stringResource(R.string.cd_focus_peaking),
                  testTag = "chip_peaking_inline",
                  onClick = onToggleFocusPeaking,
                )
              }
            }
          } else {
            UnavailableFeatureCard(
              title = stringResource(R.string.pro_focus_label),
              reason =
                focus?.unsupportedManualReason
                  ?: "Unavailable: Fixed-focus lens or unsupported manual focus",
            )
          }
        }

        ProControlTab.FORMAT -> {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = ObsidianElevated,
            border = BorderStroke(1.dp, HairlineSubtle),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(
              modifier = Modifier.padding(12.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Text(
                text = stringResource(R.string.pro_format_label),
                style = MaterialTheme.typography.titleMedium,
                color = TitaniumWhite,
              )

              val rawDngSupported =
                exp?.isRawSupported == true && exp.isCameraXRawOnlySupported
              val rawPlusJpegSupported =
                exp?.isRawSupported == true && exp.isCameraXRawJpegSupported
              val rawSizeText =
                exp?.rawOutputSizes?.firstOrNull()?.formattedLabel() ?: "Sensor DNG"

              FormatOptionRow(
                title = "JPEG",
                subtitle =
                  profile?.maxJpegResolution?.formattedLabel() ?: "Full Native Sensor JPEG",
                selected = settings.captureOutputFormat == CaptureOutputFormat.JPEG,
                supported = true,
                unavailableReason = null,
                testTag = "format_option_jpeg",
                onClick = { onSelectCaptureFormat(CaptureOutputFormat.JPEG) },
              )

              FormatOptionRow(
                title = "RAW (DNG)",
                subtitle = "16-bit uncompressed DNG · $rawSizeText",
                selected = settings.captureOutputFormat == CaptureOutputFormat.RAW_DNG,
                supported = rawDngSupported,
                unavailableReason =
                  exp?.unsupportedRawReason
                    ?: "Unavailable: Sensor or CameraX stream does not support DNG-only RAW output",
                testTag = "format_option_raw",
                onClick = { onSelectCaptureFormat(CaptureOutputFormat.RAW_DNG) },
              )

              FormatOptionRow(
                title = "RAW + JPEG",
                subtitle = "Simultaneous DNG + Native JPEG · $rawSizeText",
                selected = settings.captureOutputFormat == CaptureOutputFormat.RAW_PLUS_JPEG,
                supported = rawPlusJpegSupported,
                unavailableReason =
                  exp?.unsupportedRawReason
                    ?: "Unavailable: Simultaneous RAW + JPEG output unsupported on this sensor",
                testTag = "format_option_raw_jpeg",
                onClick = { onSelectCaptureFormat(CaptureOutputFormat.RAW_PLUS_JPEG) },
              )
            }
          }
        }

        ProControlTab.TOOLS -> {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = ObsidianElevated,
            border = BorderStroke(1.dp, HairlineSubtle),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(
              modifier = Modifier.padding(12.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Text(
                text = "DSLR Monitoring & Camera Tools",
                style = MaterialTheme.typography.titleMedium,
                color = TitaniumWhite,
              )

              FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                ControlIconChip(
                  icon = Icons.Outlined.CenterFocusStrong,
                  label = stringResource(R.string.pro_peaking_label),
                  selected = settings.isFocusPeakingEnabled,
                  accentColor = OpticalCyan,
                  contentDescription = stringResource(R.string.cd_focus_peaking),
                  testTag = "chip_focus_peaking",
                  onClick = onToggleFocusPeaking,
                )

                if (settings.isFocusPeakingEnabled) {
                  QuickChip(
                    label = "Color: ${settings.focusPeakingColor.label}",
                    selected = true,
                    accent = ProAmber,
                    onClick = onCycleFocusPeakingColor,
                  )
                }

                ControlIconChip(
                  icon = Icons.Outlined.BarChart,
                  label = stringResource(R.string.pro_histogram_label),
                  selected = settings.isHistogramEnabled,
                  accentColor = OpticalCyan,
                  contentDescription = stringResource(R.string.cd_live_histogram),
                  testTag = "chip_live_histogram",
                  onClick = onToggleHistogram,
                )

                ControlIconChip(
                  icon = Icons.Outlined.WarningAmber,
                  label =
                    if (settings.isZebraEnabled) "Zebra ${settings.zebraThresholdPercent}%"
                    else stringResource(R.string.pro_zebra_label),
                  selected = settings.isZebraEnabled,
                  accentColor = ErrorCoral,
                  contentDescription = stringResource(R.string.cd_zebra_warning),
                  testTag = "chip_zebra_warning",
                  onClick = onToggleZebra,
                )

                ControlIconChip(
                  icon =
                    if (settings.isExposureLockEnabled) Icons.Outlined.Lock
                    else Icons.Outlined.LockOpen,
                  label =
                    if (exp?.isAeLockSupported == true) stringResource(R.string.label_ae_lock)
                    else "AE Lock (N/A)",
                  selected = settings.isExposureLockEnabled,
                  enabled = exp?.isAeLockSupported == true,
                  accentColor = ProAmber,
                  contentDescription = stringResource(R.string.cd_exposure_lock),
                  testTag = "chip_ae_lock",
                  onClick = onToggleExposureLock,
                )

                ControlIconChip(
                  icon = if (isGridEnabled) Icons.Outlined.GridOn else Icons.Outlined.GridOff,
                  label = stringResource(R.string.label_grid),
                  selected = isGridEnabled,
                  accentColor = OpticalCyan,
                  contentDescription = stringResource(R.string.cd_grid_toggle),
                  testTag = "chip_grid_toggle",
                  onClick = onToggleGrid,
                )

                ControlIconChip(
                  icon = Icons.Outlined.Straighten,
                  label =
                    if (hasLevelSensor) stringResource(R.string.label_level)
                    else "Level (N/A)",
                  selected = isLevelEnabled,
                  enabled = hasLevelSensor,
                  accentColor = OpticalCyan,
                  contentDescription = stringResource(R.string.cd_level_indicator),
                  testTag = "chip_level_toggle",
                  onClick = onToggleLevel,
                )

                if (isFrontCamera) {
                  ControlIconChip(
                    icon = Icons.Outlined.FlipCameraAndroid,
                    label = stringResource(R.string.label_mirror),
                    selected = isFrontMirrorEnabled,
                    accentColor = OpticalCyan,
                    contentDescription = stringResource(R.string.cd_front_mirror),
                    testTag = "chip_front_mirror",
                    onClick = onToggleFrontMirror,
                  )
                }

                ControlIconChip(
                  icon =
                    if (isVolumeShutterEnabled) Icons.Outlined.VolumeUp
                    else Icons.Outlined.VolumeOff,
                  label = stringResource(R.string.label_vol_shutter),
                  selected = isVolumeShutterEnabled,
                  accentColor = OpticalCyan,
                  contentDescription = stringResource(R.string.cd_volume_shutter),
                  testTag = "chip_volume_shutter",
                  onClick = onToggleVolumeShutter,
                )
              }

              if (settings.isZebraEnabled) {
                Row(
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Text(
                    text = "Zebra IRE:",
                    style = MaterialTheme.typography.labelSmall,
                    color = SilverSecondary,
                  )
                  listOf(85, 90, 95, 98).forEach { pct ->
                    QuickChip(
                      label = "${pct}%",
                      selected = settings.zebraThresholdPercent == pct,
                      accent = ErrorCoral,
                      onClick = { onSetZebraThreshold(pct) },
                    )
                  }
                }
              }

              // Stabilization Section
              Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                  text = stringResource(R.string.pro_stabilization_label),
                  style = MaterialTheme.typography.labelMedium,
                  color = SilverSecondary,
                )
                FlowRow(
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                  verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  val oisSupported = stab?.isOisSupported == true
                  val eisSupported =
                    stab?.isEisSupported == true || stab?.isPreviewStabilizationSupported == true
                  val stabOptions =
                    listOf(
                      StabilizationSelection.AUTO to true,
                      StabilizationSelection.OIS to oisSupported,
                      StabilizationSelection.EIS to eisSupported,
                      StabilizationSelection.OFF to true,
                    )
                  stabOptions.forEach { (opt, supported) ->
                    QuickChip(
                      label = if (supported) opt.label else "${opt.label} (N/A)",
                      selected = settings.stabilizationSelection == opt,
                      enabled = supported,
                      accent = OpticalCyan,
                      onClick = { if (supported) onSelectStabilization(opt) },
                    )
                  }
                }
              }
            }
          }
        }

        ProControlTab.PRESETS -> {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = ObsidianElevated,
            border = BorderStroke(1.dp, HairlineSubtle),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(
              modifier = Modifier.padding(12.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = stringResource(R.string.pro_presets_label),
                  style = MaterialTheme.typography.titleMedium,
                  color = TitaniumWhite,
                )
                Surface(
                  onClick = { showSavePresetDialog = true },
                  shape = CircleShape,
                  color = ProAmber,
                  modifier = Modifier.testTag("save_preset_button"),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      imageVector = Icons.Outlined.Add,
                      contentDescription = stringResource(R.string.pro_save_preset_btn),
                      tint = ObsidianBlack,
                      modifier = Modifier.size(15.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = stringResource(R.string.pro_save_preset_btn),
                      style = MaterialTheme.typography.labelSmall,
                      color = ObsidianBlack,
                    )
                  }
                }
              }

              if (customPresets.isEmpty()) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                ) {
                  Icon(
                    imageVector = Icons.Outlined.BookmarkBorder,
                    contentDescription = null,
                    tint = SilverMuted,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = stringResource(R.string.pro_preset_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = SilverMuted,
                  )
                }
              } else {
                customPresets.forEach { preset ->
                  val summary = buildString {
                    append(
                      if (preset.isManualIsoEnabled && preset.manualIso != null) "ISO ${preset.manualIso}"
                      else "ISO Auto"
                    )
                    append(" · ")
                    append(
                      if (preset.isManualShutterEnabled && preset.manualShutterNs != null) {
                        formatShutterSpeed(preset.manualShutterNs)
                      } else {
                        "SS Auto"
                      }
                    )
                    append(" · ")
                    append(
                      if (preset.whiteBalanceMode == WhiteBalanceOption.MANUAL_KELVIN) "${preset.manualKelvin}K"
                      else preset.whiteBalanceMode.shortTag
                    )
                    append(" · ")
                    append(preset.captureOutputFormat.shortTag)
                  }

                  Surface(
                    onClick = { onApplyPreset(preset) },
                    shape = RoundedCornerShape(12.dp),
                    color = ObsidianBlack,
                    border = BorderStroke(1.dp, HairlineLight),
                    modifier = Modifier.fillMaxWidth().testTag("preset_item_${preset.id}"),
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Column(modifier = Modifier.weight(1f)) {
                        Text(
                          text = preset.name,
                          style = MaterialTheme.typography.labelLarge,
                          color = TitaniumWhite,
                        )
                        Text(
                          text = summary,
                          style = MaterialTheme.typography.labelSmall,
                          color = OpticalCyan,
                        )
                      }
                      IconButton(
                        onClick = { onDeletePreset(preset.id) },
                        modifier = Modifier.size(40.dp),
                      ) {
                        Icon(
                          imageVector = Icons.Outlined.DeleteOutline,
                          contentDescription = "Delete preset ${preset.name}",
                          tint = SilverMuted,
                          modifier = Modifier.size(18.dp),
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun DslrParamTile(
  label: String,
  value: String,
  selected: Boolean,
  isManual: Boolean,
  isUnavailable: Boolean,
  testTag: String,
  onClick: () -> Unit,
) {
  val borderColor =
    when {
      selected -> ProAmber
      isManual -> OpticalCyan.copy(alpha = 0.65f)
      else -> HairlineLight
    }
  val bg =
    when {
      selected -> ProAmber.copy(alpha = 0.16f)
      else -> ObsidianElevated
    }
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(10.dp),
    color = bg,
    border = BorderStroke(1.dp, borderColor),
    modifier = Modifier.minimumInteractiveComponentSize().testTag(testTag),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = if (selected) ProAmber else SilverMuted,
      )
      Text(
        text = value,
        style = MaterialTheme.typography.labelMedium,
        color =
          when {
            isUnavailable -> SilverMuted.copy(alpha = 0.7f)
            selected -> TitaniumWhite
            isManual -> OpticalCyan
            else -> TitaniumWhite
          },
      )
    }
  }
}

@Composable
private fun DslrSliderDeck(
  title: String,
  valueLabel: String,
  isManualActive: Boolean,
  toggleBadgeText: String,
  onToggleAuto: () -> Unit,
  sliderValue: Float,
  valueRange: ClosedFloatingPointRange<Float>,
  onValueChange: (Float) -> Unit,
  rangeSummary: String,
  sliderTestTag: String,
  quickStopsContent: (@Composable () -> Unit)? = null,
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = ObsidianElevated,
    border =
      BorderStroke(
        1.dp,
        if (isManualActive) ProAmber.copy(alpha = 0.55f) else HairlineSubtle,
      ),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(text = title, style = MaterialTheme.typography.titleMedium, color = TitaniumWhite)
          Text(
            text = valueLabel,
            style = MaterialTheme.typography.labelLarge,
            color = if (isManualActive) ProAmber else OpticalCyan,
          )
        }
        Surface(
          onClick = onToggleAuto,
          shape = CircleShape,
          color = if (isManualActive) ProAmber else ObsidianBlack,
          border = BorderStroke(1.dp, if (isManualActive) ProAmber else HairlineLight),
        ) {
          Text(
            text = toggleBadgeText,
            style = MaterialTheme.typography.labelSmall,
            color = if (isManualActive) ObsidianBlack else TitaniumWhite,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          )
        }
      }

      Slider(
        value = sliderValue.coerceIn(valueRange.start, valueRange.endInclusive),
        onValueChange = onValueChange,
        valueRange = valueRange,
        colors =
          SliderDefaults.colors(
            thumbColor = if (isManualActive) ProAmber else TitaniumWhite,
            activeTrackColor = if (isManualActive) ProAmber else SilverSecondary,
            inactiveTrackColor = ObsidianBlack,
          ),
        modifier = Modifier.fillMaxWidth().height(34.dp).testTag(sliderTestTag),
      )

      Text(text = rangeSummary, style = MaterialTheme.typography.labelSmall, color = SilverMuted)

      quickStopsContent?.invoke()
    }
  }
}

@Composable
private fun UnavailableFeatureCard(
  title: String,
  reason: String,
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = ObsidianBlack.copy(alpha = 0.72f),
    border = BorderStroke(1.dp, HairlineLight),
    modifier = Modifier.fillMaxWidth().testTag("unavailable_feature_card"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Outlined.Lock,
        contentDescription = stringResource(R.string.pro_unavailable_title),
        tint = SilverMuted,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(
          text = "$title — ${stringResource(R.string.pro_unavailable_title)}",
          style = MaterialTheme.typography.labelLarge,
          color = SilverSecondary,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = reason,
          style = MaterialTheme.typography.bodyMedium,
          color = SilverMuted,
        )
      }
    }
  }
}

@Composable
private fun FormatOptionRow(
  title: String,
  subtitle: String,
  selected: Boolean,
  supported: Boolean,
  unavailableReason: String?,
  testTag: String,
  onClick: () -> Unit,
) {
  Surface(
    onClick = { if (supported) onClick() },
    enabled = supported,
    shape = RoundedCornerShape(12.dp),
    color =
      when {
        selected -> ProAmber.copy(alpha = 0.16f)
        supported -> ObsidianBlack
        else -> ObsidianBlack.copy(alpha = 0.45f)
      },
    border =
      BorderStroke(
        1.dp,
        when {
          selected -> ProAmber
          supported -> HairlineLight
          else -> HairlineSubtle
        },
      ),
    modifier = Modifier.fillMaxWidth().testTag(testTag),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = if (supported) title else "$title (Unavailable)",
          style = MaterialTheme.typography.labelLarge,
          color = if (supported) TitaniumWhite else SilverMuted,
        )
        Text(
          text = if (supported) subtitle else (unavailableReason ?: "Unsupported on this sensor"),
          style = MaterialTheme.typography.labelSmall,
          color = if (supported) SilverSecondary else SilverMuted.copy(alpha = 0.75f),
        )
      }
      if (selected) {
        Surface(
          shape = CircleShape,
          color = ProAmber,
        ) {
          Text(
            text = "ACTIVE",
            style = MaterialTheme.typography.labelSmall,
            color = ObsidianBlack,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
          )
        }
      } else if (!supported) {
        Icon(
          imageVector = Icons.Outlined.Lock,
          contentDescription = null,
          tint = SilverMuted,
          modifier = Modifier.size(16.dp),
        )
      }
    }
  }
}

@Composable
private fun QuickChip(
  label: String,
  selected: Boolean,
  accent: Color,
  enabled: Boolean = true,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    enabled = enabled,
    shape = CircleShape,
    color =
      when {
        selected -> accent
        enabled -> ObsidianBlack
        else -> ObsidianBlack.copy(alpha = 0.45f)
      },
    border =
      BorderStroke(
        1.dp,
        when {
          selected -> accent
          enabled -> HairlineLight
          else -> HairlineSubtle
        },
      ),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color =
        when {
          selected -> ObsidianBlack
          enabled -> TitaniumWhite
          else -> SilverMuted.copy(alpha = 0.6f)
        },
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
    )
  }
}

@Composable
private fun ControlIconChip(
  icon: ImageVector,
  label: String,
  selected: Boolean,
  accentColor: Color,
  contentDescription: String,
  testTag: String,
  enabled: Boolean = true,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    enabled = enabled,
    shape = CircleShape,
    color =
      when {
        selected -> accentColor
        enabled -> ObsidianBlack
        else -> ObsidianBlack.copy(alpha = 0.45f)
      },
    border =
      BorderStroke(
        1.dp,
        when {
          selected -> accentColor
          enabled -> HairlineLight
          else -> HairlineSubtle
        },
      ),
    modifier = Modifier.minimumInteractiveComponentSize().testTag(testTag),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = contentDescription,
        tint =
          when {
            selected -> ObsidianBlack
            enabled -> TitaniumWhite
            else -> SilverMuted.copy(alpha = 0.6f)
          },
        modifier = Modifier.size(16.dp),
      )
      Spacer(modifier = Modifier.width(5.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        color =
          when {
            selected -> ObsidianBlack
            enabled -> TitaniumWhite
            else -> SilverMuted.copy(alpha = 0.6f)
          },
      )
    }
  }
}

fun formatShutterSpeed(ns: Long): String {
  if (ns <= 0L) return "—"
  val seconds = ns / 1_000_000_000.0
  return if (seconds >= 0.45) {
    String.format(Locale.US, "%.1fs", seconds)
  } else {
    val denom = (1_000_000_000.0 / ns).roundToInt().coerceAtLeast(1)
    "1/${denom}s"
  }
}
