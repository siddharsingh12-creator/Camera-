package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBlack = Color(0xFF090A0D)
val ObsidianSurface = Color(0xFF12141A)
val ObsidianElevated = Color(0xFF1A1D26)
val ObsidianGlass = Color(0xB3101218)
val TitaniumWhite = Color(0xFFF6F7F9)
val SilverSecondary = Color(0xFFB4BAC6)
val SilverMuted = Color(0xFF7D8594)
val OpticalCyan = Color(0xFF67E8F9)
val ProAmber = Color(0xFFF59E0B)
val CaptureEmerald = Color(0xFF34D399)
val ErrorCoral = Color(0xFFF87171)
val HairlineLight = Color(0x26FFFFFF)
val HairlineSubtle = Color(0x14FFFFFF)
