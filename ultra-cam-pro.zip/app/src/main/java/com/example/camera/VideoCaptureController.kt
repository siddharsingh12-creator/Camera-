package com.example.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Range
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.DynamicRange
import androidx.camera.core.ExperimentalSessionConfig
import androidx.camera.core.MirrorMode
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.ExperimentalHighSpeedVideo
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.HighSpeedVideoSessionConfig
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.os.Build
import java.util.concurrent.Executor

object VideoCaptureController {

  data class BoundVideoSession(
    val camera: Camera,
    val preview: Preview,
    val videoCapture: VideoCapture<Recorder>,
    val capabilities: CameraVideoCapabilities,
  )

  @OptIn(ExperimentalHighSpeedVideo::class, ExperimentalSessionConfig::class)
  fun bindVideoUseCases(
    lifecycleOwner: LifecycleOwner,
    cameraProvider: ProcessCameraProvider,
    selector: CameraSelector,
    cameraExecutor: Executor,
    profile: CameraHardwareProfile?,
    previewAspectRatio: PreviewAspectRatio,
    displayRotation: Int,
    sensorRotation: Int,
    mirrorFront: Boolean,
    videoSettings: VideoSettings,
    onLiveTelemetry: (LiveExposureTelemetry) -> Unit,
  ): BoundVideoSession {
    val targetCameraInfo: CameraInfo? =
      try {
        cameraProvider.getCameraInfo(selector)
      } catch (_: Exception) {
        null
      }

    val capabilities =
      if (targetCameraInfo != null) {
        VideoCapabilityManager.evaluateLiveCapabilities(
          cameraInfo = targetCameraInfo,
          profile = profile,
          selectedQuality = videoSettings.quality,
          hdrEnabled = videoSettings.isHdrEnabled,
        )
      } else {
        CameraVideoCapabilities(cameraId = profile?.cameraId, isInitialized = true)
      }

    val isHighSpeed =
      videoSettings.fps.isHighSpeed && capabilities.availabilityOf(videoSettings.fps).isSupported
    val useHdr =
      !isHighSpeed &&
        videoSettings.isHdrEnabled &&
        capabilities.hdrAvailability.isSupported &&
        capabilities.hdrAvailability.supportedQualities.contains(videoSettings.quality)
    val dynamicRange =
      if (useHdr) capabilities.hdrAvailability.dynamicRange else DynamicRange.SDR

    val qualityAvail = capabilities.availabilityOf(videoSettings.quality)
    val chosenQuality =
      if (qualityAvail.isSupported && qualityAvail.cameraXQuality != null) {
        qualityAvail.cameraXQuality
      } else {
        capabilities.supportedQualityList().firstOrNull()?.toCameraXQualityOrNull() ?: Quality.FHD
      }

    val qualitySelector =
      if (isHighSpeed) {
        val hsQualities = capabilities.availabilityOf(videoSettings.fps).supportedHighSpeedQualities
        val hsPreferred =
          if (hsQualities.contains(chosenQuality)) chosenQuality
          else hsQualities.firstOrNull() ?: Quality.FHD
        QualitySelector.from(hsPreferred, FallbackStrategy.lowerQualityOrHigherThan(Quality.HD))
      } else {
        QualitySelector.from(chosenQuality, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
      }

    val recorderBuilder =
      Recorder.Builder()
        .setExecutor(cameraExecutor)
        .setQualitySelector(qualitySelector)

    val requestedBitrate = videoSettings.bitrate.bitrateBps
    if (requestedBitrate != null && capabilities.isBitrateSupported(videoSettings.bitrate)) {
      recorderBuilder.setTargetVideoEncodingBitRate(requestedBitrate)
    }

    val recorder = recorderBuilder.build()

    val stabilizationEnabled =
      when (videoSettings.stabilization) {
        StabilizationSelection.OFF -> false
        StabilizationSelection.EIS -> capabilities.isEisSupported
        StabilizationSelection.OIS -> false // OIS controlled at lens level via Camera2Interop
        StabilizationSelection.AUTO -> capabilities.isEisSupported
      }

    val videoBuilder =
      VideoCapture.Builder(recorder)
        .setTargetRotation(sensorRotation)
        .setMirrorMode(
          if (mirrorFront) MirrorMode.MIRROR_MODE_ON_FRONT_ONLY
          else MirrorMode.MIRROR_MODE_OFF
        )
        .setDynamicRange(dynamicRange)
        .setVideoStabilizationEnabled(stabilizationEnabled)

    val fpsAvail = capabilities.availabilityOf(videoSettings.fps)
    if (!isHighSpeed && fpsAvail.isSupported && fpsAvail.matchedRange != null) {
      videoBuilder.setTargetFrameRate(fpsAvail.matchedRange)
    }

    val videoCapture = videoBuilder.build()

    val previewBuilder =
      Preview.Builder()
        .setResolutionSelector(
          CameraCapabilitiesHelper.buildPreviewResolutionSelector(
            if (previewAspectRatio == PreviewAspectRatio.FULL) PreviewAspectRatio.FULL
            else PreviewAspectRatio.RATIO_16_9
          )
        )
        .setTargetRotation(displayRotation)
    if (useHdr) {
      previewBuilder.setDynamicRange(dynamicRange)
    }
    CameraCapabilitiesHelper.attachLiveTelemetryCallback(previewBuilder, onLiveTelemetry)
    val preview = previewBuilder.build()

    cameraProvider.unbindAll()

    val camera =
      if (isHighSpeed && targetCameraInfo != null) {
        try {
          val hsBuilder =
            HighSpeedVideoSessionConfig.Builder(videoCapture)
              .setPreview(preview)
              .setSlowMotionEnabled(videoSettings.isSlowMotionBakedIn)
          val supportedHsRanges = targetCameraInfo.getSupportedFrameRateRanges(hsBuilder.build())
          val matchedRange =
            supportedHsRanges.firstOrNull { it.upper == videoSettings.fps.fps }
              ?: supportedHsRanges.firstOrNull()
          if (matchedRange != null) {
            hsBuilder.setFrameRateRange(matchedRange)
          }
          cameraProvider.bindToLifecycle(lifecycleOwner, selector, hsBuilder.build())
        } catch (_: Exception) {
          // Safe fallback to standard Preview + VideoCapture when device refuses high-speed stream
          cameraProvider.unbindAll()
          cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview, videoCapture)
        }
      } else {
        try {
          cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview, videoCapture)
        } catch (_: IllegalArgumentException) {
          // Fallback to SDR default Preview + VideoCapture if HDR or stabilization combo rejected
          cameraProvider.unbindAll()
          val fallbackPreview =
            Preview.Builder()
              .setTargetRotation(displayRotation)
              .apply {
                CameraCapabilitiesHelper.attachLiveTelemetryCallback(this, onLiveTelemetry)
              }
              .build()
          val fallbackVideo =
            VideoCapture.Builder(Recorder.Builder().setExecutor(cameraExecutor).build())
              .setTargetRotation(sensorRotation)
              .setMirrorMode(
                if (mirrorFront) MirrorMode.MIRROR_MODE_ON_FRONT_ONLY
                else MirrorMode.MIRROR_MODE_OFF
              )
              .build()
          cameraProvider.bindToLifecycle(lifecycleOwner, selector, fallbackPreview, fallbackVideo)
            .also { cam ->
              return BoundVideoSession(cam, fallbackPreview, fallbackVideo, capabilities)
            }
        }
      }

    return BoundVideoSession(
      camera = camera,
      preview = preview,
      videoCapture = videoCapture,
      capabilities = capabilities,
    )
  }

  @OptIn(ExperimentalCamera2Interop::class)
  fun applyVideoCamera2Options(
    camera: Camera,
    profile: CameraHardwareProfile?,
    stabilization: StabilizationSelection,
  ) {
    if (profile == null) return
    try {
      val c2 = Camera2CameraControl.from(camera.cameraControl)
      val builder = CaptureRequestOptions.Builder()

      val stab = profile.videoAndStabilization
      when (stabilization) {
        StabilizationSelection.OIS,
        StabilizationSelection.AUTO -> {
          if (stab.isOisSupported) {
            builder.setCaptureRequestOption(
              CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
              CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON,
            )
          }
        }
        StabilizationSelection.EIS -> {
          if (stab.isEisSupported) {
            val mode =
              if (
                stab.isPreviewStabilizationSupported &&
                  Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
              ) {
                CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
              } else {
                CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
              }
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, mode)
          }
        }
        StabilizationSelection.OFF -> {
          if (stab.isOisSupported) {
            builder.setCaptureRequestOption(
              CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
              CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF,
            )
          }
          if (stab.isEisSupported || stab.isPreviewStabilizationSupported) {
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
              CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF,
            )
          }
        }
      }
      c2.setCaptureRequestOptions(builder.build())
    } catch (_: Exception) {
      // Ignore transient camera session update errors
    }
  }

  fun startVideoRecording(
    context: Context,
    videoCapture: VideoCapture<Recorder>,
    withAudio: Boolean,
    sensorRotation: Int,
    onStarted: () -> Unit,
    onPaused: () -> Unit,
    onResumed: () -> Unit,
    onStatus: (durationMs: Long, numBytes: Long, amplitude: Float, hasAudio: Boolean) -> Unit,
    onFinalizedSuccess: (uri: Uri, displayName: String, durationMs: Long) -> Unit,
    onFinalizedError: (String) -> Unit,
  ): Recording? {
    return try {
      videoCapture.targetRotation = sensorRotation
      val (outputOptions, displayName) = MediaStoreVideoSaver.createVideoOutputOptions(context)
      var pending = videoCapture.output.prepareRecording(context, outputOptions)

      val hasMicPerm =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
          PackageManager.PERMISSION_GRANTED
      if (withAudio && hasMicPerm) {
        pending = pending.withAudioEnabled()
      }

      var lastRecordedDurationMs = 0L
      val mainExecutor = ContextCompat.getMainExecutor(context)

      pending.start(mainExecutor) { event ->
        when (event) {
          is VideoRecordEvent.Start -> onStarted()
          is VideoRecordEvent.Pause -> onPaused()
          is VideoRecordEvent.Resume -> onResumed()
          is VideoRecordEvent.Status -> {
            val stats = event.recordingStats
            val durationMs = stats.recordedDurationNanos / 1_000_000L
            lastRecordedDurationMs = durationMs
            val audioStats = stats.audioStats
            onStatus(
              durationMs,
              stats.numBytesRecorded,
              audioStats.audioAmplitude.toFloat().coerceIn(0f, 1f),
              audioStats.hasAudio(),
            )
          }
          is VideoRecordEvent.Finalize -> {
            if (!event.hasError()) {
              val uri = event.outputResults.outputUri
              val finalDurationMs =
                (event.recordingStats.recordedDurationNanos / 1_000_000L)
                  .takeIf { it > 0L } ?: lastRecordedDurationMs
              onFinalizedSuccess(uri, displayName, finalDurationMs)
            } else {
              onFinalizedError("Video recording error (${event.error}): ${event.cause?.localizedMessage ?: "Recording stopped"}")
            }
          }
        }
      }
    } catch (e: Exception) {
      onFinalizedError(e.localizedMessage ?: "Unable to start video recording")
      null
    }
  }
}
