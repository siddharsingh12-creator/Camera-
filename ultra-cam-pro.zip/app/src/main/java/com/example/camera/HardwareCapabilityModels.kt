package com.example.camera

import android.hardware.camera2.CameraMetadata
import android.util.Size
import kotlin.math.roundToInt

enum class CameraLensRole(val displayName: String, val shortTag: String) {
  WIDE("Main Wide", "WIDE"),
  ULTRA_WIDE("Ultra-Wide", "UW"),
  TELEPHOTO("Telephoto", "TELE"),
  MACRO("Macro", "MACRO"),
  FRONT("Front", "FRONT"),
  EXTERNAL("External", "EXT"),
  AUXILIARY("Auxiliary", "AUX"),
}

enum class HardwareLevelLabel(val displayName: String) {
  LEGACY("LEGACY"),
  LIMITED("LIMITED"),
  FULL("FULL"),
  LEVEL_3("LEVEL_3"),
  EXTERNAL("EXTERNAL"),
  UNKNOWN("UNKNOWN"),
}

enum class StabilizationSelection(val label: String) {
  AUTO("AUTO"),
  OIS("OIS"),
  EIS("EIS"),
  OFF("OFF"),
}

enum class WhiteBalanceOption(
  val camera2Mode: Int,
  val label: String,
  val shortTag: String,
  val approxKelvin: Int?,
) {
  AUTO(CameraMetadata.CONTROL_AWB_MODE_AUTO, "Auto WB", "AWB", null),
  DAYLIGHT(CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT, "Daylight", "DAY", 5500),
  CLOUDY_DAYLIGHT(CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT, "Cloudy", "CLD", 6500),
  SHADE(CameraMetadata.CONTROL_AWB_MODE_SHADE, "Shade", "SHD", 7500),
  INCANDESCENT(CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT, "Tungsten", "TUNG", 2800),
  FLUORESCENT(CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT, "Fluorescent", "FLR", 4000),
  WARM_FLUORESCENT(CameraMetadata.CONTROL_AWB_MODE_WARM_FLUORESCENT, "Warm Fluor", "WFL", 3200),
  TWILIGHT(CameraMetadata.CONTROL_AWB_MODE_TWILIGHT, "Twilight", "TWL", 4800),
  MANUAL_KELVIN(CameraMetadata.CONTROL_AWB_MODE_OFF, "Manual Kelvin", "K", 5500);

  companion object {
    fun fromCamera2AwbMode(mode: Int): WhiteBalanceOption? =
      entries.firstOrNull { it != MANUAL_KELVIN && it.camera2Mode == mode }
  }
}

enum class CaptureOutputFormat(val label: String, val shortTag: String) {
  JPEG("JPEG", "JPG"),
  RAW_DNG("RAW (DNG)", "RAW"),
  RAW_PLUS_JPEG("RAW + JPEG", "RAW+JPG"),
}

enum class ProControlTab(val label: String) {
  ISO("ISO"),
  SHUTTER("SHUTTER"),
  EV("EV"),
  WB("WB"),
  FOCUS("FOCUS"),
  FORMAT("FMT"),
  TOOLS("TOOLS"),
  PRESETS("PRESETS"),
}

enum class FocusPeakingColor(val label: String) {
  CYAN("Cyan"),
  RED("Red"),
  YELLOW("Amber"),
}

data class ResolutionSpec(
  val width: Int,
  val height: Int,
) {
  val pixelCount: Long
    get() = width.toLong() * height.toLong()

  val megapixels: Double
    get() = pixelCount / 1_000_000.0

  val aspectRatioLabel: String
    get() {
      if (width <= 0 || height <= 0) return "—"
      val gcd = computeGcd(width, height)
      val w = width / gcd
      val h = height / gcd
      return when {
        w == 4 && h == 3 || w == 3 && h == 4 -> "4:3"
        w == 16 && h == 9 || w == 9 && h == 16 -> "16:9"
        w == 3 && h == 2 || w == 2 && h == 3 -> "3:2"
        w == 1 && h == 1 -> "1:1"
        else -> "$w:$h"
      }
    }

  fun formattedLabel(): String = "${width}×${height} (${String.format("%.1f", megapixels)} MP · $aspectRatioLabel)"

  companion object {
    fun fromSize(size: Size): ResolutionSpec = ResolutionSpec(size.width, size.height)

    private fun computeGcd(a: Int, b: Int): Int {
      var x = a
      var y = b
      while (y != 0) {
        val t = x % y
        x = y
        y = t
      }
      return if (x == 0) 1 else x
    }
  }
}

data class OpticalZoomStop(
  val label: String,
  val zoomRatio: Float?,
  val targetCameraId: String,
  val focalLengthMm: Float,
  val equiv35mmFocal: Float?,
  val role: CameraLensRole,
  val isPhysicalSubSensor: Boolean,
)

data class FocusCapabilities(
  val isAutoFocusSupported: Boolean = false,
  val afModes: List<String> = emptyList(),
  val isManualFocusSupported: Boolean = false,
  val minimumFocusDistanceDiopters: Float = 0f,
  val minimumFocusDistanceCm: Float? = null,
  val focusCalibrationLabel: String = "Fixed Focus",
  val isMacroFocusCapable: Boolean = false,
  val unsupportedManualReason: String? = null,
)

data class ExposureAndRawCapabilities(
  val isManualExposureSupported: Boolean = false,
  val isAeLockSupported: Boolean = false,
  val isoRange: IntRange? = null,
  val shutterRangeNs: LongRange? = null,
  val exposureCompRange: IntRange = 0..0,
  val exposureCompStep: Float = 0f,
  val supportedAwbModes: List<WhiteBalanceOption> = listOf(WhiteBalanceOption.AUTO),
  val isManualKelvinSupported: Boolean = false,
  val unsupportedWhiteBalanceReason: String? = null,
  val isRawSupported: Boolean = false,
  val isCameraXRawOnlySupported: Boolean = false,
  val isCameraXRawJpegSupported: Boolean = false,
  val rawOutputSizes: List<ResolutionSpec> = emptyList(),
  val unsupportedManualReason: String? = null,
  val unsupportedRawReason: String? = null,
)

data class VideoAndStabilizationCapabilities(
  val supportedFpsRanges: List<IntRange> = emptyList(),
  val highSpeedFpsRanges: List<IntRange> = emptyList(),
  val supportedVideoSizes: List<ResolutionSpec> = emptyList(),
  val isOisSupported: Boolean = false,
  val isEisSupported: Boolean = false,
  val isPreviewStabilizationSupported: Boolean = false,
  val unsupportedStabilizationReason: String? = null,
)

data class CameraHardwareProfile(
  val cameraId: String,
  val isLogicalMultiCamera: Boolean,
  val isPhysicalOnlySensor: Boolean,
  val isCameraXSelectable: Boolean,
  val parentLogicalCameraId: String?,
  val physicalCameraIds: List<String>,
  val lensFacing: Int,
  val facingLabel: String,
  val role: CameraLensRole,
  val hardwareLevel: HardwareLevelLabel,
  val isBackwardCompatible: Boolean,
  val isBurstSupported: Boolean = false,
  val isZslSupported: Boolean = false,
  val supportedSceneModes: List<Int> = emptyList(),
  val hasMacroAfMode: Boolean = false,
  val supportsDepthOutput: Boolean = false,
  val supportsNaturalPipelineControls: Boolean = false,
  val supportsLowLightBoostAe: Boolean = false,
  val focalLengthsMm: List<Float>,
  val equivalent35mmFocalLength: Float?,
  val horizontalFovDegrees: Float?,
  val sensorPhysicalSizeMm: String?,
  val apertures: List<Float>,
  val maxDigitalZoom: Float,
  val controlZoomRatioRange: ClosedFloatingPointRange<Float>?,
  val hasOpticalZoom: Boolean,
  val opticalZoomExplanation: String,
  val opticalZoomStops: List<OpticalZoomStop>,
  val supportedJpegResolutions: List<ResolutionSpec>,
  val highResJpegResolutions: List<ResolutionSpec>,
  val maxJpegResolution: ResolutionSpec?,
  val hasFlash: Boolean,
  val flashExplanation: String,
  val focusCapabilities: FocusCapabilities,
  val exposureAndRaw: ExposureAndRawCapabilities,
  val videoAndStabilization: VideoAndStabilizationCapabilities,
  val capabilityTags: List<String>,
) {
  val primaryFocalSummary: String
    get() {
      val mm = focalLengthsMm.firstOrNull()
      val eq = equivalent35mmFocalLength?.roundToInt()
      return when {
        mm != null && eq != null -> "${String.format("%.2f", mm)}mm (${eq}mm eq)"
        mm != null -> "${String.format("%.2f", mm)}mm"
        else -> "Unknown focal length"
      }
    }
}

data class DeviceCameraInventory(
  val allLogicalAndStandaloneCameras: List<CameraHardwareProfile> = emptyList(),
  val allPhysicalSensors: List<CameraHardwareProfile> = emptyList(),
  val selectableCameras: List<CameraHardwareProfile> = emptyList(),
  val backCameraCount: Int = 0,
  val frontCameraCount: Int = 0,
  val externalCameraCount: Int = 0,
  val hasUltraWide: Boolean = false,
  val hasTelephoto: Boolean = false,
  val hasMacro: Boolean = false,
  val hasLevelSensor: Boolean = false,
  val hasMotionSensorForPanorama: Boolean = false,
  val isInitialized: Boolean = false,
  val scanError: String? = null,
) {
  fun findSelectableById(cameraId: String?): CameraHardwareProfile? =
    selectableCameras.firstOrNull { it.cameraId == cameraId }

  fun selectableForFacing(facing: Int): List<CameraHardwareProfile> =
    selectableCameras.filter { it.lensFacing == facing }
}

data class ManualProSettings(
  val isProPanelOpen: Boolean = false,
  val activeProTab: ProControlTab = ProControlTab.ISO,
  val isManualIsoEnabled: Boolean = false,
  val manualIso: Int? = null,
  val isManualShutterEnabled: Boolean = false,
  val manualShutterNs: Long? = null,
  val whiteBalanceMode: WhiteBalanceOption = WhiteBalanceOption.AUTO,
  val manualKelvin: Int = 5500,
  val isManualFocusEnabled: Boolean = false,
  val manualFocusDiopters: Float = 0f,
  val isExposureLockEnabled: Boolean = false,
  val captureOutputFormat: CaptureOutputFormat = CaptureOutputFormat.JPEG,
  val isRawCaptureEnabled: Boolean = false,
  val stabilizationSelection: StabilizationSelection = StabilizationSelection.AUTO,
  val isFocusPeakingEnabled: Boolean = false,
  val focusPeakingColor: FocusPeakingColor = FocusPeakingColor.CYAN,
  val isHistogramEnabled: Boolean = false,
  val isZebraEnabled: Boolean = false,
  val zebraThresholdPercent: Int = 95,
)

data class LiveExposureTelemetry(
  val iso: Int? = null,
  val shutterNs: Long? = null,
  val aperture: Float? = null,
  val focusDistanceDiopters: Float? = null,
  val aeState: Int? = null,
  val afState: Int? = null,
  val awbState: Int? = null,
  val colorGainSummary: String? = null,
)

data class ProPreset(
  val id: String,
  val name: String,
  val isManualIsoEnabled: Boolean = false,
  val manualIso: Int? = null,
  val isManualShutterEnabled: Boolean = false,
  val manualShutterNs: Long? = null,
  val whiteBalanceMode: WhiteBalanceOption = WhiteBalanceOption.AUTO,
  val manualKelvin: Int = 5500,
  val isManualFocusEnabled: Boolean = false,
  val manualFocusDiopters: Float = 0f,
  val exposureCompIndex: Int = 0,
  val captureOutputFormat: CaptureOutputFormat = CaptureOutputFormat.JPEG,
  val stabilizationSelection: StabilizationSelection = StabilizationSelection.AUTO,
  val isFocusPeakingEnabled: Boolean = false,
  val isHistogramEnabled: Boolean = false,
  val isZebraEnabled: Boolean = false,
)

class FrameAnalysisData(
  val lumaBins: FloatArray = FloatArray(48),
  val redBins: FloatArray = FloatArray(48),
  val greenBins: FloatArray = FloatArray(48),
  val blueBins: FloatArray = FloatArray(48),
  val highlightClippedPercent: Float = 0f,
  val shadowClippedPercent: Float = 0f,
  val focusPeakingPoints: FloatArray = FloatArray(0),
  val zebraHighlightPoints: FloatArray = FloatArray(0),
  val zebraShadowPoints: FloatArray = FloatArray(0),
  val meanLuma: Float = 0.5f,
  val highlightShare: Float = 0f,
  val shadowShare: Float = 0f,
  val isWarmScene: Boolean = false,
)
