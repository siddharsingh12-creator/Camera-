package com.example.camera

import android.content.Context
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.util.Size
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionFilter
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

object PhotographyModeManager {

  suspend fun probeExtensionsManager(
    context: Context,
    cameraProvider: ProcessCameraProvider,
  ): ExtensionsManager? =
    try {
      suspendCancellableCoroutine { cont ->
        val future = ExtensionsManager.getInstanceAsync(context, cameraProvider)
        future.addListener(
          {
            val mgr =
              try {
                future.get()
              } catch (_: Exception) {
                null
              }
            if (cont.isActive) cont.resume(mgr)
          },
          ContextCompat.getMainExecutor(context),
        )
      }
    } catch (_: Exception) {
      null
    }

  fun evaluateModeCapabilities(
    profile: CameraHardwareProfile?,
    inventory: DeviceCameraInventory,
    selector: CameraSelector?,
    cameraInfo: CameraInfo?,
    extensionsManager: ExtensionsManager?,
  ): CameraModeCapabilities {
    if (profile == null) {
      return CameraModeCapabilities(isInitialized = inventory.isInitialized)
    }

    val extHdr =
      selector != null &&
        extensionsManager?.safeIsAvailable(selector, ExtensionMode.HDR) == true
    val extNight =
      selector != null &&
        extensionsManager?.safeIsAvailable(selector, ExtensionMode.NIGHT) == true
    val extBokeh =
      selector != null &&
        extensionsManager?.safeIsAvailable(selector, ExtensionMode.BOKEH) == true
    val extAuto =
      selector != null &&
        extensionsManager?.safeIsAvailable(selector, ExtensionMode.AUTO) == true
    val extFace =
      selector != null &&
        extensionsManager?.safeIsAvailable(selector, ExtensionMode.FACE_RETOUCH) == true

    val cameraXLowLightBoost =
      try {
        cameraInfo?.isLowLightBoostSupported == true
      } catch (_: Exception) {
        false
      }

    val scenes = profile.supportedSceneModes
    val hasSceneHdr = scenes.contains(CameraMetadata.CONTROL_SCENE_MODE_HDR)
    val hasSceneNight = scenes.contains(CameraMetadata.CONTROL_SCENE_MODE_NIGHT)
    val hasSceneNightPortrait = scenes.contains(CameraMetadata.CONTROL_SCENE_MODE_NIGHT_PORTRAIT)

    // Same-facing sensors checked for Macro capability
    val sameFacing = inventory.selectableForFacing(profile.lensFacing)
    val dedicatedMacro = sameFacing.firstOrNull { it.role == CameraLensRole.MACRO }
    val closeFocusCapable =
      sameFacing
        .filter {
          it.role == CameraLensRole.MACRO ||
            it.focusCapabilities.minimumFocusDistanceDiopters >= 8.0f ||
            it.hasMacroAfMode
        }
        .maxByOrNull {
          (if (it.role == CameraLensRole.MACRO) 100f else 0f) +
            it.focusCapabilities.minimumFocusDistanceDiopters
        }
    val bestMacroId = dedicatedMacro?.cameraId ?: closeFocusCapable?.cameraId

    // 1. Standard Photo
    val standardAvail =
      ModeAvailability(
        mode = PhotographyMode.STANDARD,
        isSupported = true,
        backendLabel = "CameraX Max Quality",
        reason = "Full native sensor capture with CAPTURE_MODE_MAXIMIZE_QUALITY",
      )

    // 2. HDR
    val hdrAvail =
      when {
        extHdr ->
          ModeAvailability(
            mode = PhotographyMode.HDR,
            isSupported = true,
            backendLabel = "CameraX HDR Extension",
            reason = "Hardware vendor multi-frame HDR computational extension",
            extensionMode = ExtensionMode.HDR,
          )
        hasSceneHdr ->
          ModeAvailability(
            mode = PhotographyMode.HDR,
            isSupported = true,
            backendLabel = "Camera2 HDR Scene",
            reason = "Hardware CONTROL_SCENE_MODE_HDR on sensor",
          )
        else ->
          ModeAvailability(
            mode = PhotographyMode.HDR,
            isSupported = false,
            backendLabel = "Unsupported",
            reason = "Unavailable: Device lacks CameraX HDR Extension & Camera2 HDR scene mode",
          )
      }

    // 3. Night Photography
    val nightAvail =
      when {
        extNight ->
          ModeAvailability(
            mode = PhotographyMode.NIGHT,
            isSupported = true,
            backendLabel = "CameraX Night Extension",
            reason = "Hardware vendor multi-exposure Night extension",
            extensionMode = ExtensionMode.NIGHT,
          )
        hasSceneNight ->
          ModeAvailability(
            mode = PhotographyMode.NIGHT,
            isSupported = true,
            backendLabel = "Camera2 Night Scene",
            reason = "Hardware CONTROL_SCENE_MODE_NIGHT exposure mode",
          )
        else ->
          ModeAvailability(
            mode = PhotographyMode.NIGHT,
            isSupported = false,
            backendLabel = "Unsupported",
            reason = "Unavailable: Device lacks CameraX Night Extension & Night scene mode",
          )
      }

    // 4. Portrait Mode (Vendor Bokeh Extension OR Real On-Device ML Kit Selfie Segmentation)
    val portraitAvail =
      when {
        extBokeh ->
          ModeAvailability(
            mode = PhotographyMode.PORTRAIT,
            isSupported = true,
            backendLabel = "CameraX Bokeh Extension",
            reason = "Vendor hardware Bokeh depth blur preserving natural skin texture",
            extensionMode = ExtensionMode.BOKEH,
          )
        profile.supportsDepthOutput ->
          ModeAvailability(
            mode = PhotographyMode.PORTRAIT,
            isSupported = true,
            backendLabel = "Depth + ML Kit Seg",
            reason = "Hardware DEPTH_OUTPUT + on-device neural subject segmentation",
          )
        else ->
          ModeAvailability(
            mode = PhotographyMode.PORTRAIT,
            isSupported = true,
            backendLabel = "On-Device ML Kit Seg",
            reason = "Real on-device ML Kit foreground segmentation (untouched skin detail)",
          )
      }

    // 5. Macro Mode
    val macroAvail =
      if (closeFocusCapable != null) {
        val cm = closeFocusCapable.focusCapabilities.minimumFocusDistanceCm
        val detail =
          when {
            dedicatedMacro != null -> "Dedicated Macro Sensor (CAM ${dedicatedMacro.cameraId})"
            closeFocusCapable.hasMacroAfMode -> "Hardware AF_MODE_MACRO"
            cm != null -> String.format("Close Focus (min %.1f cm)", cm)
            else -> "Macro Focus Hardware"
          }
        ModeAvailability(
          mode = PhotographyMode.MACRO,
          isSupported = true,
          backendLabel = detail,
          reason = detail,
        )
      } else {
        ModeAvailability(
          mode = PhotographyMode.MACRO,
          isSupported = false,
          backendLabel = "Unsupported",
          reason = "Unavailable: No dedicated macro lens, AF_MODE_MACRO, or <=12.5cm focus sensor",
        )
      }

    // 6. High Resolution Mode
    val maxMp = profile.maxJpegResolution?.megapixels ?: 0.0
    val hasHighRes =
      profile.highResJpegResolutions.isNotEmpty() || maxMp >= 12.0
    val highResAvail =
      if (hasHighRes) {
        val res = profile.maxJpegResolution
        val resText =
          if (res != null) "${res.width}×${res.height} (${String.format("%.1f", res.megapixels)} MP)"
          else "Native High-Res"
        ModeAvailability(
          mode = PhotographyMode.HIGH_RES,
          isSupported = true,
          backendLabel = resText,
          reason = "Native full-pixel stream ($resText) without upscaling",
        )
      } else {
        ModeAvailability(
          mode = PhotographyMode.HIGH_RES,
          isSupported = false,
          backendLabel = "Unsupported",
          reason = "Unavailable: Sensor max output is under 12 MP with no high-res JPEG stream",
        )
      }

    // 7. Panorama Mode (requires motion sensor + ZNCC image alignment & stitcher)
    val panoAvail =
      if (inventory.hasMotionSensorForPanorama) {
        ModeAvailability(
          mode = PhotographyMode.PANORAMA,
          isSupported = true,
          backendLabel = "ZNCC Image Stitcher",
          reason = "Real multi-frame ZNCC alignment & cosine-feather stitching with gyro tracking",
        )
      } else {
        ModeAvailability(
          mode = PhotographyMode.PANORAMA,
          isSupported = false,
          backendLabel = "Unsupported",
          reason = "Unavailable: Device lacks orientation/gyroscope sensor for guided panorama sweep",
        )
      }

    // 8. Low Light Mode
    val supportsManualFrameStack =
      profile.exposureAndRaw.isManualExposureSupported &&
        (profile.exposureAndRaw.shutterRangeNs?.last ?: 0L) >= 125_000_000L
    val lowLightAvail =
      when {
        cameraXLowLightBoost ->
          ModeAvailability(
            mode = PhotographyMode.LOW_LIGHT,
            isSupported = true,
            backendLabel = "CameraX Low Light Boost",
            reason = "Hardware CameraX enableLowLightBoostAsync real-time brightness AE",
          )
        profile.supportsLowLightBoostAe ->
          ModeAvailability(
            mode = PhotographyMode.LOW_LIGHT,
            isSupported = true,
            backendLabel = "Camera2 Low Light AE",
            reason = "Camera2 AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY",
          )
        supportsManualFrameStack ->
          ModeAvailability(
            mode = PhotographyMode.LOW_LIGHT,
            isSupported = true,
            backendLabel = "3-Frame Align Stack",
            reason = "Aligned 3-frame temporal average stack for low-light shadow SNR recovery",
          )
        hasSceneNightPortrait ->
          ModeAvailability(
            mode = PhotographyMode.LOW_LIGHT,
            isSupported = true,
            backendLabel = "Camera2 Night Portrait",
            reason = "Hardware CONTROL_SCENE_MODE_NIGHT_PORTRAIT",
          )
        else ->
          ModeAvailability(
            mode = PhotographyMode.LOW_LIGHT,
            isSupported = false,
            backendLabel = "Unsupported",
            reason = "Unavailable: Sensor lacks Low Light Boost, Night Portrait, or >=1/8s manual stacking",
          )
      }

    // 9. Auto Scene Mode
    val autoSceneAvail =
      when {
        extAuto ->
          ModeAvailability(
            mode = PhotographyMode.AUTO_SCENE,
            isSupported = true,
            backendLabel = "CameraX Auto Extension",
            reason = "Vendor CameraX AUTO computational scene detection",
            extensionMode = ExtensionMode.AUTO,
          )
        scenes.isNotEmpty() ->
          ModeAvailability(
            mode = PhotographyMode.AUTO_SCENE,
            isSupported = true,
            backendLabel = "Scene Telemetry (${scenes.size})",
            reason = "Live frame telemetry mapping to ${scenes.size} Camera2 scene modes",
          )
        else ->
          ModeAvailability(
            mode = PhotographyMode.AUTO_SCENE,
            isSupported = false,
            backendLabel = "Unsupported",
            reason = "Unavailable: Sensor lacks CameraX Auto Extension & Camera2 CONTROL_SCENE_MODES",
          )
      }

    // 10. Natural Color Mode
    val naturalAvail =
      if (profile.supportsNaturalPipelineControls) {
        ModeAvailability(
          mode = PhotographyMode.NATURAL_COLOR,
          isSupported = true,
          backendLabel = "Natural ISP Pipeline",
          reason = "Disables aggressive edge oversharpening & uses high-quality natural tone curve",
        )
      } else {
        ModeAvailability(
          mode = PhotographyMode.NATURAL_COLOR,
          isSupported = false,
          backendLabel = "Unsupported",
          reason = "Unavailable: LEGACY hardware restricts Camera2 edge/tonemap pipeline control",
        )
      }

    val map =
      mapOf(
        PhotographyMode.STANDARD to standardAvail,
        PhotographyMode.HDR to hdrAvail,
        PhotographyMode.NIGHT to nightAvail,
        PhotographyMode.PORTRAIT to portraitAvail,
        PhotographyMode.MACRO to macroAvail,
        PhotographyMode.HIGH_RES to highResAvail,
        PhotographyMode.PANORAMA to panoAvail,
        PhotographyMode.LOW_LIGHT to lowLightAvail,
        PhotographyMode.AUTO_SCENE to autoSceneAvail,
        PhotographyMode.NATURAL_COLOR to naturalAvail,
      )

    return CameraModeCapabilities(
      cameraId = profile.cameraId,
      modes = map,
      hasExtensionHdr = extHdr,
      hasExtensionNight = extNight,
      hasExtensionBokeh = extBokeh,
      hasExtensionAuto = extAuto,
      hasExtensionFaceRetouch = extFace,
      isCameraXLowLightBoostSupported = cameraXLowLightBoost,
      bestMacroCameraId = bestMacroId,
      isInitialized = true,
    )
  }

  private fun ExtensionsManager.safeIsAvailable(selector: CameraSelector, mode: Int): Boolean {
    return try {
      isExtensionAvailable(selector, mode)
    } catch (_: Exception) {
      false
    }
  }

  fun classifyLiveScene(
    analysis: FrameAnalysisData?,
    telemetry: LiveExposureTelemetry,
  ): DetectedSceneType {
    if (analysis == null) return DetectedSceneType.GENERAL
    val focusD = telemetry.focusDistanceDiopters ?: 0f
    return when {
      focusD >= 6.5f -> DetectedSceneType.MACRO
      analysis.meanLuma < 0.22f || (telemetry.iso ?: 0) >= 1200 -> DetectedSceneType.LOW_LIGHT
      analysis.highlightShare >= 0.04f && analysis.shadowShare >= 0.08f -> DetectedSceneType.HIGH_CONTRAST
      analysis.isWarmScene && analysis.meanLuma > 0.32f -> DetectedSceneType.PORTRAIT
      analysis.meanLuma > 0.42f && analysis.shadowShare < 0.04f -> DetectedSceneType.LANDSCAPE
      else -> DetectedSceneType.GENERAL
    }
  }

  fun buildCaptureResolutionSelectorForMode(
    mode: PhotographyMode,
    aspectRatio: PreviewAspectRatio,
    profile: CameraHardwareProfile?,
  ): ResolutionSelector {
    if (mode == PhotographyMode.HIGH_RES && profile?.maxJpegResolution != null) {
      val maxSpec = profile.maxJpegResolution
      val target = Size(maxSpec.width, maxSpec.height)
      val exactMaxFilter = ResolutionFilter { supportedSizes, _ ->
        val exact =
          supportedSizes.filter {
            (it.width == target.width && it.height == target.height) ||
              (it.width == target.height && it.height == target.width)
          }
        if (exact.isNotEmpty()) exact
        else supportedSizes.sortedByDescending { it.width.toLong() * it.height.toLong() }
      }
      return ResolutionSelector.Builder()
        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
        .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
        .setResolutionFilter(exactMaxFilter)
        .build()
    }
    return CameraCapabilitiesHelper.buildCaptureResolutionSelector(aspectRatio)
  }

  @OptIn(ExperimentalCamera2Interop::class)
  fun applyModeHardwareOptions(
    camera: Camera,
    mode: PhotographyMode,
    modeCapabilities: CameraModeCapabilities,
    profile: CameraHardwareProfile?,
    manual: ManualProSettings,
    liveTelemetry: LiveExposureTelemetry,
    detectedScene: DetectedSceneType,
  ) {
    try {
      if (modeCapabilities.isCameraXLowLightBoostSupported) {
        camera.cameraControl.enableLowLightBoostAsync(mode == PhotographyMode.LOW_LIGHT)
      }
    } catch (_: Exception) {
      // Ignore if unsupported
    }

    if (profile == null) return
    val hasManualExposureOverride =
      profile.exposureAndRaw.isManualExposureSupported &&
        (manual.isManualIsoEnabled || manual.isManualShutterEnabled)

    try {
      val camera2Control = Camera2CameraControl.from(camera.cameraControl)
      val builder = CaptureRequestOptions.Builder()
      val scenes = profile.supportedSceneModes

      when (mode) {
        PhotographyMode.HDR -> {
          if (
            !hasManualExposureOverride &&
              !modeCapabilities.hasExtensionHdr &&
              scenes.contains(CameraMetadata.CONTROL_SCENE_MODE_HDR)
          ) {
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_MODE,
              CameraMetadata.CONTROL_MODE_USE_SCENE_MODE,
            )
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_SCENE_MODE,
              CameraMetadata.CONTROL_SCENE_MODE_HDR,
            )
          }
        }

        PhotographyMode.NIGHT -> {
          if (
            !hasManualExposureOverride &&
              !modeCapabilities.hasExtensionNight &&
              scenes.contains(CameraMetadata.CONTROL_SCENE_MODE_NIGHT)
          ) {
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_MODE,
              CameraMetadata.CONTROL_MODE_USE_SCENE_MODE,
            )
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_SCENE_MODE,
              CameraMetadata.CONTROL_SCENE_MODE_NIGHT,
            )
          }
        }

        PhotographyMode.MACRO -> {
          if (!manual.isManualFocusEnabled) {
            if (profile.hasMacroAfMode) {
              builder.setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_MODE,
                CameraMetadata.CONTROL_AF_MODE_MACRO,
              )
            } else if (profile.focusCapabilities.isAutoFocusSupported) {
              builder.setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_MODE,
                CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE,
              )
            }
          }
        }

        PhotographyMode.NATURAL_COLOR -> {
          if (profile.supportsNaturalPipelineControls) {
            builder.setCaptureRequestOption(
              CaptureRequest.EDGE_MODE,
              CameraMetadata.EDGE_MODE_OFF,
            )
            builder.setCaptureRequestOption(
              CaptureRequest.NOISE_REDUCTION_MODE,
              CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY,
            )
            builder.setCaptureRequestOption(
              CaptureRequest.TONEMAP_MODE,
              CameraMetadata.TONEMAP_MODE_HIGH_QUALITY,
            )
            builder.setCaptureRequestOption(
              CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
              CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY,
            )
          }
        }

        PhotographyMode.HIGH_RES -> {
          if (profile.supportsNaturalPipelineControls) {
            builder.setCaptureRequestOption(
              CaptureRequest.NOISE_REDUCTION_MODE,
              CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY,
            )
            builder.setCaptureRequestOption(
              CaptureRequest.TONEMAP_MODE,
              CameraMetadata.TONEMAP_MODE_HIGH_QUALITY,
            )
          }
        }

        PhotographyMode.LOW_LIGHT -> {
          if (
            !hasManualExposureOverride &&
              !modeCapabilities.isCameraXLowLightBoostSupported &&
              Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM &&
              profile.supportsLowLightBoostAe
          ) {
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_AE_MODE,
              CameraMetadata.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY,
            )
          } else if (
            !hasManualExposureOverride &&
              scenes.contains(CameraMetadata.CONTROL_SCENE_MODE_NIGHT_PORTRAIT)
          ) {
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_MODE,
              CameraMetadata.CONTROL_MODE_USE_SCENE_MODE,
            )
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_SCENE_MODE,
              CameraMetadata.CONTROL_SCENE_MODE_NIGHT_PORTRAIT,
            )
          }
        }

        PhotographyMode.AUTO_SCENE -> {
          if (!hasManualExposureOverride && !modeCapabilities.hasExtensionAuto && scenes.isNotEmpty()) {
            val mappedScene =
              when (detectedScene) {
                DetectedSceneType.LOW_LIGHT ->
                  scenes.firstOrNull { it == CameraMetadata.CONTROL_SCENE_MODE_NIGHT }
                DetectedSceneType.HIGH_CONTRAST ->
                  scenes.firstOrNull { it == CameraMetadata.CONTROL_SCENE_MODE_HDR }
                DetectedSceneType.PORTRAIT ->
                  scenes.firstOrNull {
                    it == CameraMetadata.CONTROL_SCENE_MODE_PORTRAIT ||
                      it == CameraMetadata.CONTROL_SCENE_MODE_FACE_PRIORITY
                  }
                DetectedSceneType.LANDSCAPE ->
                  scenes.firstOrNull { it == CameraMetadata.CONTROL_SCENE_MODE_LANDSCAPE }
                DetectedSceneType.MACRO,
                DetectedSceneType.GENERAL -> null
              }
            if (mappedScene != null) {
              builder.setCaptureRequestOption(
                CaptureRequest.CONTROL_MODE,
                CameraMetadata.CONTROL_MODE_USE_SCENE_MODE,
              )
              builder.setCaptureRequestOption(CaptureRequest.CONTROL_SCENE_MODE, mappedScene)
            } else {
              builder.setCaptureRequestOption(
                CaptureRequest.CONTROL_MODE,
                CameraMetadata.CONTROL_MODE_AUTO,
              )
            }
          }
        }

        PhotographyMode.STANDARD,
        PhotographyMode.PORTRAIT,
        PhotographyMode.PANORAMA -> {
          if (!hasManualExposureOverride && liveTelemetry.aeState != null) {
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_MODE,
              CameraMetadata.CONTROL_MODE_AUTO,
            )
          }
        }
      }

      camera2Control.setCaptureRequestOptions(builder.build())
    } catch (_: Exception) {
      // Session in transition or extension camera control ignores override
    }
  }
}
