package com.example.camera

import android.net.Uri
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture

enum class PreviewAspectRatio(val label: String, val ratioValue: Float?) {
  RATIO_4_3(label = "4:3", ratioValue = 3f / 4f),
  RATIO_16_9(label = "16:9", ratioValue = 9f / 16f),
  RATIO_1_1(label = "1:1", ratioValue = 1f),
  FULL(label = "FULL", ratioValue = null),
}

enum class ShutterTimer(val seconds: Int, val label: String) {
  OFF(0, "OFF"),
  SEC_3(3, "3s"),
  SEC_5(5, "5s"),
  SEC_10(10, "10s");

  fun next(): ShutterTimer =
    when (this) {
      OFF -> SEC_3
      SEC_3 -> SEC_5
      SEC_5 -> SEC_10
      SEC_10 -> OFF
    }
}

enum class CaptureSpeedMode(val label: String) {
  MAX_QUALITY("MAX QUALITY"),
  QUICK("QUICK"),
}

enum class FlashSetting(val imageCaptureMode: Int, val label: String) {
  OFF(ImageCapture.FLASH_MODE_OFF, "OFF"),
  AUTO(ImageCapture.FLASH_MODE_AUTO, "AUTO"),
  ON(ImageCapture.FLASH_MODE_ON, "ON");

  fun next(): FlashSetting =
    when (this) {
      OFF -> AUTO
      AUTO -> ON
      ON -> OFF
    }
}

enum class LensOption(val selector: CameraSelector, val lensFacing: Int, val label: String) {
  BACK(CameraSelector.DEFAULT_BACK_CAMERA, CameraSelector.LENS_FACING_BACK, "REAR"),
  FRONT(CameraSelector.DEFAULT_FRONT_CAMERA, CameraSelector.LENS_FACING_FRONT, "FRONT");

  fun toggle(): LensOption = if (this == BACK) FRONT else BACK
}

enum class CameraPermissionStatus {
  NOT_REQUESTED,
  DENIED,
  PERMANENTLY_DENIED,
  GRANTED,
}

data class SensorCapabilities(
  val maxSensorJpegSize: Size? = null,
  val activeCaptureSize: Size? = null,
  val hasFlash: Boolean = false,
  val minZoomRatio: Float = 1f,
  val maxZoomRatio: Float = 1f,
  val currentZoomRatio: Float = 1f,
  val exposureRange: IntRange = 0..0,
  val exposureStep: Float = 0f,
  val currentExposureIndex: Int = 0,
) {
  val displayedResolution: Size?
    get() = activeCaptureSize ?: maxSensorJpegSize

  val megapixels: Double?
    get() =
      displayedResolution?.let { size ->
        (size.width.toDouble() * size.height.toDouble()) / 1_000_000.0
      }
}

data class CapturedPhotoInfo(
  val uri: Uri,
  val width: Int,
  val height: Int,
  val sizeBytes: Long,
  val displayName: String,
  val timestampMillis: Long,
  val isVideo: Boolean = false,
  val durationMs: Long = 0L,
  val mimeType: String = "image/jpeg",
  val videoFrameRate: Int? = null,
  val isHdrVideo: Boolean = false,
) {
  val megapixels: Double
    get() = (width.toDouble() * height.toDouble()) / 1_000_000.0
}

data class FocusPointState(
  val x: Float,
  val y: Float,
  val timestamp: Long,
  val isLockedSuccess: Boolean? = null,
)

data class CameraUiState(
  val permissionStatus: CameraPermissionStatus = CameraPermissionStatus.NOT_REQUESTED,
  val captureDomain: AppCaptureDomain = AppCaptureDomain.PHOTO,
  val deviceInventory: DeviceCameraInventory = DeviceCameraInventory(),
  val activeCameraId: String? = null,
  val activeHardwareProfile: CameraHardwareProfile? = null,
  val lensOption: LensOption = LensOption.BACK,
  val hasBackCamera: Boolean = true,
  val hasFrontCamera: Boolean = true,
  val aspectRatio: PreviewAspectRatio = PreviewAspectRatio.RATIO_4_3,
  val flashSetting: FlashSetting = FlashSetting.OFF,
  val shutterTimer: ShutterTimer = ShutterTimer.OFF,
  val countdownRemainingSeconds: Int? = null,
  val captureSpeedMode: CaptureSpeedMode = CaptureSpeedMode.MAX_QUALITY,
  val isBurstModeEnabled: Boolean = false,
  val burstProgressCount: Int? = null,
  val isGridEnabled: Boolean = false,
  val isLevelEnabled: Boolean = false,
  val isFrontMirrorEnabled: Boolean = true,
  val isVolumeShutterEnabled: Boolean = true,
  val isCapturing: Boolean = false,
  val shutterBlinkCounter: Int = 0,
  val sensorCapabilities: SensorCapabilities = SensorCapabilities(),
  val manualSettings: ManualProSettings = ManualProSettings(),
  val liveTelemetry: LiveExposureTelemetry = LiveExposureTelemetry(),
  val frameAnalysis: FrameAnalysisData? = null,
  val customPresets: List<ProPreset> = emptyList(),
  val photographyMode: PhotographyMode = PhotographyMode.STANDARD,
  val modeCapabilities: CameraModeCapabilities = CameraModeCapabilities(),
  val detectedAutoScene: DetectedSceneType = DetectedSceneType.GENERAL,
  val panoramaState: PanoramaSessionState = PanoramaSessionState(),
  val videoCapabilities: CameraVideoCapabilities = CameraVideoCapabilities(),
  val videoSettings: VideoSettings = VideoSettings(),
  val videoRecordingState: VideoRecordingState = VideoRecordingState(),
  val isVideoSettingsOpen: Boolean = false,
  val isHardwareInspectorOpen: Boolean = false,
  val inspectorSelectedCameraId: String? = null,
  val lastCapturedPhoto: CapturedPhotoInfo? = null,
  val inspectedPhoto: CapturedPhotoInfo? = null,
  val isPhotoViewerOpen: Boolean = false,
  val focusPoint: FocusPointState? = null,
  val statusBanner: String? = null,
  val errorMessage: String? = null,
)
