package com.example.camera

import android.util.Range
import android.util.Size
import androidx.camera.core.DynamicRange
import androidx.camera.video.Quality

enum class AppCaptureDomain(val label: String) {
  PHOTO("PHOTO"),
  VIDEO("VIDEO"),
}

enum class VideoQualityOption(
  val shortLabel: String,
  val displayName: String,
  val nominalWidth: Int,
  val nominalHeight: Int,
) {
  SD_480P("480p", "SD 480p", 720, 480),
  HD_720P("720p", "HD 720p", 1280, 720),
  FHD_1080P("1080p", "Full HD 1080p", 1920, 1080),
  QHD_2K("2K", "2K QHD 1440p", 2560, 1440),
  UHD_4K("4K", "4K UHD 2160p", 3840, 2160);

  fun toCameraXQualityOrNull(): Quality? =
    when (this) {
      SD_480P -> Quality.SD
      HD_720P -> Quality.HD
      FHD_1080P -> Quality.FHD
      QHD_2K -> null // CameraX 1.5.0 Quality exposes SD/HD/FHD/UHD; 2K enabled only if a Quality resolves to 2K
      UHD_4K -> Quality.UHD
    }
}

enum class VideoFpsOption(
  val fps: Int,
  val label: String,
  val isHighSpeed: Boolean,
) {
  FPS_24(24, "24", false),
  FPS_30(30, "30", false),
  FPS_60(60, "60", false),
  FPS_120(120, "120", true),
  FPS_240(240, "240", true),
}

enum class VideoBitrateOption(
  val label: String,
  val bitrateBps: Int?,
) {
  AUTO("AUTO", null),
  MBPS_10("10M", 10_000_000),
  MBPS_20("20M", 20_000_000),
  MBPS_35("35M", 35_000_000),
  MBPS_50("50M", 50_000_000),
  MBPS_80("80M", 80_000_000),
}

enum class AudioPermissionStatus {
  NOT_REQUESTED,
  GRANTED,
  DENIED,
  PERMANENTLY_DENIED,
}

data class VideoQualityAvailability(
  val quality: VideoQualityOption,
  val isSupported: Boolean,
  val resolvedSize: Size? = null,
  val cameraXQuality: Quality? = quality.toCameraXQualityOrNull(),
  val reason: String,
)

data class VideoFpsAvailability(
  val fpsOption: VideoFpsOption,
  val isSupported: Boolean,
  val matchedRange: Range<Int>? = null,
  val supportedHighSpeedQualities: List<Quality> = emptyList(),
  val reason: String,
)

data class VideoHdrAvailability(
  val isSupported: Boolean = false,
  val dynamicRange: DynamicRange = DynamicRange.SDR,
  val label: String = "SDR",
  val supportedQualities: List<VideoQualityOption> = emptyList(),
  val reason: String = "10-bit HDR video unavailable on this sensor",
)

data class CameraVideoCapabilities(
  val cameraId: String? = null,
  val qualities: Map<VideoQualityOption, VideoQualityAvailability> =
    mapOf(
      VideoQualityOption.FHD_1080P to
        VideoQualityAvailability(
          quality = VideoQualityOption.FHD_1080P,
          isSupported = true,
          resolvedSize = Size(1920, 1080),
          cameraXQuality = Quality.FHD,
          reason = "Full HD 1080p baseline video",
        )
    ),
  val fpsOptions: Map<VideoFpsOption, VideoFpsAvailability> =
    mapOf(
      VideoFpsOption.FPS_30 to
        VideoFpsAvailability(
          fpsOption = VideoFpsOption.FPS_30,
          isSupported = true,
          matchedRange = Range(30, 30),
          reason = "Standard 30 fps",
        )
    ),
  val hdrAvailability: VideoHdrAvailability = VideoHdrAvailability(),
  val isVideoStabilizationSupported: Boolean = false,
  val isOisSupported: Boolean = false,
  val isEisSupported: Boolean = false,
  val maxEncoderBitrateBps: Int = 100_000_000,
  val isInitialized: Boolean = false,
) {
  fun availabilityOf(quality: VideoQualityOption): VideoQualityAvailability =
    qualities[quality]
      ?: VideoQualityAvailability(
        quality = quality,
        isSupported = false,
        reason = "${quality.displayName} unsupported on this sensor",
      )

  fun availabilityOf(fps: VideoFpsOption): VideoFpsAvailability =
    fpsOptions[fps]
      ?: VideoFpsAvailability(
        fpsOption = fps,
        isSupported = false,
        reason = "${fps.fps} fps unsupported on this sensor",
      )

  fun isBitrateSupported(option: VideoBitrateOption): Boolean {
    val bps = option.bitrateBps ?: return true
    return bps <= maxEncoderBitrateBps
  }

  fun supportedQualityList(): List<VideoQualityOption> =
    VideoQualityOption.entries.filter { availabilityOf(it).isSupported }

  fun supportedFpsList(): List<VideoFpsOption> =
    VideoFpsOption.entries.filter { availabilityOf(it).isSupported }
}

data class VideoSettings(
  val quality: VideoQualityOption = VideoQualityOption.FHD_1080P,
  val fps: VideoFpsOption = VideoFpsOption.FPS_30,
  val bitrate: VideoBitrateOption = VideoBitrateOption.AUTO,
  val stabilization: StabilizationSelection = StabilizationSelection.AUTO,
  val isHdrEnabled: Boolean = false,
  val isAudioEnabled: Boolean = true,
  val isSlowMotionBakedIn: Boolean = false,
  val isTorchEnabled: Boolean = false,
)

data class VideoRecordingState(
  val isRecording: Boolean = false,
  val isPaused: Boolean = false,
  val isFinalizing: Boolean = false,
  val elapsedDurationMs: Long = 0L,
  val recordedBytes: Long = 0L,
  val audioAmplitude: Float = 0f,
  val hasAudioTrack: Boolean = false,
  val audioPermissionStatus: AudioPermissionStatus = AudioPermissionStatus.NOT_REQUESTED,
  val pendingRecordWithAudio: Boolean = false,
) {
  val canPauseOrResume: Boolean
    get() = isRecording && !isFinalizing
}
