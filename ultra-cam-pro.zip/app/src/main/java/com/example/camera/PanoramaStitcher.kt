package com.example.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sqrt

object PanoramaStitcher {

  data class PixelFrame(
    val width: Int,
    val height: Int,
    val pixels: IntArray,
  )

  data class AlignmentOffset(
    val dx: Int,
    val dy: Int,
    val correlationScore: Double,
  )

  data class StitchResult(
    val uri: Uri,
    val displayName: String,
    val width: Int,
    val height: Int,
    val stitchedFrames: Int,
  )

  fun decodeScaledFrame(
    jpegBytes: ByteArray,
    rotationDegrees: Int,
    mirrorHorizontal: Boolean,
    maxHeightPx: Int = 1440,
  ): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

    var sample = 1
    val approxOutH =
      if (rotationDegrees == 90 || rotationDegrees == 270) bounds.outWidth else bounds.outHeight
    while (approxOutH / (sample * 2) >= maxHeightPx) {
      sample *= 2
    }

    val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
    val raw = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size, decodeOpts) ?: return null

    val oriented =
      if (rotationDegrees != 0 || mirrorHorizontal) {
        val matrix = Matrix().apply {
          if (rotationDegrees != 0) postRotate(rotationDegrees.toFloat())
          if (mirrorHorizontal) postScale(-1f, 1f, raw.width / 2f, raw.height / 2f)
        }
        val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
        if (rotated !== raw) raw.recycle()
        rotated
      } else {
        raw
      }

    if (oriented.height > maxHeightPx) {
      val targetW = ((oriented.width.toFloat() / oriented.height.toFloat()) * maxHeightPx).roundToInt().coerceAtLeast(64)
      val scaled = Bitmap.createScaledBitmap(oriented, targetW, maxHeightPx, true)
      if (scaled !== oriented) oriented.recycle()
      return scaled
    }
    return oriented
  }

  /**
   * Finds the horizontal (dx > 0) and vertical (dy) displacement of `curr` relative to `prev`
   * using Zero-Mean Normalized Cross-Correlation (ZNCC) over a coarse luma pyramid followed by
   * fine local refinement. Returns null if no credible overlap correlation is found.
   */
  fun estimatePairwiseAlignment(
    prev: PixelFrame,
    curr: PixelFrame,
  ): AlignmentOffset? {
    val targetSmallH = 96
    val scale = (prev.height.toFloat() / targetSmallH.toFloat()).coerceAtLeast(1f)
    val swPrev = (prev.width / scale).roundToInt().coerceAtLeast(24)
    val shPrev = (prev.height / scale).roundToInt().coerceAtLeast(24)
    val swCurr = (curr.width / scale).roundToInt().coerceAtLeast(24)
    val shCurr = (curr.height / scale).roundToInt().coerceAtLeast(24)

    val lumPrev = downsampleLuma(prev, swPrev, shPrev)
    val lumCurr = downsampleLuma(curr, swCurr, shCurr)

    // Template strip on the right third of `prev`
    val patchW = (swPrev * 0.26f).roundToInt().coerceIn(8, swPrev / 2)
    val patchXEnd = (swPrev * 0.94f).roundToInt().coerceIn(patchW + 1, swPrev)
    val patchX = patchXEnd - patchW
    val patchY = (shPrev * 0.16f).roundToInt()
    val patchH = (shPrev * 0.68f).roundToInt().coerceIn(8, shPrev - patchY)

    val minDx = (swPrev * 0.12f).roundToInt().coerceAtLeast(4)
    val maxDx = (swPrev * 0.85f).roundToInt().coerceAtMost(swPrev - 4)
    val maxDy = (shPrev * 0.14f).roundToInt().coerceAtLeast(2)

    var bestSmallDx = -1
    var bestSmallDy = 0
    var bestZncc = -1.0

    for (dy in -maxDy..maxDy) {
      val currPatchY = patchY - dy
      if (currPatchY < 0 || currPatchY + patchH > shCurr) continue
      for (dx in minDx..maxDx) {
        val currPatchX = patchX - dx
        if (currPatchX < 0 || currPatchX + patchW > swCurr) continue

        val zncc =
          computeZncc(
            a = lumPrev,
            aStride = swPrev,
            ax = patchX,
            ay = patchY,
            b = lumCurr,
            bStride = swCurr,
            bx = currPatchX,
            by = currPatchY,
            w = patchW,
            h = patchH,
          )
        if (zncc > bestZncc) {
          bestZncc = zncc
          bestSmallDx = dx
          bestSmallDy = dy
        }
      }
    }

    if (bestSmallDx <= 0 || bestZncc < 0.30) {
      return null
    }

    // Refine at full resolution around the coarse peak
    val coarseFullDx = (bestSmallDx * scale).roundToInt()
    val coarseFullDy = (bestSmallDy * scale).roundToInt()
    val refineWindow = (scale * 2f).roundToInt().coerceIn(2, 12)

    val fullPrevX = (patchX * scale).roundToInt().coerceIn(0, prev.width - 24)
    val fullPrevY = (patchY * scale).roundToInt().coerceIn(0, prev.height - 24)
    val fullPatchW = (patchW * scale).roundToInt().coerceIn(16, prev.width - fullPrevX)
    val fullPatchH = (patchH * scale).roundToInt().coerceIn(16, prev.height - fullPrevY)

    var bestFullDx = coarseFullDx
    var bestFullDy = coarseFullDy
    var bestFullZncc = bestZncc

    val fullLumPrev = extractLuma(prev)
    val fullLumCurr = extractLuma(curr)
    val step = if (prev.width > 400) 2 else 1

    for (dy in (coarseFullDy - refineWindow)..(coarseFullDy + refineWindow)) {
      val cy = fullPrevY - dy
      if (cy < 0 || cy + fullPatchH > curr.height) continue
      for (dx in (coarseFullDx - refineWindow)..(coarseFullDx + refineWindow)) {
        if (dx <= 0) continue
        val cx = fullPrevX - dx
        if (cx < 0 || cx + fullPatchW > curr.width) continue

        val score =
          computeZncc(
            a = fullLumPrev,
            aStride = prev.width,
            ax = fullPrevX,
            ay = fullPrevY,
            b = fullLumCurr,
            bStride = curr.width,
            bx = cx,
            by = cy,
            w = fullPatchW,
            h = fullPatchH,
            step = step,
          )
        if (score > bestFullZncc) {
          bestFullZncc = score
          bestFullDx = dx
          bestFullDy = dy
        }
      }
    }

    return AlignmentOffset(dx = bestFullDx, dy = bestFullDy, correlationScore = bestFullZncc)
  }

  /**
   * Aligns and blends a sequence of overlapping pixel frames into a seamless cropped panorama.
   */
  fun stitchFrames(frames: List<PixelFrame>): Pair<PixelFrame, Int>? {
    if (frames.size < 2) return null

    val placedFrames = mutableListOf(frames.first())
    val originsX = mutableListOf(0)
    val originsY = mutableListOf(0)

    var accumX = 0
    var accumY = 0
    for (i in 1 until frames.size) {
      val prev = placedFrames.last()
      val curr = frames[i]
      val alignment = estimatePairwiseAlignment(prev, curr) ?: continue
      if (alignment.dx < 12) continue
      accumX += alignment.dx
      accumY += alignment.dy
      placedFrames.add(curr)
      originsX.add(accumX)
      originsY.add(accumY)
    }

    if (placedFrames.size < 2) return null

    var minValidTop = Int.MIN_VALUE
    var maxValidBottom = Int.MAX_VALUE
    for (i in placedFrames.indices) {
      val top = originsY[i]
      val bot = top + placedFrames[i].height
      if (top > minValidTop) minValidTop = top
      if (bot < maxValidBottom) maxValidBottom = bot
    }
    val outHeight = maxValidBottom - minValidTop
    if (outHeight < 24) return null

    val totalWidth =
      placedFrames.indices.maxOf { i -> originsX[i] + placedFrames[i].width }
    if (totalWidth <= 0) return null

    val outPixels = IntArray(totalWidth * outHeight)
    val first = placedFrames[0]
    val firstRelYStart = minValidTop - originsY[0]
    for (row in 0 until outHeight) {
      val srcOff = (firstRelYStart + row) * first.width
      val dstOff = row * totalWidth
      System.arraycopy(first.pixels, srcOff, outPixels, dstOff, first.width)
    }

    var currentFrontierRight = originsX[0] + first.width
    var accumGain = 1f

    for (i in 1 until placedFrames.size) {
      val slice = placedFrames[i]
      val ox = originsX[i]
      val oy = originsY[i]
      val overlapEnd = minOf(currentFrontierRight, ox + slice.width)
      val overlapWidth = (overlapEnd - ox).coerceAtLeast(1)

      val gain = computeExposureGain(outPixels, totalWidth, slice, ox, oy, minValidTop, outHeight, overlapEnd)
      accumGain = (accumGain * 0.4f + gain * 0.6f).coerceIn(0.86f, 1.16f)

      val srcRelYStart = minValidTop - oy
      for (row in 0 until outHeight) {
        val dstRowOff = row * totalWidth
        val srcRowOff = (srcRelYStart + row) * slice.width

        for (x in ox until (ox + slice.width)) {
          val sx = x - ox
          val sp = slice.pixels[srcRowOff + sx]
          val sr = ((((sp ushr 16) and 0xFF) * accumGain).roundToInt()).coerceIn(0, 255)
          val sg = ((((sp ushr 8) and 0xFF) * accumGain).roundToInt()).coerceIn(0, 255)
          val sb = (((sp and 0xFF) * accumGain).roundToInt()).coerceIn(0, 255)

          if (x < currentFrontierRight) {
            val t = ((x - ox).toFloat() / overlapWidth.toFloat()).coerceIn(0f, 1f)
            val wNew = 0.5f - 0.5f * cos(PI * t).toFloat()
            val wOld = 1f - wNew
            val ep = outPixels[dstRowOff + x]
            val er = (ep ushr 16) and 0xFF
            val eg = (ep ushr 8) and 0xFF
            val eb = ep and 0xFF
            val r = (er * wOld + sr * wNew).roundToInt().coerceIn(0, 255)
            val g = (eg * wOld + sg * wNew).roundToInt().coerceIn(0, 255)
            val b = (eb * wOld + sb * wNew).roundToInt().coerceIn(0, 255)
            outPixels[dstRowOff + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
          } else {
            outPixels[dstRowOff + x] = (0xFF shl 24) or (sr shl 16) or (sg shl 8) or sb
          }
        }
      }
      currentFrontierRight = maxOf(currentFrontierRight, ox + slice.width)
    }

    return PixelFrame(width = totalWidth, height = outHeight, pixels = outPixels) to placedFrames.size
  }

  fun stitchAndSaveToMediaStore(
    context: Context,
    bitmaps: List<Bitmap>,
  ): StitchResult? {
    if (bitmaps.size < 2) return null
    val frames =
      bitmaps.map { bmp ->
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        PixelFrame(bmp.width, bmp.height, px)
      }
    val (stitched, stitchedCount) = stitchFrames(frames) ?: return null
    val outBitmap =
      Bitmap.createBitmap(stitched.pixels, stitched.width, stitched.height, Bitmap.Config.ARGB_8888)
    return try {
      val saved = MediaStorePhotoSaver.saveBitmapToMediaStore(context, outBitmap, prefix = "PANO_")
      saved?.let {
        StitchResult(
          uri = it.first,
          displayName = it.second,
          width = stitched.width,
          height = stitched.height,
          stitchedFrames = stitchedCount,
        )
      }
    } finally {
      outBitmap.recycle()
    }
  }

  private fun computeExposureGain(
    canvasPixels: IntArray,
    canvasWidth: Int,
    slice: PixelFrame,
    ox: Int,
    oy: Int,
    minValidTop: Int,
    outHeight: Int,
    overlapEnd: Int,
  ): Float {
    if (overlapEnd <= ox) return 1f
    var oldSum = 0.0
    var newSum = 0.0
    var count = 0
    val srcRelYStart = minValidTop - oy
    val rowStep = (outHeight / 32).coerceAtLeast(1)
    val colStep = ((overlapEnd - ox) / 32).coerceAtLeast(1)

    var row = 0
    while (row < outHeight) {
      val dstOff = row * canvasWidth
      val srcOff = (srcRelYStart + row) * slice.width
      var x = ox
      while (x < overlapEnd) {
        val ep = canvasPixels[dstOff + x]
        val sp = slice.pixels[srcOff + (x - ox)]
        val oldL =
          0.299 * ((ep ushr 16) and 0xFF) +
            0.587 * ((ep ushr 8) and 0xFF) +
            0.114 * (ep and 0xFF)
        val newL =
          0.299 * ((sp ushr 16) and 0xFF) +
            0.587 * ((sp ushr 8) and 0xFF) +
            0.114 * (sp and 0xFF)
        oldSum += oldL
        newSum += newL
        count++
        x += colStep
      }
      row += rowStep
    }
    if (count == 0 || newSum < 8.0) return 1f
    return (oldSum / newSum).toFloat().coerceIn(0.86f, 1.16f)
  }

  private fun downsampleLuma(frame: PixelFrame, targetW: Int, targetH: Int): FloatArray {
    val out = FloatArray(targetW * targetH)
    for (y in 0 until targetH) {
      val sy = ((y * frame.height) / targetH).coerceIn(0, frame.height - 1)
      val rowOff = sy * frame.width
      val outOff = y * targetW
      for (x in 0 until targetW) {
        val sx = ((x * frame.width) / targetW).coerceIn(0, frame.width - 1)
        val p = frame.pixels[rowOff + sx]
        val r = (p ushr 16) and 0xFF
        val g = (p ushr 8) and 0xFF
        val b = p and 0xFF
        out[outOff + x] = 0.299f * r + 0.587f * g + 0.114f * b
      }
    }
    return out
  }

  private fun extractLuma(frame: PixelFrame): FloatArray {
    val out = FloatArray(frame.pixels.size)
    for (i in frame.pixels.indices) {
      val p = frame.pixels[i]
      val r = (p ushr 16) and 0xFF
      val g = (p ushr 8) and 0xFF
      val b = p and 0xFF
      out[i] = 0.299f * r + 0.587f * g + 0.114f * b
    }
    return out
  }

  private fun computeZncc(
    a: FloatArray,
    aStride: Int,
    ax: Int,
    ay: Int,
    b: FloatArray,
    bStride: Int,
    bx: Int,
    by: Int,
    w: Int,
    h: Int,
    step: Int = 1,
  ): Double {
    var sumA = 0.0
    var sumB = 0.0
    var count = 0
    var dy = 0
    while (dy < h) {
      val aOff = (ay + dy) * aStride + ax
      val bOff = (by + dy) * bStride + bx
      var dx = 0
      while (dx < w) {
        sumA += a[aOff + dx]
        sumB += b[bOff + dx]
        count++
        dx += step
      }
      dy += step
    }
    if (count == 0) return -1.0
    val meanA = sumA / count
    val meanB = sumB / count

    var num = 0.0
    var denA = 0.0
    var denB = 0.0
    dy = 0
    while (dy < h) {
      val aOff = (ay + dy) * aStride + ax
      val bOff = (by + dy) * bStride + bx
      var dx = 0
      while (dx < w) {
        val da = a[aOff + dx] - meanA
        val db = b[bOff + dx] - meanB
        num += da * db
        denA += da * da
        denB += db * db
        dx += step
      }
      dy += step
    }
    val denom = sqrt(denA * denB)
    return if (denom < 1e-6) -1.0 else num / denom
  }
}
