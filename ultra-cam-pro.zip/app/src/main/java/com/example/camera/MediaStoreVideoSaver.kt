package com.example.camera

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.camera.video.MediaStoreOutputOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MediaStoreVideoSaver {

  private const val ALBUM_FOLDER = "UltraCamPro"
  private const val FILENAME_PATTERN = "yyyyMMdd_HHmmss_SSS"

  fun createVideoOutputOptions(context: Context): Pair<MediaStoreOutputOptions, String> {
    val timestamp = SimpleDateFormat(FILENAME_PATTERN, Locale.US).format(Date())
    val displayName = "VID_${timestamp}.mp4"

    val contentValues =
      ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          put(
            MediaStore.Video.Media.RELATIVE_PATH,
            "${Environment.DIRECTORY_MOVIES}/$ALBUM_FOLDER",
          )
        }
      }

    val options =
      MediaStoreOutputOptions.Builder(
          context.contentResolver,
          MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
        )
        .setContentValues(contentValues)
        .build()

    return options to displayName
  }

  fun inspectVideoInfo(
    context: Context,
    uri: Uri,
    fallbackName: String? = null,
    fallbackDurationMs: Long = 0L,
    fps: Int? = null,
    isHdr: Boolean = false,
  ): CapturedPhotoInfo {
    var displayName = fallbackName ?: "Video.mp4"
    var width = 0
    var height = 0
    var sizeBytes = 0L
    var durationMs = fallbackDurationMs
    var timestamp = System.currentTimeMillis()

    val projection =
      arrayOf(
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.WIDTH,
        MediaStore.Video.Media.HEIGHT,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.DATE_TAKEN,
      )

    try {
      context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
          val nameIdx = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
          val widthIdx = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
          val heightIdx = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)
          val sizeIdx = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
          val durIdx = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
          val dateIdx = cursor.getColumnIndex(MediaStore.Video.Media.DATE_TAKEN)

          if (nameIdx >= 0) displayName = cursor.getString(nameIdx) ?: displayName
          if (widthIdx >= 0) width = cursor.getInt(widthIdx)
          if (heightIdx >= 0) height = cursor.getInt(heightIdx)
          if (sizeIdx >= 0) sizeBytes = cursor.getLong(sizeIdx)
          if (durIdx >= 0) {
            val d = cursor.getLong(durIdx)
            if (d > 0L) durationMs = d
          }
          if (dateIdx >= 0) {
            val taken = cursor.getLong(dateIdx)
            if (taken > 0L) timestamp = taken
          }
        }
      }
    } catch (_: Exception) {
      // Fallback to MediaMetadataRetriever below
    }

    if (width <= 0 || height <= 0 || durationMs <= 0L) {
      val retriever = MediaMetadataRetriever()
      try {
        retriever.setDataSource(context, uri)
        val w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        val h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rot = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        val dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        if (w > 0 && h > 0) {
          if (rot == 90 || rot == 270) {
            width = h
            height = w
          } else {
            width = w
            height = h
          }
        }
        if (dur > 0L) durationMs = dur
      } catch (_: Exception) {
        // Ignore if URI unavailable
      } finally {
        runCatching { retriever.release() }
      }
    }

    if (sizeBytes <= 0L) {
      try {
        context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
          if (afd.length > 0L) sizeBytes = afd.length
        }
      } catch (_: Exception) {
        // Ignore
      }
    }

    return CapturedPhotoInfo(
      uri = uri,
      width = width,
      height = height,
      sizeBytes = sizeBytes,
      displayName = displayName,
      timestampMillis = timestamp,
      isVideo = true,
      durationMs = durationMs,
      mimeType = "video/mp4",
      videoFrameRate = fps,
      isHdrVideo = isHdr,
    )
  }

  fun extractVideoThumbnail(context: Context, uri: Uri): Bitmap? {
    val retriever = MediaMetadataRetriever()
    return try {
      retriever.setDataSource(context, uri)
      retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        ?: retriever.frameAtTime
    } catch (_: Exception) {
      null
    } finally {
      runCatching { retriever.release() }
    }
  }

  fun queryLatestAppMedia(context: Context): CapturedPhotoInfo? {
    val latestPhoto = MediaStorePhotoSaver.queryLatestAppPhoto(context)
    val latestVideo = queryLatestVideo(context)
    return when {
      latestPhoto == null -> latestVideo
      latestVideo == null -> latestPhoto
      latestVideo.timestampMillis >= latestPhoto.timestampMillis -> latestVideo
      else -> latestPhoto
    }
  }

  private fun queryLatestVideo(context: Context): CapturedPhotoInfo? {
    return try {
      val projection =
        arrayOf(
          MediaStore.Video.Media._ID,
          MediaStore.Video.Media.DISPLAY_NAME,
          MediaStore.Video.Media.WIDTH,
          MediaStore.Video.Media.HEIGHT,
          MediaStore.Video.Media.SIZE,
          MediaStore.Video.Media.DURATION,
          MediaStore.Video.Media.DATE_TAKEN,
        )
      val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"
      context.contentResolver
        .query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, sortOrder)
        ?.use { cursor ->
          if (cursor.moveToFirst()) {
            val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
            val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
            inspectVideoInfo(context, uri)
          } else {
            null
          }
        }
    } catch (_: Exception) {
      null
    }
  }

  fun formatDurationMs(durationMs: Long): String {
    val totalSecs = (durationMs.coerceAtLeast(0L) / 1000L)
    val hours = totalSecs / 3600L
    val mins = (totalSecs % 3600L) / 60L
    val secs = totalSecs % 60L
    return if (hours > 0L) {
      String.format(Locale.US, "%d:%02d:%02d", hours, mins, secs)
    } else {
      String.format(Locale.US, "%02d:%02d", mins, secs)
    }
  }
}
