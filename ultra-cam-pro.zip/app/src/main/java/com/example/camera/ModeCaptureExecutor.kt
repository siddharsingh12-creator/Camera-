package com.example.camera

import android.content.Context
import android.net.Uri
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import java.util.concurrent.Executor
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

data class SavedCaptureResult(
  val uri: Uri,
  val displayName: String,
  val rawSaved: Boolean,
)

object ModeCaptureExecutor {

  suspend fun captureInMemoryJpeg(
    imageCapture: ImageCapture,
    cameraExecutor: Executor,
  ): Result<Pair<ByteArray, Int>> = runCatching {
    suspendCancellableCoroutine { continuation ->
      imageCapture.takePicture(
        cameraExecutor,
        object : ImageCapture.OnImageCapturedCallback() {
          override fun onCaptureSuccess(image: ImageProxy) {
            try {
              val buffer = image.planes.firstOrNull()?.buffer
              if (buffer == null) {
                if (continuation.isActive) {
                  continuation.resumeWithException(IllegalStateException("Missing JPEG image buffer"))
                }
              } else {
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                if (continuation.isActive) {
                  continuation.resume(bytes to image.imageInfo.rotationDegrees)
                }
              }
            } finally {
              image.close()
            }
          }

          override fun onError(exception: ImageCaptureException) {
            if (continuation.isActive) continuation.resumeWithException(exception)
          }
        },
      )
    }
  }

  suspend fun executeCaptureForMode(
    context: Context,
    imageCapture: ImageCapture,
    cameraExecutor: Executor,
    photographyMode: PhotographyMode,
    modeCapabilities: CameraModeCapabilities,
    isFrontCamera: Boolean,
    mirrorFrontCamera: Boolean,
    aspectRatio: PreviewAspectRatio,
    outputFormat: CaptureOutputFormat,
  ): Result<SavedCaptureResult> = runCatching {
    when {
      photographyMode == PhotographyMode.PORTRAIT && !modeCapabilities.hasExtensionBokeh -> {
        val (bytes, rot) = captureInMemoryJpeg(imageCapture, cameraExecutor).getOrThrow()
        val saved =
          PortraitProcessor.processAndSavePortrait(
            context = context,
            jpegBytes = bytes,
            rotationDegrees = rot,
            mirrorHorizontal = isFrontCamera && mirrorFrontCamera,
          )
            ?: throw IllegalStateException("Portrait segmentation save failed")
        SavedCaptureResult(saved.first, saved.second, rawSaved = false)
      }

      photographyMode == PhotographyMode.LOW_LIGHT &&
        !modeCapabilities.isCameraXLowLightBoostSupported &&
        modeCapabilities.availabilityOf(PhotographyMode.LOW_LIGHT).backendLabel ==
          "3-Frame Align Stack" -> {
        val frames = mutableListOf<Pair<ByteArray, Int>>()
        repeat(3) {
          captureInMemoryJpeg(imageCapture, cameraExecutor).getOrNull()?.let { frames.add(it) }
        }
        if (frames.isEmpty()) {
          throw IllegalStateException("Unable to capture low-light stack frames")
        }
        val saved =
          MultiFrameLowLightProcessor.alignAndBlendToMediaStore(
            context = context,
            capturedFrames = frames,
            mirrorHorizontal = isFrontCamera && mirrorFrontCamera,
          )
            ?: throw IllegalStateException("Low-light alignment save failed")
        SavedCaptureResult(saved.first, saved.second, rawSaved = false)
      }

      else ->
        executeStandardSingleCapture(
          context = context,
          imageCapture = imageCapture,
          cameraExecutor = cameraExecutor,
          isFrontCamera = isFrontCamera,
          mirrorFrontCamera = mirrorFrontCamera,
          aspectRatio = aspectRatio,
          outputFormat = outputFormat,
        ).getOrThrow()
    }
  }

  suspend fun executeStandardSingleCapture(
    context: Context,
    imageCapture: ImageCapture,
    cameraExecutor: Executor,
    isFrontCamera: Boolean,
    mirrorFrontCamera: Boolean,
    aspectRatio: PreviewAspectRatio,
    outputFormat: CaptureOutputFormat,
  ): Result<SavedCaptureResult> = runCatching {
    suspendCancellableCoroutine { continuation ->
      when (outputFormat) {
        CaptureOutputFormat.RAW_DNG -> {
          val (rawOptions, rawName) = MediaStorePhotoSaver.createRawOutputFileOptions(context)
          imageCapture.takePicture(
            rawOptions,
            cameraExecutor,
            object : ImageCapture.OnImageSavedCallback {
              override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                val savedUri = outputFileResults.savedUri
                if (continuation.isActive) {
                  if (savedUri != null) {
                    continuation.resume(SavedCaptureResult(savedUri, rawName, true))
                  } else {
                    continuation.resumeWithException(IllegalStateException("Missing RAW DNG URI"))
                  }
                }
              }

              override fun onError(exception: ImageCaptureException) {
                if (continuation.isActive) continuation.resumeWithException(exception)
              }
            },
          )
        }

        CaptureOutputFormat.RAW_PLUS_JPEG -> {
          val (rawOptions, _) = MediaStorePhotoSaver.createRawOutputFileOptions(context)
          val (jpegOptions, jpegName) =
            MediaStorePhotoSaver.createOutputFileOptions(context, isFrontCamera, mirrorFrontCamera)
          imageCapture.takePicture(
            rawOptions,
            jpegOptions,
            cameraExecutor,
            object : ImageCapture.OnImageSavedCallback {
              override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                val savedUri = outputFileResults.savedUri ?: return
                val mime = context.contentResolver.getType(savedUri) ?: ""
                if (!mime.contains("dng", ignoreCase = true) && continuation.isActive) {
                  continuation.resume(SavedCaptureResult(savedUri, jpegName, true))
                }
              }

              override fun onError(exception: ImageCaptureException) {
                if (continuation.isActive) continuation.resumeWithException(exception)
              }
            },
          )
        }

        CaptureOutputFormat.JPEG -> {
          if (aspectRatio == PreviewAspectRatio.RATIO_1_1) {
            imageCapture.takePicture(
              cameraExecutor,
              object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                  try {
                    val saved =
                      MediaStorePhotoSaver.saveSquareCropFromImageProxy(
                        context = context,
                        image = image,
                        isFrontCamera = isFrontCamera,
                        mirrorFrontCamera = mirrorFrontCamera,
                      )
                    if (continuation.isActive) {
                      if (saved != null) {
                        continuation.resume(SavedCaptureResult(saved.first, saved.second, false))
                      } else {
                        continuation.resumeWithException(IllegalStateException("Failed to crop 1:1 image"))
                      }
                    }
                  } finally {
                    image.close()
                  }
                }

                override fun onError(exception: ImageCaptureException) {
                  if (continuation.isActive) continuation.resumeWithException(exception)
                }
              },
            )
          } else {
            val (jpegOptions, jpegName) =
              MediaStorePhotoSaver.createOutputFileOptions(context, isFrontCamera, mirrorFrontCamera)
            imageCapture.takePicture(
              jpegOptions,
              cameraExecutor,
              object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                  val savedUri = outputFileResults.savedUri
                  if (continuation.isActive) {
                    if (savedUri != null) {
                      continuation.resume(SavedCaptureResult(savedUri, jpegName, false))
                    } else {
                      continuation.resumeWithException(IllegalStateException("Missing MediaStore URI"))
                    }
                  }
                }

                override fun onError(exception: ImageCaptureException) {
                  if (continuation.isActive) continuation.resumeWithException(exception)
                }
              },
            )
          }
        }
      }
    }
  }
}
