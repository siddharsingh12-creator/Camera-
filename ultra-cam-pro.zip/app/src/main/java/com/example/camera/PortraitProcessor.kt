package com.example.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt
import kotlinx.coroutines.suspendCancellableCoroutine

object PortraitProcessor {

  private val segmenter by lazy {
    val options =
      SelfieSegmenterOptions.Builder()
        .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
        .enableRawSizeMask()
        .build()
    Segmentation.getClient(options)
  }

  suspend fun processAndSavePortrait(
    context: Context,
    jpegBytes: ByteArray,
    rotationDegrees: Int,
    mirrorHorizontal: Boolean,
  ): Pair<Uri, String>? {
    val rawBitmap = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size) ?: return null
    val oriented =
      if (rotationDegrees != 0 || mirrorHorizontal) {
        val m = Matrix().apply {
          if (rotationDegrees != 0) postRotate(rotationDegrees.toFloat())
          if (mirrorHorizontal) postScale(-1f, 1f, rawBitmap.width / 2f, rawBitmap.height / 2f)
        }
        val rotated = Bitmap.createBitmap(rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, m, true)
        if (rotated !== rawBitmap) rawBitmap.recycle()
        rotated
      } else {
        rawBitmap
      }

    return try {
      val mask = runSegmentation(oriented)
      val buffer = mask.buffer
      buffer.rewind()
      val maskW = mask.width
      val maskH = mask.height
      val confidences = FloatArray(maskW * maskH)
      var fgCount = 0
      for (i in confidences.indices) {
        val c = buffer.float
        confidences[i] = c
        if (c >= 0.55f) fgCount++
      }

      val fgFraction = fgCount.toFloat() / confidences.size.coerceAtLeast(1).toFloat()
      // If no portrait subject is detected in frame, save natural untouched original
      if (fgFraction < 0.015f || fgFraction > 0.96f) {
        return MediaStorePhotoSaver.saveBitmapToMediaStore(context, oriented, prefix = "PORTRAIT_")
      }

      // Create gentle natural optical background blur via downsampled symmetric multi-pass box blur
      val blurredBg = createOpticalBackgroundBlur(oriented)
      val w = oriented.width
      val h = oriented.height

      val fgPixels = IntArray(w * h)
      val bgPixels = IntArray(w * h)
      val outPixels = IntArray(w * h)
      oriented.getPixels(fgPixels, 0, w, 0, 0, w, h)
      blurredBg.getPixels(bgPixels, 0, w, 0, 0, w, h)
      blurredBg.recycle()

      // Smoothstep feather transition (0.38..0.82) preserves fine hair/edges and never alters skin texture
      for (y in 0 until h) {
        val my = ((y * maskH) / h).coerceIn(0, maskH - 1)
        val maskRow = my * maskW
        val rowOff = y * w
        for (x in 0 until w) {
          val mx = ((x * maskW) / w).coerceIn(0, maskW - 1)
          val conf = confidences[maskRow + mx]
          val rawAlpha = ((conf - 0.38f) / 0.44f).coerceIn(0f, 1f)
          val alpha = rawAlpha * rawAlpha * (3f - 2f * rawAlpha)

          if (alpha >= 0.995f) {
            outPixels[rowOff + x] = fgPixels[rowOff + x]
          } else if (alpha <= 0.005f) {
            outPixels[rowOff + x] = bgPixels[rowOff + x]
          } else {
            val fp = fgPixels[rowOff + x]
            val bp = bgPixels[rowOff + x]
            val inv = 1f - alpha
            val r = (((fp ushr 16) and 0xFF) * alpha + ((bp ushr 16) and 0xFF) * inv).roundToInt()
            val g = (((fp ushr 8) and 0xFF) * alpha + ((bp ushr 8) and 0xFF) * inv).roundToInt()
            val b = ((fp and 0xFF) * alpha + (bp and 0xFF) * inv).roundToInt()
            outPixels[rowOff + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
          }
        }
      }

      val composite = Bitmap.createBitmap(outPixels, w, h, Bitmap.Config.ARGB_8888)
      try {
        MediaStorePhotoSaver.saveBitmapToMediaStore(context, composite, prefix = "PORTRAIT_")
      } finally {
        composite.recycle()
      }
    } catch (_: Exception) {
      MediaStorePhotoSaver.saveBitmapToMediaStore(context, oriented, prefix = "PORTRAIT_")
    } finally {
      oriented.recycle()
    }
  }

  private suspend fun runSegmentation(bitmap: Bitmap) =
    suspendCancellableCoroutine { cont ->
      val input = InputImage.fromBitmap(bitmap, 0)
      segmenter.process(input)
        .addOnSuccessListener { mask ->
          if (cont.isActive) cont.resume(mask)
        }
        .addOnFailureListener { exc ->
          if (cont.isActive) cont.resumeWithException(exc)
        }
    }

  private fun createOpticalBackgroundBlur(src: Bitmap): Bitmap {
    val scale = 8
    val sw = (src.width / scale).coerceAtLeast(32)
    val sh = (src.height / scale).coerceAtLeast(32)
    val small = Bitmap.createScaledBitmap(src, sw, sh, true)
    val pixels = IntArray(sw * sh)
    val temp = IntArray(sw * sh)
    small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
    small.recycle()

    repeat(2) {
      boxBlurPass(pixels, temp, sw, sh, radius = 2)
      System.arraycopy(temp, 0, pixels, 0, pixels.size)
    }

    val blurredSmall = Bitmap.createBitmap(pixels, sw, sh, Bitmap.Config.ARGB_8888)
    val upscaled = Bitmap.createScaledBitmap(blurredSmall, src.width, src.height, true)
    blurredSmall.recycle()
    return upscaled
  }

  private fun boxBlurPass(src: IntArray, dst: IntArray, w: Int, h: Int, radius: Int) {
    val horiz = IntArray(w * h)
    for (y in 0 until h) {
      val rowOff = y * w
      for (x in 0 until w) {
        var rSum = 0
        var gSum = 0
        var bSum = 0
        var cnt = 0
        for (kx in (x - radius)..(x + radius)) {
          val cx = kx.coerceIn(0, w - 1)
          val p = src[rowOff + cx]
          rSum += (p ushr 16) and 0xFF
          gSum += (p ushr 8) and 0xFF
          bSum += p and 0xFF
          cnt++
        }
        horiz[rowOff + x] = (0xFF shl 24) or ((rSum / cnt) shl 16) or ((gSum / cnt) shl 8) or (bSum / cnt)
      }
    }
    for (y in 0 until h) {
      val rowOff = y * w
      for (x in 0 until w) {
        var rSum = 0
        var gSum = 0
        var bSum = 0
        var cnt = 0
        for (ky in (y - radius)..(y + radius)) {
          val cy = ky.coerceIn(0, h - 1)
          val p = horiz[cy * w + x]
          rSum += (p ushr 16) and 0xFF
          gSum += (p ushr 8) and 0xFF
          bSum += p and 0xFF
          cnt++
        }
        dst[rowOff + x] = (0xFF shl 24) or ((rSum / cnt) shl 16) or ((gSum / cnt) shl 8) or (bSum / cnt)
      }
    }
  }
}
