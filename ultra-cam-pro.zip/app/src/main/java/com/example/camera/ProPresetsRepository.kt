package com.example.camera

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.proPresetsDataStore by preferencesDataStore(name = "ultra_cam_pro_presets")

object ProPresetsRepository {

  private val KEY_PRESETS_JSON = stringPreferencesKey("custom_pro_presets_json")

  fun observePresets(context: Context): Flow<List<ProPreset>> {
    val appContext = context.applicationContext
    return appContext.proPresetsDataStore.data.map { prefs ->
      val raw = prefs[KEY_PRESETS_JSON]
      if (raw.isNullOrBlank()) emptyList() else decodePresets(raw)
    }
  }

  suspend fun savePreset(context: Context, preset: ProPreset) {
    val appContext = context.applicationContext
    appContext.proPresetsDataStore.edit { prefs ->
      val existing = prefs[KEY_PRESETS_JSON]?.let { decodePresets(it) }.orEmpty()
      val updated = (existing.filterNot { it.id == preset.id } + preset).takeLast(12)
      prefs[KEY_PRESETS_JSON] = encodePresets(updated)
    }
  }

  suspend fun deletePreset(context: Context, presetId: String) {
    val appContext = context.applicationContext
    appContext.proPresetsDataStore.edit { prefs ->
      val existing = prefs[KEY_PRESETS_JSON]?.let { decodePresets(it) }.orEmpty()
      val updated = existing.filterNot { it.id == presetId }
      prefs[KEY_PRESETS_JSON] = encodePresets(updated)
    }
  }

  internal fun encodePresets(presets: List<ProPreset>): String {
    val array = JSONArray()
    presets.forEach { p ->
      val obj =
        JSONObject().apply {
          put("id", p.id)
          put("name", p.name)
          put("isManualIsoEnabled", p.isManualIsoEnabled)
          if (p.manualIso != null) put("manualIso", p.manualIso)
          put("isManualShutterEnabled", p.isManualShutterEnabled)
          if (p.manualShutterNs != null) put("manualShutterNs", p.manualShutterNs)
          put("whiteBalanceMode", p.whiteBalanceMode.name)
          put("manualKelvin", p.manualKelvin)
          put("isManualFocusEnabled", p.isManualFocusEnabled)
          put("manualFocusDiopters", p.manualFocusDiopters.toDouble())
          put("exposureCompIndex", p.exposureCompIndex)
          put("captureOutputFormat", p.captureOutputFormat.name)
          put("stabilizationSelection", p.stabilizationSelection.name)
          put("isFocusPeakingEnabled", p.isFocusPeakingEnabled)
          put("isHistogramEnabled", p.isHistogramEnabled)
          put("isZebraEnabled", p.isZebraEnabled)
        }
      array.put(obj)
    }
    return array.toString()
  }

  internal fun decodePresets(json: String): List<ProPreset> {
    return try {
      val array = JSONArray(json)
      buildList {
        for (i in 0 until array.length()) {
          val obj = array.optJSONObject(i) ?: continue
          val id = obj.optString("id").takeIf { it.isNotBlank() } ?: continue
          val name = obj.optString("name").takeIf { it.isNotBlank() } ?: continue
          val wbName = obj.optString("whiteBalanceMode", WhiteBalanceOption.AUTO.name)
          val fmtName = obj.optString("captureOutputFormat", CaptureOutputFormat.JPEG.name)
          val stabName = obj.optString("stabilizationSelection", StabilizationSelection.AUTO.name)
          add(
            ProPreset(
              id = id,
              name = name,
              isManualIsoEnabled = obj.optBoolean("isManualIsoEnabled", false),
              manualIso = if (obj.has("manualIso")) obj.optInt("manualIso") else null,
              isManualShutterEnabled = obj.optBoolean("isManualShutterEnabled", false),
              manualShutterNs =
                if (obj.has("manualShutterNs")) obj.optLong("manualShutterNs") else null,
              whiteBalanceMode =
                runCatching { WhiteBalanceOption.valueOf(wbName) }
                  .getOrDefault(WhiteBalanceOption.AUTO),
              manualKelvin = obj.optInt("manualKelvin", 5500),
              isManualFocusEnabled = obj.optBoolean("isManualFocusEnabled", false),
              manualFocusDiopters = obj.optDouble("manualFocusDiopters", 0.0).toFloat(),
              exposureCompIndex = obj.optInt("exposureCompIndex", 0),
              captureOutputFormat =
                runCatching { CaptureOutputFormat.valueOf(fmtName) }
                  .getOrDefault(CaptureOutputFormat.JPEG),
              stabilizationSelection =
                runCatching { StabilizationSelection.valueOf(stabName) }
                  .getOrDefault(StabilizationSelection.AUTO),
              isFocusPeakingEnabled = obj.optBoolean("isFocusPeakingEnabled", false),
              isHistogramEnabled = obj.optBoolean("isHistogramEnabled", false),
              isZebraEnabled = obj.optBoolean("isZebraEnabled", false),
            )
          )
        }
      }
    } catch (_: Exception) {
      emptyList()
    }
  }
}
