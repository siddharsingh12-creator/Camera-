package com.example.camera

import androidx.camera.extensions.ExtensionMode

enum class PhotographyMode(
  val label: String,
  val shortTag: String,
  val description: String,
) {
  STANDARD(
    label = "Photo",
    shortTag = "PHOTO",
    description = "Full-resolution native sensor capture with natural tone mapping",
  ),
  HDR(
    label = "HDR",
    shortTag = "HDR",
    description = "High dynamic range capture via vendor CameraX HDR or Camera2 HDR scene",
  ),
  NIGHT(
    label = "Night",
    shortTag = "NIGHT",
    description = "Multi-frame night computational photography when supported by device",
  ),
  PORTRAIT(
    label = "Portrait",
    shortTag = "PORTRAIT",
    description = "Hardware Bokeh extension or on-device neural segmentation with natural skin texture",
  ),
  MACRO(
    label = "Macro",
    shortTag = "MACRO",
    description = "Dedicated macro sensor or hardware close-focus AF_MODE_MACRO",
  ),
  HIGH_RES(
    label = "Hi-Res",
    shortTag = "HI-RES",
    description = "Unbinned highest native sensor megapixel stream without upscaling",
  ),
  PANORAMA(
    label = "Panorama",
    shortTag = "PANO",
    description = "Guided multi-frame sweep with ZNCC image alignment & feather seam stitching",
  ),
  LOW_LIGHT(
    label = "Low Light",
    shortTag = "LOW LT",
    description = "Hardware Low Light Boost or aligned multi-frame noise-reduction stack",
  ),
  AUTO_SCENE(
    label = "Auto Scene",
    shortTag = "SCENE",
    description = "Vendor Auto Extension or live frame telemetry selecting hardware scene modes",
  ),
  NATURAL_COLOR(
    label = "Natural",
    shortTag = "NATURAL",
    description = "True color fidelity with edge oversharpening disabled & highlight protection",
  ),
}

enum class DetectedSceneType(val label: String) {
  GENERAL("Standard Scene"),
  PORTRAIT("Portrait Subject"),
  LOW_LIGHT("Low Light Scene"),
  HIGH_CONTRAST("High Contrast"),
  MACRO("Close Focus"),
  LANDSCAPE("Landscape"),
}

data class ModeAvailability(
  val mode: PhotographyMode,
  val isSupported: Boolean,
  val backendLabel: String,
  val reason: String,
  val extensionMode: Int = ExtensionMode.NONE,
)

data class CameraModeCapabilities(
  val cameraId: String? = null,
  val modes: Map<PhotographyMode, ModeAvailability> =
    mapOf(
      PhotographyMode.STANDARD to
        ModeAvailability(
          mode = PhotographyMode.STANDARD,
          isSupported = true,
          backendLabel = "CameraX Max Quality",
          reason = "Full native sensor JPEG capture",
        )
    ),
  val hasExtensionHdr: Boolean = false,
  val hasExtensionNight: Boolean = false,
  val hasExtensionBokeh: Boolean = false,
  val hasExtensionAuto: Boolean = false,
  val hasExtensionFaceRetouch: Boolean = false,
  val isCameraXLowLightBoostSupported: Boolean = false,
  val bestMacroCameraId: String? = null,
  val isInitialized: Boolean = false,
) {
  fun availabilityOf(mode: PhotographyMode): ModeAvailability =
    modes[mode]
      ?: ModeAvailability(
        mode = mode,
        isSupported = mode == PhotographyMode.STANDARD,
        backendLabel = "Unavailable",
        reason = "Hardware capability probe pending",
      )
}

data class PanoramaSessionState(
  val isActive: Boolean = false,
  val capturedSlicesCount: Int = 0,
  val maxSlices: Int = 6,
  val currentYawDeg: Float = 0f,
  val targetStepDeg: Float = 18f,
  val pitchTiltDeg: Float = 0f,
  val isStitching: Boolean = false,
  val statusHint: String = "Tap shutter to start panorama sweep",
) {
  val canFinishStitch: Boolean
    get() = capturedSlicesCount >= 2 && !isStitching
}
