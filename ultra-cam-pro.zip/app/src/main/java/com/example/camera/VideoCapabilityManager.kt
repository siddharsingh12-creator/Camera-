package com.example.camera

import android.hardware.camera2.CameraCharacteristics
import android.media.CamcorderProfile
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaRecorder
import android.util.Range
import android.util.Size
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraInfo
import androidx.camera.core.DynamicRange
import androidx.camera.video.ExperimentalHighSpeedVideo
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder

object VideoCapabilityManager {

  @OptIn(ExperimentalCamera2Interop::class, ExperimentalHighSpeedVideo::class)
  fun evaluateLiveCapabilities(
    cameraInfo: CameraInfo,
    profile: CameraHardwareProfile?,
    selectedQuality: VideoQualityOption,
    hdrEnabled: Boolean,
  ): CameraVideoCapabilities {
    val videoCaps = Recorder.getVideoCapabilities(cameraInfo)
    val highSpeedCaps =
      try {
        Recorder.getHighSpeedVideoCapabilities(cameraInfo)
      } catch (_: Exception) {
        null
      }

    // 1. Evaluate 10-bit Video HDR support
    val hdrRanges =
      try {
        videoCaps.supportedDynamicRanges.filter { it != DynamicRange.SDR }
      } catch (_: Exception) {
        emptyList()
      }
    val preferredHdrRange =
      hdrRanges.firstOrNull { it == DynamicRange.HLG_10_BIT } ?: hdrRanges.firstOrNull()
    val hdrDynamicRange =
      if (hdrEnabled && preferredHdrRange != null) preferredHdrRange else DynamicRange.SDR

    val activeRangeQualities =
      try {
        videoCaps.getSupportedQualities(hdrDynamicRange)
      } catch (_: Exception) {
        emptyList()
      }
    val sdrQualities =
      try {
        videoCaps.getSupportedQualities(DynamicRange.SDR)
      } catch (_: Exception) {
        emptyList()
      }
    val baseQualities = activeRangeQualities.ifEmpty { sdrQualities }

    val resolvedResolutions =
      mutableMapOf<Quality, Size>().apply {
        listOf(Quality.UHD, Quality.FHD, Quality.HD, Quality.SD).forEach { q ->
          if (baseQualities.contains(q)) {
            QualitySelector.getResolution(cameraInfo, q)?.let { put(q, it) }
          }
        }
      }

    // Check Camera2 StreamConfigurationMap & CamcorderProfile for genuine 2K (QHD/2K) metadata
    val cam2Info =
      try {
        Camera2CameraInfo.from(cameraInfo)
      } catch (_: Exception) {
        null
      }
    val streamMap =
      try {
        cam2Info?.getCameraCharacteristic(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
      } catch (_: Exception) {
        null
      }
    val mediaRecorderSizes =
      streamMap?.getOutputSizes(MediaRecorder::class.java)?.toList().orEmpty()
    val cameraIdInt = profile?.cameraId?.toIntOrNull()
    @Suppress("DEPRECATION")
    val hasHardwareQhdProfile =
      cameraIdInt != null &&
        (runCatching { CamcorderProfile.hasProfile(cameraIdInt, CamcorderProfile.QUALITY_QHD) }
          .getOrDefault(false) ||
          runCatching { CamcorderProfile.hasProfile(cameraIdInt, CamcorderProfile.QUALITY_2K) }
            .getOrDefault(false))
    val hasMediaRecorder2kSize =
      mediaRecorderSizes.any { s ->
        val maxD = maxOf(s.width, s.height)
        val minD = minOf(s.width, s.height)
        (minD in 1400..1500 && maxD in 2500..2600) || (maxD in 2000..2160 && minD in 1080..1200)
      }

    val minFrameDurationBySizeNs: Map<Size, Long> =
      buildMap {
        if (streamMap != null) {
          resolvedResolutions.values.forEach { size ->
            try {
              val d = streamMap.getOutputMinFrameDuration(MediaRecorder::class.java, size)
              if (d > 0L) put(size, d)
            } catch (_: Exception) {
              // Ignore if device omits min frame duration
            }
          }
        }
      }

    val camXStabSupported =
      try {
        videoCaps.isStabilizationSupported
      } catch (_: Exception) {
        false
      }

    val camXFpsRanges =
      try {
        cameraInfo.supportedFrameRateRanges.toList()
      } catch (_: Exception) {
        emptyList()
      }
    val profileFpsRanges =
      profile?.videoAndStabilization?.supportedFpsRanges?.map { Range(it.first, it.last) }.orEmpty()
    val standardFpsRanges = camXFpsRanges.ifEmpty { profileFpsRanges }

    val highSpeedQualities =
      try {
        highSpeedCaps?.getSupportedQualities(DynamicRange.SDR).orEmpty()
      } catch (_: Exception) {
        emptyList()
      }
    val highSpeedRanges =
      try {
        streamMap?.highSpeedVideoFpsRanges?.toList().orEmpty()
      } catch (_: Exception) {
        emptyList()
      }

    val maxEncoderBitrate = queryMaxHardwareVideoEncoderBitrate()

    return evaluateCapabilitiesCore(
      cameraId = profile?.cameraId,
      supportedCameraXQualities = baseQualities,
      resolvedQualitySizes = resolvedResolutions,
      hdrSupportedQualities =
        if (preferredHdrRange != null) {
          runCatching { videoCaps.getSupportedQualities(preferredHdrRange) }.getOrDefault(emptyList())
        } else {
          emptyList()
        },
      preferredHdrRange = preferredHdrRange,
      hasHardwareQhdProfile = hasHardwareQhdProfile || hasMediaRecorder2kSize,
      selectedQuality = selectedQuality,
      standardFpsRanges = standardFpsRanges,
      highSpeedQualities = highSpeedQualities,
      highSpeedFpsRanges = highSpeedRanges,
      minFrameDurationBySizeNs = minFrameDurationBySizeNs,
      isCameraXStabilizationSupported = camXStabSupported,
      isOisSupported = profile?.videoAndStabilization?.isOisSupported == true,
      isEisSupported = profile?.videoAndStabilization?.isEisSupported == true || camXStabSupported,
      maxEncoderBitrateBps = maxEncoderBitrate,
    )
  }

  /**
   * Pure capability evaluation core usable both at runtime and in Robolectric unit tests.
   */
  fun evaluateCapabilitiesCore(
    cameraId: String?,
    supportedCameraXQualities: List<Quality>,
    resolvedQualitySizes: Map<Quality, Size>,
    hdrSupportedQualities: List<Quality>,
    preferredHdrRange: DynamicRange?,
    hasHardwareQhdProfile: Boolean,
    selectedQuality: VideoQualityOption,
    standardFpsRanges: List<Range<Int>>,
    highSpeedQualities: List<Quality>,
    highSpeedFpsRanges: List<Range<Int>>,
    minFrameDurationBySizeNs: Map<Size, Long>,
    isCameraXStabilizationSupported: Boolean,
    isOisSupported: Boolean,
    isEisSupported: Boolean,
    maxEncoderBitrateBps: Int,
  ): CameraVideoCapabilities {
    // 1. Quality availability (never fake 2K/4K)
    val qMap = linkedMapOf<VideoQualityOption, VideoQualityAvailability>()
    for (opt in VideoQualityOption.entries) {
      if (opt == VideoQualityOption.QHD_2K) {
        // Check if any CameraX quality genuinely resolved to a 2K/1440p size on this sensor
        val matching2kQuality =
          supportedCameraXQualities.firstOrNull { q ->
            val s = resolvedQualitySizes[q] ?: return@firstOrNull false
            val minD = minOf(s.width, s.height)
            val maxD = maxOf(s.width, s.height)
            minD in 1400..1500 || (maxD in 2000..2600 && minD >= 1080)
          }
        val size2k = matching2kQuality?.let { resolvedQualitySizes[it] }
        qMap[opt] =
          if (matching2kQuality != null && size2k != null) {
            VideoQualityAvailability(
              quality = opt,
              isSupported = true,
              resolvedSize = size2k,
              cameraXQuality = matching2kQuality,
              reason = "${size2k.width}×${size2k.height} native 2K video stream",
            )
          } else {
            VideoQualityAvailability(
              quality = opt,
              isSupported = false,
              resolvedSize = null,
              cameraXQuality = null,
              reason =
                if (hasHardwareQhdProfile) {
                  "Unavailable: CameraX Recorder exposes FHD/UHD qualities rather than discrete 2K QHD on this sensor"
                } else {
                  "Unavailable: Camera hardware lacks native 2K (1440p) video profile"
                },
            )
          }
      } else {
        val camXQ = opt.toCameraXQualityOrNull()
        val isSupportedByCamX = camXQ != null && supportedCameraXQualities.contains(camXQ)
        val size = camXQ?.let { resolvedQualitySizes[it] }
        // Guard against misreported 4K/FHD where sensor stream is smaller than the quality tier
        val meetsMinDimension =
          when (opt) {
            VideoQualityOption.UHD_4K ->
              size == null || minOf(size.width, size.height) >= 2000
            VideoQualityOption.FHD_1080P ->
              size == null || minOf(size.width, size.height) >= 1000
            else -> true
          }
        val supported = isSupportedByCamX && meetsMinDimension
        qMap[opt] =
          if (supported) {
            val resLabel = size?.let { "${it.width}×${it.height}" } ?: opt.displayName
            VideoQualityAvailability(
              quality = opt,
              isSupported = true,
              resolvedSize = size,
              cameraXQuality = camXQ,
              reason = "$resLabel hardware-backed Recorder stream",
            )
          } else {
            VideoQualityAvailability(
              quality = opt,
              isSupported = false,
              resolvedSize = null,
              cameraXQuality = camXQ,
              reason = "Unavailable: Sensor lacks ${opt.displayName} CamcorderProfile / encoder support",
            )
          }
      }
    }

    // 2. HDR availability
    val hdrQualityList =
      VideoQualityOption.entries.filter { opt ->
        val cx = qMap[opt]?.cameraXQuality
        cx != null && hdrSupportedQualities.contains(cx)
      }
    val hdrLabel =
      when (preferredHdrRange) {
        DynamicRange.HLG_10_BIT -> "HLG10"
        DynamicRange.HDR10_10_BIT -> "HDR10"
        DynamicRange.HDR10_PLUS_10_BIT -> "HDR10+"
        DynamicRange.DOLBY_VISION_10_BIT,
        DynamicRange.DOLBY_VISION_8_BIT -> "Dolby Vision"
        else -> "HDR"
      }
    val hdrAvailability =
      if (preferredHdrRange != null && hdrQualityList.isNotEmpty()) {
        VideoHdrAvailability(
          isSupported = true,
          dynamicRange = preferredHdrRange,
          label = hdrLabel,
          supportedQualities = hdrQualityList,
          reason = "10-bit $hdrLabel video supported (${hdrQualityList.joinToString("/") { it.shortLabel }})",
        )
      } else {
        VideoHdrAvailability(
          isSupported = false,
          dynamicRange = DynamicRange.SDR,
          label = "SDR",
          supportedQualities = emptyList(),
          reason = "Unavailable: Sensor or encoder lacks 10-bit HDR video capability",
        )
      }

    // 3. FPS availability (24, 30, 60, 120, 240) gated by real AE ranges + stream minFrameDuration + HighSpeedVideoCapabilities
    val activeSize = qMap[selectedQuality]?.resolvedSize
    val minDurNs = activeSize?.let { minFrameDurationBySizeNs[it] } ?: 0L
    val sensorMaxFpsForSize =
      if (minDurNs > 0L) (1_000_000_000.0 / minDurNs.toDouble()).toFloat() else null

    val fpsMap = linkedMapOf<VideoFpsOption, VideoFpsAvailability>()
    for (fpsOpt in VideoFpsOption.entries) {
      if (!fpsOpt.isHighSpeed) {
        val exactRange =
          standardFpsRanges.firstOrNull { it.lower == fpsOpt.fps && it.upper == fpsOpt.fps }
        val variableCoveringRange =
          if (fpsOpt == VideoFpsOption.FPS_30) {
            standardFpsRanges.firstOrNull { it.upper == 30 && it.lower <= 30 }
          } else {
            null
          }
        val matched = exactRange ?: variableCoveringRange
        val meetsSizeBandwidth =
          sensorMaxFpsForSize == null || sensorMaxFpsForSize + 1.5f >= fpsOpt.fps.toFloat()

        fpsMap[fpsOpt] =
          when {
            matched != null && meetsSizeBandwidth ->
              VideoFpsAvailability(
                fpsOption = fpsOpt,
                isSupported = true,
                matchedRange = matched,
                reason =
                  if (matched.lower == matched.upper) {
                    "Hardware constant ${fpsOpt.fps} fps [${matched.lower}..${matched.upper}]"
                  } else {
                    "Adaptive ${matched.lower}–${matched.upper} fps"
                  },
              )
            matched == null ->
              VideoFpsAvailability(
                fpsOption = fpsOpt,
                isSupported = false,
                reason = "Unavailable: Sensor AE target FPS list lacks ${fpsOpt.fps} fps",
              )
            else ->
              VideoFpsAvailability(
                fpsOption = fpsOpt,
                isSupported = false,
                reason =
                  "Unavailable at ${selectedQuality.shortLabel}: sensor readout caps at ~${sensorMaxFpsForSize?.toInt() ?: 30} fps",
              )
          }
      } else {
        val hsMatch =
          highSpeedFpsRanges.firstOrNull { it.upper == fpsOpt.fps && it.lower <= fpsOpt.fps }
            ?: highSpeedFpsRanges.firstOrNull { it.upper >= fpsOpt.fps && it.lower <= fpsOpt.fps }
        val hsSupported = highSpeedQualities.isNotEmpty() && hsMatch != null
        fpsMap[fpsOpt] =
          if (hsSupported) {
            VideoFpsAvailability(
              fpsOption = fpsOpt,
              isSupported = true,
              matchedRange = hsMatch,
              supportedHighSpeedQualities = highSpeedQualities,
              reason =
                "High-Speed ${hsMatch!!.lower}–${hsMatch.upper} fps (${highSpeedQualities.joinToString("/") { qualityShortName(it) }})",
            )
          } else {
            VideoFpsAvailability(
              fpsOption = fpsOpt,
              isSupported = false,
              reason =
                if (highSpeedQualities.isEmpty()) {
                  "Unavailable: Camera lacks Constrained High-Speed Video capability"
                } else {
                  "Unavailable: Hardware high-speed profile does not include ${fpsOpt.fps} fps"
                },
            )
          }
      }
    }

    return CameraVideoCapabilities(
      cameraId = cameraId,
      qualities = qMap,
      fpsOptions = fpsMap,
      hdrAvailability = hdrAvailability,
      isVideoStabilizationSupported = isCameraXStabilizationSupported || isEisSupported || isOisSupported,
      isOisSupported = isOisSupported,
      isEisSupported = isEisSupported || isCameraXStabilizationSupported,
      maxEncoderBitrateBps = maxEncoderBitrateBps,
      isInitialized = true,
    )
  }

  private fun qualityShortName(q: Quality): String =
    when (q) {
      Quality.UHD -> "4K"
      Quality.FHD -> "1080p"
      Quality.HD -> "720p"
      Quality.SD -> "480p"
      else -> q.toString()
    }

  private fun queryMaxHardwareVideoEncoderBitrate(): Int {
    return try {
      val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
      var highest = 0
      for (info in list.codecInfos) {
        if (!info.isEncoder) continue
        val mimes = info.supportedTypes
        for (mime in mimes) {
          if (
            mime.equals(MediaFormat.MIMETYPE_VIDEO_AVC, ignoreCase = true) ||
              mime.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, ignoreCase = true)
          ) {
            val caps = info.getCapabilitiesForType(mime)
            val upper = caps.videoCapabilities?.bitrateRange?.upper ?: 0
            if (upper > highest) highest = upper
          }
        }
      }
      if (highest >= 10_000_000) highest else 100_000_000
    } catch (_: Exception) {
      100_000_000
    }
  }
}
