package com.example.camera

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Matrix
import android.graphics.Rect
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageProxy
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MediaStorePhotoSaver {

  private const val ALBUM_FOLDER = "UltraCamPro"
  private const val FILENAME_PATTERN = "yyyyMMdd_HHmmss_SSS"

  fun createOutputFileOptions(
    context: Context,
    isFrontCamera: Boolean = false,
    mirrorFrontCamera: Boolean = false,
  ): Pair<ImageCapture.OutputFileOptions, String> {
    val timestamp = SimpleDateFormat(FILENAME_PATTERN, Locale.US).format(Date())
    val displayName = "IMG_${timestamp}.jpg"

    val contentValues =
      ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          put(
            MediaStore.Images.Media.RELATIVE_PATH,
            "${Environment.DIRECTORY_PICTURES}/$ALBUM_FOLDER",
          )
        }
      }

    val metadata =
      ImageCapture.Metadata().apply {
        isReversedHorizontal = isFrontCamera && mirrorFrontCamera
      }

    val options =
      ImageCapture.OutputFileOptions.Builder(
          context.contentResolver,
          MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
          contentValues,
        )
        .setMetadata(metadata)
        .build()

    return options to displayName
  }

  fun createRawOutputFileOptions(context: Context): Pair<ImageCapture.OutputFileOptions, String> {
    val timestamp = SimpleDateFormat(FILENAME_PATTERN, Locale.US).format(Date())
    val displayName = "RAW_${timestamp}.dng"

    val contentValues =
      ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
        put(MediaStore.Images.Media.MIME_TYPE, "image/x-adobe-dng")
        put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          put(
            MediaStore.Images.Media.RELATIVE_PATH,
            "${Environment.DIRECTORY_PICTURES}/$ALBUM_FOLDER",
          )
        }
      }

    val options =
      ImageCapture.OutputFileOptions.Builder(
          context.contentResolver,
          MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
          contentValues,
        )
        .build()

    return options to displayName
  }

  /**
   * Decodes the center 1:1 square region from the native JPEG sensor buffer without scaling,
   * applies hardware rotation/front-mirroring, and saves at JPEG quality 100 to MediaStore.
   */
  @Suppress("DEPRECATION")
  fun saveSquareCropFromImageProxy(
    context: Context,
    image: ImageProxy,
    isFrontCamera: Boolean,
    mirrorFrontCamera: Boolean,
  ): Pair<Uri, String>? {
    val buffer = image.planes.firstOrNull()?.buffer ?: return null
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)

    val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOpts)
    val srcW = boundsOpts.outWidth
    val srcH = boundsOpts.outHeight
    if (srcW <= 0 || srcH <= 0) return null

    val side = minOf(srcW, srcH)
    val left = (srcW - side) / 2
    val top = (srcH - side) / 2
    val cropRect = Rect(left, top, left + side, top + side)

    val decoder =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        BitmapRegionDecoder.newInstance(bytes, 0, bytes.size)
      } else {
        BitmapRegionDecoder.newInstance(bytes, 0, bytes.size, false)
      }

    val cropped =
      decoder.useOrClose { dec ->
        dec.decodeRegion(cropRect, BitmapFactory.Options())
      } ?: return null

    val rotationDegrees = image.imageInfo.rotationDegrees
    val shouldMirror = isFrontCamera && mirrorFrontCamera
    val finalBitmap =
      if (rotationDegrees != 0 || shouldMirror) {
        val matrix = Matrix().apply {
          if (rotationDegrees != 0) postRotate(rotationDegrees.toFloat())
          if (shouldMirror) postScale(-1f, 1f, cropped.width / 2f, cropped.height / 2f)
        }
        val transformed =
          Bitmap.createBitmap(cropped, 0, 0, cropped.width, cropped.height, matrix, true)
        if (transformed !== cropped) cropped.recycle()
        transformed
      } else {
        cropped
      }

    val timestamp = SimpleDateFormat(FILENAME_PATTERN, Locale.US).format(Date())
    val displayName = "IMG_${timestamp}.jpg"
    val contentValues =
      ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
        put(MediaStore.Images.Media.WIDTH, finalBitmap.width)
        put(MediaStore.Images.Media.HEIGHT, finalBitmap.height)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          put(
            MediaStore.Images.Media.RELATIVE_PATH,
            "${Environment.DIRECTORY_PICTURES}/$ALBUM_FOLDER",
          )
          put(MediaStore.Images.Media.IS_PENDING, 1)
        }
      }

    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
    if (uri == null) {
      finalBitmap.recycle()
      return null
    }

    return try {
      resolver.openOutputStream(uri)?.use { out ->
        finalBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out)
      }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
        resolver.update(uri, done, null, null)
      }
      uri to displayName
    } catch (_: Exception) {
      resolver.delete(uri, null, null)
      null
    } finally {
      finalBitmap.recycle()
    }
  }

  private inline fun <R> BitmapRegionDecoder.useOrClose(block: (BitmapRegionDecoder) -> R): R {
    return try {
      block(this)
    } finally {
      recycle()
    }
  }

  fun saveBitmapToMediaStore(
    context: Context,
    bitmap: Bitmap,
    prefix: String = "IMG_",
    quality: Int = 98,
  ): Pair<Uri, String>? {
    val timestamp = SimpleDateFormat(FILENAME_PATTERN, Locale.US).format(Date())
    val displayName = "${prefix}${timestamp}.jpg"
    val contentValues =
      ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
        put(MediaStore.Images.Media.WIDTH, bitmap.width)
        put(MediaStore.Images.Media.HEIGHT, bitmap.height)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          put(
            MediaStore.Images.Media.RELATIVE_PATH,
            "${Environment.DIRECTORY_PICTURES}/$ALBUM_FOLDER",
          )
          put(MediaStore.Images.Media.IS_PENDING, 1)
        }
      }

    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues) ?: return null
    return try {
      resolver.openOutputStream(uri)?.use { out ->
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(85, 100), out)
      }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
        resolver.update(uri, done, null, null)
      }
      uri to displayName
    } catch (_: Exception) {
      resolver.delete(uri, null, null)
      null
    }
  }

  fun inspectPhotoInfo(context: Context, uri: Uri, fallbackName: String? = null): CapturedPhotoInfo {
    var displayName = fallbackName ?: "Photo.jpg"
    var width = 0
    var height = 0
    var sizeBytes = 0L
    var timestamp = System.currentTimeMillis()

    val projection =
      arrayOf(
        MediaStore.Images.Media.DISPLAY_NAME,
        MediaStore.Images.Media.WIDTH,
        MediaStore.Images.Media.HEIGHT,
        MediaStore.Images.Media.SIZE,
        MediaStore.Images.Media.DATE_TAKEN,
      )

    try {
      context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
          val nameIdx = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
          val widthIdx = cursor.getColumnIndex(MediaStore.Images.Media.WIDTH)
          val heightIdx = cursor.getColumnIndex(MediaStore.Images.Media.HEIGHT)
          val sizeIdx = cursor.getColumnIndex(MediaStore.Images.Media.SIZE)
          val dateIdx = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)

          if (nameIdx >= 0) displayName = cursor.getString(nameIdx) ?: displayName
          if (widthIdx >= 0) width = cursor.getInt(widthIdx)
          if (heightIdx >= 0) height = cursor.getInt(heightIdx)
          if (sizeIdx >= 0) sizeBytes = cursor.getLong(sizeIdx)
          if (dateIdx >= 0) {
            val taken = cursor.getLong(dateIdx)
            if (taken > 0L) timestamp = taken
          }
        }
      }
    } catch (_: Exception) {
      // Fallback to stream inspection below
    }

    if (width <= 0 || height <= 0) {
      try {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { stream ->
          BitmapFactory.decodeStream(stream, null, options)
        }
        var rawWidth = options.outWidth
        var rawHeight = options.outHeight

        context.contentResolver.openInputStream(uri)?.use { exifStream ->
          val exif = ExifInterface(exifStream)
          val orientation =
            exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
          if (
            orientation == ExifInterface.ORIENTATION_ROTATE_90 ||
              orientation == ExifInterface.ORIENTATION_ROTATE_270 ||
              orientation == ExifInterface.ORIENTATION_TRANSPOSE ||
              orientation == ExifInterface.ORIENTATION_TRANSVERSE
          ) {
            val temp = rawWidth
            rawWidth = rawHeight
            rawHeight = temp
          }
        }

        if (rawWidth > 0 && rawHeight > 0) {
          width = rawWidth
          height = rawHeight
        }
      } catch (_: Exception) {
        // Leave 0 if unreadable
      }
    }

    if (sizeBytes <= 0L) {
      try {
        context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
          if (afd.length > 0L) sizeBytes = afd.length
        }
      } catch (_: Exception) {
        // Ignore
      }
    }

    return CapturedPhotoInfo(
      uri = uri,
      width = width,
      height = height,
      sizeBytes = sizeBytes,
      displayName = displayName,
      timestampMillis = timestamp,
    )
  }

  fun queryLatestAppPhoto(context: Context): CapturedPhotoInfo? {
    return try {
      val projection =
        arrayOf(
          MediaStore.Images.Media._ID,
          MediaStore.Images.Media.DISPLAY_NAME,
          MediaStore.Images.Media.WIDTH,
          MediaStore.Images.Media.HEIGHT,
          MediaStore.Images.Media.SIZE,
          MediaStore.Images.Media.DATE_TAKEN,
        )
      val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
      context.contentResolver
        .query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, sortOrder)
        ?.use { cursor ->
          if (cursor.moveToFirst()) {
            val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
            val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
            inspectPhotoInfo(context, uri)
          } else {
            null
          }
        }
    } catch (_: Exception) {
      null
    }
  }
}
