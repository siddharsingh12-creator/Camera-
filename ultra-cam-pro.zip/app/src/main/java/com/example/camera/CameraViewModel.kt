package com.example.camera

import android.content.Context
import android.hardware.camera2.CameraMetadata
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CameraViewModel : ViewModel() {

  private val _uiState = MutableStateFlow(CameraUiState())
  val uiState: StateFlow<CameraUiState> = _uiState.asStateFlow()

  private val _volumeShutterEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
  val volumeShutterEvents: SharedFlow<Unit> = _volumeShutterEvents.asSharedFlow()

  private var countdownJob: Job? = null
  private var presetsObserverJob: Job? = null

  fun triggerVolumeShutter() {
    _volumeShutterEvents.tryEmit(Unit)
  }

  fun startObservingPresets(context: Context) {
    if (presetsObserverJob?.isActive == true) return
    val appContext = context.applicationContext
    presetsObserverJob =
      viewModelScope.launch {
        ProPresetsRepository.observePresets(appContext).collect { presets ->
          _uiState.update { it.copy(customPresets = presets) }
        }
      }
  }

  fun updatePermissionStatus(status: CameraPermissionStatus) {
    _uiState.update { it.copy(permissionStatus = status, errorMessage = null) }
  }

  fun loadLatestAppPhotoIfNeeded(context: Context) {
    if (_uiState.value.lastCapturedPhoto != null) return
    val appContext = context.applicationContext
    viewModelScope.launch {
      val latest = withContext(Dispatchers.IO) { MediaStoreVideoSaver.queryLatestAppMedia(appContext) }
      if (latest != null) {
        _uiState.update { state ->
          if (state.lastCapturedPhoto == null) state.copy(lastCapturedPhoto = latest) else state
        }
      }
    }
  }

  fun updateDeviceInventory(inventory: DeviceCameraInventory) {
    _uiState.update { state ->
      val hasBack = inventory.backCameraCount > 0
      val hasFront = inventory.frontCameraCount > 0
      val selectable = inventory.selectableCameras
      val existingActive = selectable.firstOrNull { it.cameraId == state.activeCameraId }

      val resolvedActive =
        existingActive
          ?: when (state.lensOption) {
            LensOption.BACK ->
              selectable.firstOrNull { it.lensFacing == CameraMetadata.LENS_FACING_BACK }
                ?: selectable.firstOrNull()
            LensOption.FRONT ->
              selectable.firstOrNull { it.lensFacing == CameraMetadata.LENS_FACING_FRONT }
                ?: selectable.firstOrNull()
          }

      val resolvedLens =
        when (resolvedActive?.lensFacing) {
          CameraMetadata.LENS_FACING_FRONT -> LensOption.FRONT
          else -> LensOption.BACK
        }

      state.copy(
        deviceInventory = inventory,
        activeCameraId = resolvedActive?.cameraId,
        activeHardwareProfile = resolvedActive,
        hasBackCamera = hasBack,
        hasFrontCamera = hasFront,
        lensOption = resolvedLens,
        isLevelEnabled = state.isLevelEnabled && inventory.hasLevelSensor,
        isBurstModeEnabled = state.isBurstModeEnabled && (resolvedActive?.isBurstSupported == true),
        manualSettings = sanitizeManualSettingsForProfile(state.manualSettings, resolvedActive),
        inspectorSelectedCameraId =
          state.inspectorSelectedCameraId
            ?: resolvedActive?.cameraId
            ?: inventory.allLogicalAndStandaloneCameras.firstOrNull()?.cameraId,
        errorMessage =
          if (inventory.isInitialized && selectable.isEmpty()) {
            inventory.scanError ?: "No compatible physical camera sensor detected."
          } else {
            state.errorMessage
          },
      )
    }
  }

  fun updateCameraAvailability(hasBack: Boolean, hasFront: Boolean) {
    _uiState.update { state ->
      val correctedLens =
        when {
          state.lensOption == LensOption.BACK && !hasBack && hasFront -> LensOption.FRONT
          state.lensOption == LensOption.FRONT && !hasFront && hasBack -> LensOption.BACK
          else -> state.lensOption
        }
      state.copy(
        hasBackCamera = hasBack,
        hasFrontCamera = hasFront,
        lensOption = correctedLens,
        errorMessage = if (!hasBack && !hasFront) "No physical camera sensor detected." else null,
      )
    }
  }

  fun selectSpecificCamera(cameraId: String) {
    if (_uiState.value.videoRecordingState.isRecording || _uiState.value.videoRecordingState.isFinalizing) {
      showTransientBanner("Stop recording before switching lenses")
      return
    }
    cancelCountdown()
    _uiState.update { state ->
      val profile = state.deviceInventory.findSelectableById(cameraId) ?: return@update state
      if (state.activeCameraId == cameraId) return@update state
      val nextLens =
        if (profile.lensFacing == CameraMetadata.LENS_FACING_FRONT) LensOption.FRONT
        else LensOption.BACK
      state.copy(
        activeCameraId = cameraId,
        activeHardwareProfile = profile,
        lensOption = nextLens,
        focusPoint = null,
        errorMessage = null,
        isBurstModeEnabled = state.isBurstModeEnabled && profile.isBurstSupported,
        manualSettings = sanitizeManualSettingsForProfile(state.manualSettings, profile),
        videoSettings = state.videoSettings.copy(isTorchEnabled = false),
      )
    }
  }

  fun switchCamera() {
    if (_uiState.value.videoRecordingState.isRecording || _uiState.value.videoRecordingState.isFinalizing) {
      showTransientBanner("Stop recording before switching cameras")
      return
    }
    cancelCountdown()
    _uiState.update { state ->
      val next = state.lensOption.toggle()
      val canSwitch =
        when (next) {
          LensOption.BACK -> state.hasBackCamera
          LensOption.FRONT -> state.hasFrontCamera
        }
      if (!canSwitch) return@update state

      val targetFacing =
        if (next == LensOption.FRONT) CameraMetadata.LENS_FACING_FRONT
        else CameraMetadata.LENS_FACING_BACK
      val nextProfile = state.deviceInventory.selectableForFacing(targetFacing).firstOrNull()

      state.copy(
        lensOption = next,
        activeCameraId = nextProfile?.cameraId ?: state.activeCameraId,
        activeHardwareProfile = nextProfile ?: state.activeHardwareProfile,
        focusPoint = null,
        errorMessage = null,
        isBurstModeEnabled = state.isBurstModeEnabled && (nextProfile?.isBurstSupported == true),
        manualSettings = sanitizeManualSettingsForProfile(state.manualSettings, nextProfile),
        videoSettings = state.videoSettings.copy(isTorchEnabled = false),
      )
    }
  }

  private fun sanitizeManualSettingsForProfile(
    current: ManualProSettings,
    profile: CameraHardwareProfile?,
  ): ManualProSettings {
    if (profile == null) {
      return current.copy(
        isManualIsoEnabled = false,
        isManualShutterEnabled = false,
        whiteBalanceMode = WhiteBalanceOption.AUTO,
        isManualFocusEnabled = false,
        isExposureLockEnabled = false,
        captureOutputFormat = CaptureOutputFormat.JPEG,
        isRawCaptureEnabled = false,
      )
    }
    val exp = profile.exposureAndRaw
    val foc = profile.focusCapabilities
    val stab = profile.videoAndStabilization

    val forceJpegMode = _uiState.value.photographyMode != PhotographyMode.STANDARD &&
      _uiState.value.photographyMode != PhotographyMode.NATURAL_COLOR
    val resolvedFormat =
      when {
        forceJpegMode -> CaptureOutputFormat.JPEG
        current.captureOutputFormat == CaptureOutputFormat.RAW_DNG ->
          when {
            exp.isRawSupported && exp.isCameraXRawOnlySupported -> CaptureOutputFormat.RAW_DNG
            exp.isRawSupported && exp.isCameraXRawJpegSupported -> CaptureOutputFormat.RAW_PLUS_JPEG
            else -> CaptureOutputFormat.JPEG
          }
        current.captureOutputFormat == CaptureOutputFormat.RAW_PLUS_JPEG ->
          when {
            exp.isRawSupported && exp.isCameraXRawJpegSupported -> CaptureOutputFormat.RAW_PLUS_JPEG
            exp.isRawSupported && exp.isCameraXRawOnlySupported -> CaptureOutputFormat.RAW_DNG
            else -> CaptureOutputFormat.JPEG
          }
        else -> CaptureOutputFormat.JPEG
      }

    val resolvedWb =
      if (current.whiteBalanceMode == WhiteBalanceOption.MANUAL_KELVIN && !exp.isManualKelvinSupported) {
        WhiteBalanceOption.AUTO
      } else if (exp.supportedAwbModes.contains(current.whiteBalanceMode)) {
        current.whiteBalanceMode
      } else {
        WhiteBalanceOption.AUTO
      }

    return current.copy(
      isManualIsoEnabled = current.isManualIsoEnabled && exp.isManualExposureSupported,
      manualIso =
        if (exp.isManualExposureSupported) {
          val range = exp.isoRange
          if (range != null) current.manualIso?.coerceIn(range) else null
        } else {
          null
        },
      isManualShutterEnabled = current.isManualShutterEnabled && exp.isManualExposureSupported,
      manualShutterNs =
        if (exp.isManualExposureSupported) {
          val range = exp.shutterRangeNs
          if (range != null) current.manualShutterNs?.coerceIn(range) else null
        } else {
          null
        },
      whiteBalanceMode = resolvedWb,
      isManualFocusEnabled = current.isManualFocusEnabled && foc.isManualFocusSupported,
      manualFocusDiopters =
        if (foc.isManualFocusSupported) {
          current.manualFocusDiopters.coerceIn(0f, foc.minimumFocusDistanceDiopters)
        } else {
          0f
        },
      isExposureLockEnabled = false,
      captureOutputFormat = resolvedFormat,
      isRawCaptureEnabled = resolvedFormat != CaptureOutputFormat.JPEG,
      stabilizationSelection =
        when (current.stabilizationSelection) {
          StabilizationSelection.OIS ->
            if (stab.isOisSupported) StabilizationSelection.OIS else StabilizationSelection.AUTO
          StabilizationSelection.EIS ->
            if (stab.isEisSupported || stab.isPreviewStabilizationSupported) {
              StabilizationSelection.EIS
            } else {
              StabilizationSelection.AUTO
            }
          else -> current.stabilizationSelection
        },
    )
  }

  fun selectAspectRatio(aspectRatio: PreviewAspectRatio) {
    _uiState.update { state ->
      if (state.aspectRatio == aspectRatio) state
      else state.copy(aspectRatio = aspectRatio, focusPoint = null)
    }
  }

  fun cycleFlashSetting() {
    _uiState.update { state ->
      if (!state.sensorCapabilities.hasFlash) state
      else state.copy(flashSetting = state.flashSetting.next())
    }
  }

  fun cycleShutterTimer() {
    cancelCountdown()
    _uiState.update { it.copy(shutterTimer = it.shutterTimer.next()) }
  }

  fun startCountdownAndCapture(onTick: () -> Unit, onComplete: () -> Unit) {
    val timer = _uiState.value.shutterTimer
    if (timer == ShutterTimer.OFF) {
      onComplete()
      return
    }
    if (countdownJob?.isActive == true) {
      cancelCountdown()
      return
    }
    countdownJob =
      viewModelScope.launch {
        for (sec in timer.seconds downTo 1) {
          _uiState.update { it.copy(countdownRemainingSeconds = sec) }
          onTick()
          delay(1000L)
        }
        _uiState.update { it.copy(countdownRemainingSeconds = null) }
        onComplete()
      }
  }

  fun cancelCountdown() {
    countdownJob?.cancel()
    countdownJob = null
    _uiState.update { it.copy(countdownRemainingSeconds = null) }
  }

  fun toggleCaptureSpeedMode() {
    _uiState.update { state ->
      val next =
        if (state.captureSpeedMode == CaptureSpeedMode.MAX_QUALITY) CaptureSpeedMode.QUICK
        else CaptureSpeedMode.MAX_QUALITY
      state.copy(captureSpeedMode = next)
    }
  }

  fun toggleBurstMode() {
    _uiState.update { state ->
      if (state.activeHardwareProfile?.isBurstSupported != true) return@update state
      val nextBurst = !state.isBurstModeEnabled
      state.copy(
        isBurstModeEnabled = nextBurst,
        manualSettings =
          if (nextBurst) {
            state.manualSettings.copy(
              captureOutputFormat = CaptureOutputFormat.JPEG,
              isRawCaptureEnabled = false,
            )
          } else {
            state.manualSettings
          },
      )
    }
  }

  fun updateBurstProgress(count: Int?) {
    _uiState.update { it.copy(burstProgressCount = count) }
  }

  fun toggleGrid() {
    _uiState.update { it.copy(isGridEnabled = !it.isGridEnabled) }
  }

  fun toggleLevelIndicator() {
    _uiState.update { state ->
      if (!state.deviceInventory.hasLevelSensor) state
      else state.copy(isLevelEnabled = !state.isLevelEnabled)
    }
  }

  fun toggleFrontMirror() {
    _uiState.update { it.copy(isFrontMirrorEnabled = !it.isFrontMirrorEnabled) }
  }

  fun toggleVolumeShutter() {
    _uiState.update { it.copy(isVolumeShutterEnabled = !it.isVolumeShutterEnabled) }
  }

  fun toggleProPanel() {
    _uiState.update {
      it.copy(
        manualSettings =
          it.manualSettings.copy(isProPanelOpen = !it.manualSettings.isProPanelOpen)
      )
    }
  }

  fun selectProTab(tab: ProControlTab) {
    _uiState.update {
      it.copy(manualSettings = it.manualSettings.copy(activeProTab = tab))
    }
  }

  fun setManualIso(enabled: Boolean, iso: Int? = null) {
    _uiState.update { state ->
      val exp = state.activeHardwareProfile?.exposureAndRaw
      if (exp?.isManualExposureSupported != true) return@update state
      val range = exp.isoRange ?: return@update state
      val fallbackIso = state.liveTelemetry.iso ?: range.first
      val resolvedIso = (iso ?: state.manualSettings.manualIso ?: fallbackIso).coerceIn(range)
      state.copy(
        manualSettings =
          state.manualSettings.copy(
            isManualIsoEnabled = enabled,
            manualIso = if (enabled) resolvedIso else null,
            isExposureLockEnabled = if (enabled) false else state.manualSettings.isExposureLockEnabled,
          )
      )
    }
  }

  fun setManualShutter(enabled: Boolean, shutterNs: Long? = null) {
    _uiState.update { state ->
      val exp = state.activeHardwareProfile?.exposureAndRaw
      if (exp?.isManualExposureSupported != true) return@update state
      val range = exp.shutterRangeNs ?: return@update state
      val defaultShutter = (state.liveTelemetry.shutterNs ?: 16_666_666L).coerceIn(range)
      val resolved = (shutterNs ?: state.manualSettings.manualShutterNs ?: defaultShutter).coerceIn(range)
      state.copy(
        manualSettings =
          state.manualSettings.copy(
            isManualShutterEnabled = enabled,
            manualShutterNs = if (enabled) resolved else null,
            isExposureLockEnabled = if (enabled) false else state.manualSettings.isExposureLockEnabled,
          )
      )
    }
  }

  fun setWhiteBalance(option: WhiteBalanceOption) {
    _uiState.update { state ->
      val exp = state.activeHardwareProfile?.exposureAndRaw
      val allowed =
        when (option) {
          WhiteBalanceOption.AUTO -> true
          WhiteBalanceOption.MANUAL_KELVIN -> exp?.isManualKelvinSupported == true
          else -> exp?.supportedAwbModes?.contains(option) == true
        }
      if (!allowed) return@update state
      state.copy(
        manualSettings =
          state.manualSettings.copy(
            whiteBalanceMode = option,
            manualKelvin = option.approxKelvin ?: state.manualSettings.manualKelvin,
          )
      )
    }
  }

  fun setManualKelvin(kelvin: Int) {
    _uiState.update { state ->
      val exp = state.activeHardwareProfile?.exposureAndRaw
      if (exp?.isManualKelvinSupported != true) return@update state
      state.copy(
        manualSettings =
          state.manualSettings.copy(
            whiteBalanceMode = WhiteBalanceOption.MANUAL_KELVIN,
            manualKelvin = kelvin.coerceIn(2200, 8000),
          )
      )
    }
  }

  fun setManualFocus(enabled: Boolean, diopters: Float? = null) {
    _uiState.update { state ->
      val foc = state.activeHardwareProfile?.focusCapabilities
      if (foc?.isManualFocusSupported != true) return@update state
      val maxD = foc.minimumFocusDistanceDiopters
      val fallbackD = state.liveTelemetry.focusDistanceDiopters ?: state.manualSettings.manualFocusDiopters
      val resolved = (diopters ?: fallbackD).coerceIn(0f, maxD)
      state.copy(
        manualSettings =
          state.manualSettings.copy(
            isManualFocusEnabled = enabled,
            manualFocusDiopters = resolved,
          ),
        focusPoint = if (enabled) null else state.focusPoint,
      )
    }
  }

  fun toggleExposureLock() {
    _uiState.update { state ->
      val exp = state.activeHardwareProfile?.exposureAndRaw
      if (exp?.isAeLockSupported != true) return@update state
      val nextLock = !state.manualSettings.isExposureLockEnabled
      state.copy(
        manualSettings =
          state.manualSettings.copy(
            isExposureLockEnabled = nextLock,
            isManualIsoEnabled = if (nextLock) false else state.manualSettings.isManualIsoEnabled,
            isManualShutterEnabled =
              if (nextLock) false else state.manualSettings.isManualShutterEnabled,
          )
      )
    }
  }

  fun selectCaptureOutputFormat(format: CaptureOutputFormat) {
    _uiState.update { state ->
      val exp = state.activeHardwareProfile?.exposureAndRaw
      val allowed =
        when (format) {
          CaptureOutputFormat.JPEG -> true
          CaptureOutputFormat.RAW_DNG ->
            exp?.isRawSupported == true && exp.isCameraXRawOnlySupported
          CaptureOutputFormat.RAW_PLUS_JPEG ->
            exp?.isRawSupported == true && exp.isCameraXRawJpegSupported
        }
      if (!allowed) return@update state
      val isRaw = format != CaptureOutputFormat.JPEG
      state.copy(
        isBurstModeEnabled = if (isRaw) false else state.isBurstModeEnabled,
        manualSettings =
          state.manualSettings.copy(
            captureOutputFormat = format,
            isRawCaptureEnabled = isRaw,
          ),
      )
    }
  }

  fun toggleRawCapture() {
    _uiState.update { state ->
      val exp = state.activeHardwareProfile?.exposureAndRaw
      if (exp?.isRawSupported != true || (!exp.isCameraXRawJpegSupported && !exp.isCameraXRawOnlySupported)) {
        return@update state
      }
      val nextRaw = !state.manualSettings.isRawCaptureEnabled
      val nextFormat =
        if (!nextRaw) {
          CaptureOutputFormat.JPEG
        } else if (exp.isCameraXRawJpegSupported) {
          CaptureOutputFormat.RAW_PLUS_JPEG
        } else {
          CaptureOutputFormat.RAW_DNG
        }
      state.copy(
        isBurstModeEnabled = if (nextRaw) false else state.isBurstModeEnabled,
        manualSettings =
          state.manualSettings.copy(
            captureOutputFormat = nextFormat,
            isRawCaptureEnabled = nextRaw,
          ),
      )
    }
  }

  fun selectStabilization(selection: StabilizationSelection) {
    _uiState.update { state ->
      val stab = state.activeHardwareProfile?.videoAndStabilization ?: return@update state
      val allowed =
        when (selection) {
          StabilizationSelection.AUTO,
          StabilizationSelection.OFF -> true
          StabilizationSelection.OIS -> stab.isOisSupported
          StabilizationSelection.EIS -> stab.isEisSupported || stab.isPreviewStabilizationSupported
        }
      if (!allowed) return@update state
      state.copy(
        manualSettings = state.manualSettings.copy(stabilizationSelection = selection)
      )
    }
  }

  fun toggleFocusPeaking() {
    _uiState.update { state ->
      val next = !state.manualSettings.isFocusPeakingEnabled
      state.copy(
        manualSettings = state.manualSettings.copy(isFocusPeakingEnabled = next),
        frameAnalysis =
          if (!next && !state.manualSettings.isHistogramEnabled && !state.manualSettings.isZebraEnabled) {
            null
          } else {
            state.frameAnalysis
          },
      )
    }
  }

  fun cycleFocusPeakingColor() {
    _uiState.update { state ->
      val colors = FocusPeakingColor.entries
      val nextIdx = (colors.indexOf(state.manualSettings.focusPeakingColor) + 1) % colors.size
      state.copy(
        manualSettings = state.manualSettings.copy(focusPeakingColor = colors[nextIdx])
      )
    }
  }

  fun toggleHistogram() {
    _uiState.update { state ->
      val next = !state.manualSettings.isHistogramEnabled
      state.copy(
        manualSettings = state.manualSettings.copy(isHistogramEnabled = next),
        frameAnalysis =
          if (!next && !state.manualSettings.isFocusPeakingEnabled && !state.manualSettings.isZebraEnabled) {
            null
          } else {
            state.frameAnalysis
          },
      )
    }
  }

  fun toggleZebraExposure() {
    _uiState.update { state ->
      val next = !state.manualSettings.isZebraEnabled
      state.copy(
        manualSettings = state.manualSettings.copy(isZebraEnabled = next),
        frameAnalysis =
          if (!next && !state.manualSettings.isFocusPeakingEnabled && !state.manualSettings.isHistogramEnabled) {
            null
          } else {
            state.frameAnalysis
          },
      )
    }
  }

  fun setZebraThreshold(percent: Int) {
    _uiState.update {
      it.copy(
        manualSettings =
          it.manualSettings.copy(zebraThresholdPercent = percent.coerceIn(75, 100))
      )
    }
  }

  fun updateLiveTelemetry(telemetry: LiveExposureTelemetry) {
    _uiState.update { state ->
      val updatedScene =
        if (state.photographyMode == PhotographyMode.AUTO_SCENE && state.frameAnalysis != null) {
          PhotographyModeManager.classifyLiveScene(state.frameAnalysis, telemetry)
        } else {
          state.detectedAutoScene
        }
      state.copy(liveTelemetry = telemetry, detectedAutoScene = updatedScene)
    }
  }

  fun updateFrameAnalysis(analysis: FrameAnalysisData) {
    _uiState.update { state ->
      val updatedScene =
        if (state.photographyMode == PhotographyMode.AUTO_SCENE) {
          PhotographyModeManager.classifyLiveScene(analysis, state.liveTelemetry)
        } else {
          state.detectedAutoScene
        }
      state.copy(frameAnalysis = analysis, detectedAutoScene = updatedScene)
    }
  }

  fun updateModeCapabilities(capabilities: CameraModeCapabilities) {
    var fallbackMessage: String? = null
    _uiState.update { state ->
      val currentMode = state.photographyMode
      val avail = capabilities.availabilityOf(currentMode)
      val nextMode =
        if (!capabilities.isInitialized || avail.isSupported) {
          currentMode
        } else {
          fallbackMessage = "${currentMode.label} unavailable on this sensor — switched to Photo"
          PhotographyMode.STANDARD
        }
      state.copy(
        modeCapabilities = capabilities,
        photographyMode = nextMode,
        panoramaState =
          if (nextMode != PhotographyMode.PANORAMA) PanoramaSessionState()
          else state.panoramaState,
      )
    }
    fallbackMessage?.let { showTransientBanner(it) }
  }

  fun selectPhotographyMode(mode: PhotographyMode) {
    val state = _uiState.value
    val avail = state.modeCapabilities.availabilityOf(mode)
    if (!avail.isSupported) {
      showTransientBanner(avail.reason)
      return
    }
    if (state.photographyMode == mode && mode != PhotographyMode.MACRO) return

    cancelCountdown()

    var targetCameraId = state.activeCameraId
    var targetProfile = state.activeHardwareProfile
    var targetLens = state.lensOption

    if (mode == PhotographyMode.MACRO) {
      val macroId = state.modeCapabilities.bestMacroCameraId
      if (macroId != null && macroId != state.activeCameraId) {
        val macroProfile = state.deviceInventory.findSelectableById(macroId)
        if (macroProfile != null) {
          targetCameraId = macroProfile.cameraId
          targetProfile = macroProfile
          targetLens =
            if (macroProfile.lensFacing == CameraMetadata.LENS_FACING_FRONT) LensOption.FRONT
            else LensOption.BACK
        }
      }
    }

    val forceJpegOnly =
      mode == PhotographyMode.PANORAMA ||
        mode == PhotographyMode.PORTRAIT ||
        mode == PhotographyMode.HDR ||
        mode == PhotographyMode.NIGHT ||
        mode == PhotographyMode.LOW_LIGHT

    val updatedManual =
      sanitizeManualSettingsForProfile(state.manualSettings, targetProfile).let { m ->
        if (forceJpegOnly && m.isRawCaptureEnabled) {
          m.copy(captureOutputFormat = CaptureOutputFormat.JPEG, isRawCaptureEnabled = false)
        } else {
          m
        }
      }

    _uiState.update { s ->
      s.copy(
        photographyMode = mode,
        activeCameraId = targetCameraId,
        activeHardwareProfile = targetProfile,
        lensOption = targetLens,
        isBurstModeEnabled = if (mode == PhotographyMode.STANDARD) s.isBurstModeEnabled else false,
        aspectRatio =
          if (mode == PhotographyMode.HIGH_RES || mode == PhotographyMode.PANORAMA) {
            PreviewAspectRatio.RATIO_4_3
          } else {
            s.aspectRatio
          },
        manualSettings = updatedManual,
        panoramaState = PanoramaSessionState(),
        errorMessage = null,
      )
    }
    showTransientBanner("${mode.label}: ${avail.backendLabel}")
  }

  fun updatePanoramaProgress(
    isActive: Boolean,
    capturedSlicesCount: Int,
    currentYawDeg: Float = _uiState.value.panoramaState.currentYawDeg,
    pitchTiltDeg: Float = _uiState.value.panoramaState.pitchTiltDeg,
    isStitching: Boolean = false,
    statusHint: String = _uiState.value.panoramaState.statusHint,
  ) {
    _uiState.update { state ->
      state.copy(
        panoramaState =
          state.panoramaState.copy(
            isActive = isActive,
            capturedSlicesCount = capturedSlicesCount,
            currentYawDeg = currentYawDeg,
            pitchTiltDeg = pitchTiltDeg,
            isStitching = isStitching,
            statusHint = statusHint,
          )
      )
    }
  }

  fun updatePanoramaMotion(yawDeg: Float, pitchTiltDeg: Float) {
    _uiState.update { state ->
      if (state.photographyMode != PhotographyMode.PANORAMA) return@update state
      state.copy(
        panoramaState =
          state.panoramaState.copy(
            currentYawDeg = yawDeg,
            pitchTiltDeg = pitchTiltDeg,
          )
      )
    }
  }

  fun resetPanoramaSession() {
    _uiState.update { it.copy(panoramaState = PanoramaSessionState()) }
  }

  fun saveCustomPreset(context: Context, name: String) {
    val trimmed = name.trim()
    if (trimmed.isEmpty()) return
    val state = _uiState.value
    val m = state.manualSettings
    val preset =
      ProPreset(
        id = "preset_${System.currentTimeMillis()}",
        name = trimmed,
        isManualIsoEnabled = m.isManualIsoEnabled,
        manualIso = m.manualIso,
        isManualShutterEnabled = m.isManualShutterEnabled,
        manualShutterNs = m.manualShutterNs,
        whiteBalanceMode = m.whiteBalanceMode,
        manualKelvin = m.manualKelvin,
        isManualFocusEnabled = m.isManualFocusEnabled,
        manualFocusDiopters = m.manualFocusDiopters,
        exposureCompIndex = state.sensorCapabilities.currentExposureIndex,
        captureOutputFormat = m.captureOutputFormat,
        stabilizationSelection = m.stabilizationSelection,
        isFocusPeakingEnabled = m.isFocusPeakingEnabled,
        isHistogramEnabled = m.isHistogramEnabled,
        isZebraEnabled = m.isZebraEnabled,
      )
    val appContext = context.applicationContext
    viewModelScope.launch {
      ProPresetsRepository.savePreset(appContext, preset)
      showTransientBanner("Saved preset: $trimmed")
    }
  }

  fun applyCustomPreset(preset: ProPreset, applyEvIndex: (Int) -> Unit) {
    val state = _uiState.value
    val profile = state.activeHardwareProfile
    val exp = profile?.exposureAndRaw
    val foc = profile?.focusCapabilities

    val requestedSettings =
      state.manualSettings.copy(
        isManualIsoEnabled = preset.isManualIsoEnabled,
        manualIso = preset.manualIso,
        isManualShutterEnabled = preset.isManualShutterEnabled,
        manualShutterNs = preset.manualShutterNs,
        whiteBalanceMode = preset.whiteBalanceMode,
        manualKelvin = preset.manualKelvin,
        isManualFocusEnabled = preset.isManualFocusEnabled,
        manualFocusDiopters = preset.manualFocusDiopters,
        captureOutputFormat = preset.captureOutputFormat,
        isRawCaptureEnabled = preset.captureOutputFormat != CaptureOutputFormat.JPEG,
        stabilizationSelection = preset.stabilizationSelection,
        isFocusPeakingEnabled = preset.isFocusPeakingEnabled,
        isHistogramEnabled = preset.isHistogramEnabled,
        isZebraEnabled = preset.isZebraEnabled,
      )

    val sanitized = sanitizeManualSettingsForProfile(requestedSettings, profile)
    val evRange = state.sensorCapabilities.exposureRange
    if (evRange.first < evRange.last) {
      val clampedEv = preset.exposureCompIndex.coerceIn(evRange)
      applyEvIndex(clampedEv)
    }

    _uiState.update { s ->
      s.copy(
        isBurstModeEnabled =
          if (sanitized.isRawCaptureEnabled) false else s.isBurstModeEnabled,
        manualSettings = sanitized,
      )
    }

    val unsupportedNotes = buildList {
      if ((preset.isManualIsoEnabled || preset.isManualShutterEnabled) && exp?.isManualExposureSupported != true) {
        add("Manual ISO/Shutter")
      }
      if (preset.isManualFocusEnabled && foc?.isManualFocusSupported != true) {
        add("Manual Focus")
      }
      if (preset.captureOutputFormat != CaptureOutputFormat.JPEG && !sanitized.isRawCaptureEnabled) {
        add("RAW")
      }
    }
    val msg =
      if (unsupportedNotes.isEmpty()) "Applied preset: ${preset.name}"
      else "Applied ${preset.name} (unavailable on sensor: ${unsupportedNotes.joinToString(", ")})"
    showTransientBanner(msg)
  }

  fun deleteCustomPreset(context: Context, presetId: String) {
    val appContext = context.applicationContext
    viewModelScope.launch {
      ProPresetsRepository.deletePreset(appContext, presetId)
    }
  }

  fun resetAllProToAuto(applyEvIndex: (Int) -> Unit) {
    val evRange = _uiState.value.sensorCapabilities.exposureRange
    if (evRange.first < evRange.last) {
      applyEvIndex(0)
    }
    _uiState.update { state ->
      state.copy(
        manualSettings =
          state.manualSettings.copy(
            isManualIsoEnabled = false,
            manualIso = null,
            isManualShutterEnabled = false,
            manualShutterNs = null,
            whiteBalanceMode = WhiteBalanceOption.AUTO,
            manualKelvin = 5500,
            isManualFocusEnabled = false,
            manualFocusDiopters = 0f,
            isExposureLockEnabled = false,
            captureOutputFormat = CaptureOutputFormat.JPEG,
            isRawCaptureEnabled = false,
            stabilizationSelection = StabilizationSelection.AUTO,
          )
      )
    }
    showTransientBanner("Reset Pro controls to Auto")
  }

  private fun showTransientBanner(banner: String) {
    _uiState.update { it.copy(statusBanner = banner) }
    viewModelScope.launch {
      delay(2400)
      _uiState.update { state ->
        if (state.statusBanner == banner) state.copy(statusBanner = null) else state
      }
    }
  }

  fun openHardwareInspector(cameraId: String? = null) {
    _uiState.update { state ->
      val targetId =
        cameraId
          ?: state.activeCameraId
          ?: state.deviceInventory.allLogicalAndStandaloneCameras.firstOrNull()?.cameraId
      state.copy(
        isHardwareInspectorOpen = true,
        inspectorSelectedCameraId = targetId,
      )
    }
  }

  fun selectInspectorCamera(cameraId: String) {
    _uiState.update { it.copy(inspectorSelectedCameraId = cameraId) }
  }

  fun closeHardwareInspector() {
    _uiState.update { it.copy(isHardwareInspectorOpen = false) }
  }

  fun updateSensorCapabilities(capabilities: SensorCapabilities) {
    _uiState.update { state ->
      val flash = if (capabilities.hasFlash) state.flashSetting else FlashSetting.OFF
      state.copy(sensorCapabilities = capabilities, flashSetting = flash)
    }
  }

  fun updateZoomRatio(zoomRatio: Float) {
    _uiState.update { state ->
      state.copy(
        sensorCapabilities = state.sensorCapabilities.copy(currentZoomRatio = zoomRatio)
      )
    }
  }

  fun updateExposureIndex(index: Int) {
    _uiState.update { state ->
      state.copy(
        sensorCapabilities = state.sensorCapabilities.copy(currentExposureIndex = index)
      )
    }
  }

  fun showFocusPoint(x: Float, y: Float, lockedSuccess: Boolean? = null) {
    val timestamp = System.currentTimeMillis()
    _uiState.update {
      it.copy(
        focusPoint =
          FocusPointState(
            x = x,
            y = y,
            timestamp = timestamp,
            isLockedSuccess = lockedSuccess,
          )
      )
    }
    viewModelScope.launch {
      delay(1800)
      _uiState.update { state ->
        if (state.focusPoint?.timestamp == timestamp) state.copy(focusPoint = null) else state
      }
    }
  }

  fun onCaptureStarted() {
    _uiState.update {
      it.copy(
        isCapturing = true,
        shutterBlinkCounter = it.shutterBlinkCounter + 1,
        errorMessage = null,
      )
    }
  }

  fun onCaptureSucceeded(
    context: Context,
    savedUri: Uri,
    displayName: String,
    rawSaved: Boolean = false,
    burstSummary: String? = null,
  ) {
    val appContext = context.applicationContext
    val isRawOnly = displayName.endsWith(".dng", ignoreCase = true)
    viewModelScope.launch {
      val photoInfo =
        withContext(Dispatchers.IO) {
          MediaStorePhotoSaver.inspectPhotoInfo(appContext, savedUri, displayName)
        }
      val banner =
        when {
          burstSummary != null -> burstSummary
          isRawOnly && photoInfo.width > 0 ->
            "Saved RAW DNG ${photoInfo.width}×${photoInfo.height}"
          isRawOnly -> "Saved RAW DNG to Gallery"
          rawSaved && photoInfo.width > 0 ->
            "Saved RAW+JPEG ${photoInfo.width}×${photoInfo.height}"
          photoInfo.width > 0 && photoInfo.height > 0 ->
            "Saved ${photoInfo.width}×${photoInfo.height}"
          else -> "Saved to Gallery"
        }
      _uiState.update {
        it.copy(
          isCapturing = false,
          burstProgressCount = null,
          lastCapturedPhoto = photoInfo,
          statusBanner = banner,
          errorMessage = null,
        )
      }
      delay(2400)
      _uiState.update { state ->
        if (state.statusBanner == banner) state.copy(statusBanner = null) else state
      }
    }
  }

  fun onCaptureFailed(message: String) {
    _uiState.update {
      it.copy(
        isCapturing = false,
        burstProgressCount = null,
        errorMessage = message,
      )
    }
  }

  fun onCameraBindError(message: String) {
    _uiState.update { it.copy(errorMessage = message) }
  }

  fun openPhotoViewer(photo: CapturedPhotoInfo) {
    _uiState.update { it.copy(inspectedPhoto = photo, isPhotoViewerOpen = true) }
  }

  fun openPickedPhotoUri(context: Context, uri: Uri) {
    val appContext = context.applicationContext
    viewModelScope.launch {
      val info = withContext(Dispatchers.IO) { MediaStorePhotoSaver.inspectPhotoInfo(appContext, uri) }
      _uiState.update { it.copy(inspectedPhoto = info, isPhotoViewerOpen = true) }
    }
  }

  fun closePhotoViewer() {
    _uiState.update { it.copy(isPhotoViewerOpen = false) }
  }

  fun selectCaptureDomain(domain: AppCaptureDomain) {
    val state = _uiState.value
    if (state.captureDomain == domain) return
    if (state.videoRecordingState.isRecording || state.videoRecordingState.isFinalizing) {
      showTransientBanner("Stop recording before switching modes")
      return
    }
    if (state.isCapturing || state.panoramaState.isActive) {
      showTransientBanner("Finish active capture first")
      return
    }
    cancelCountdown()
    _uiState.update {
      it.copy(
        captureDomain = domain,
        isVideoSettingsOpen = false,
        manualSettings =
          if (domain == AppCaptureDomain.VIDEO) it.manualSettings.copy(isProPanelOpen = false)
          else it.manualSettings,
        videoSettings =
          if (domain == AppCaptureDomain.PHOTO) it.videoSettings.copy(isTorchEnabled = false)
          else it.videoSettings,
        errorMessage = null,
      )
    }
  }

  fun toggleVideoSettingsPanel() {
    _uiState.update { it.copy(isVideoSettingsOpen = !it.isVideoSettingsOpen) }
  }

  fun updateVideoCapabilities(capabilities: CameraVideoCapabilities) {
    _uiState.update { state ->
      val current = state.videoSettings
      val resolvedQuality =
        if (capabilities.availabilityOf(current.quality).isSupported) {
          current.quality
        } else {
          capabilities.supportedQualityList().lastOrNull { it == VideoQualityOption.FHD_1080P }
            ?: capabilities.supportedQualityList().firstOrNull()
            ?: VideoQualityOption.FHD_1080P
        }

      val resolvedFps =
        if (capabilities.availabilityOf(current.fps).isSupported) {
          current.fps
        } else {
          capabilities.supportedFpsList().firstOrNull { it == VideoFpsOption.FPS_30 }
            ?: capabilities.supportedFpsList().firstOrNull()
            ?: VideoFpsOption.FPS_30
        }

      val resolvedHdr =
        !resolvedFps.isHighSpeed &&
          current.isHdrEnabled &&
          capabilities.hdrAvailability.isSupported &&
          capabilities.hdrAvailability.supportedQualities.contains(resolvedQuality)

      val resolvedBitrate =
        if (capabilities.isBitrateSupported(current.bitrate)) current.bitrate
        else VideoBitrateOption.AUTO

      val resolvedStab =
        when (current.stabilization) {
          StabilizationSelection.OIS ->
            if (capabilities.isOisSupported) StabilizationSelection.OIS else StabilizationSelection.AUTO
          StabilizationSelection.EIS ->
            if (capabilities.isEisSupported) StabilizationSelection.EIS else StabilizationSelection.AUTO
          else -> current.stabilization
        }

      state.copy(
        videoCapabilities = capabilities,
        videoSettings =
          current.copy(
            quality = resolvedQuality,
            fps = resolvedFps,
            bitrate = resolvedBitrate,
            isHdrEnabled = resolvedHdr,
            stabilization = resolvedStab,
          ),
      )
    }
  }

  fun selectVideoQuality(quality: VideoQualityOption) {
    val state = _uiState.value
    if (state.videoRecordingState.isRecording) {
      showTransientBanner("Stop recording to change resolution")
      return
    }
    val avail = state.videoCapabilities.availabilityOf(quality)
    if (!avail.isSupported) {
      showTransientBanner(avail.reason)
      return
    }
    _uiState.update { s ->
      val hdrValid =
        s.videoSettings.isHdrEnabled &&
          s.videoCapabilities.hdrAvailability.isSupported &&
          s.videoCapabilities.hdrAvailability.supportedQualities.contains(quality)
      s.copy(
        videoSettings =
          s.videoSettings.copy(
            quality = quality,
            isHdrEnabled = hdrValid,
          )
      )
    }
    showTransientBanner("Video: ${quality.displayName} (${avail.reason})")
  }

  fun selectVideoFps(fps: VideoFpsOption) {
    val state = _uiState.value
    if (state.videoRecordingState.isRecording) {
      showTransientBanner("Stop recording to change frame rate")
      return
    }
    val avail = state.videoCapabilities.availabilityOf(fps)
    if (!avail.isSupported) {
      showTransientBanner(avail.reason)
      return
    }
    _uiState.update { s ->
      val nextHdr = if (fps.isHighSpeed) false else s.videoSettings.isHdrEnabled
      val hsQualities = avail.supportedHighSpeedQualities
      val currentCamXQuality = s.videoSettings.quality.toCameraXQualityOrNull()
      val adjustedQuality =
        if (fps.isHighSpeed && hsQualities.isNotEmpty() && !hsQualities.contains(currentCamXQuality)) {
          VideoQualityOption.entries.firstOrNull { opt ->
            opt.toCameraXQualityOrNull() == hsQualities.first() &&
              s.videoCapabilities.availabilityOf(opt).isSupported
          } ?: s.videoSettings.quality
        } else {
          s.videoSettings.quality
        }
      s.copy(
        videoSettings =
          s.videoSettings.copy(
            fps = fps,
            quality = adjustedQuality,
            isHdrEnabled = nextHdr,
          )
      )
    }
    showTransientBanner("${fps.fps} FPS · ${avail.reason}")
  }

  fun selectVideoBitrate(bitrate: VideoBitrateOption) {
    val state = _uiState.value
    if (state.videoRecordingState.isRecording) {
      showTransientBanner("Stop recording to change bitrate")
      return
    }
    if (!state.videoCapabilities.isBitrateSupported(bitrate)) {
      val maxMbps = state.videoCapabilities.maxEncoderBitrateBps / 1_000_000
      showTransientBanner("Unavailable: Hardware encoder caps at $maxMbps Mbps")
      return
    }
    _uiState.update {
      it.copy(videoSettings = it.videoSettings.copy(bitrate = bitrate))
    }
  }

  fun selectVideoStabilization(selection: StabilizationSelection) {
    val state = _uiState.value
    if (state.videoRecordingState.isRecording) {
      showTransientBanner("Stop recording to change stabilization")
      return
    }
    val caps = state.videoCapabilities
    val allowed =
      when (selection) {
        StabilizationSelection.AUTO,
        StabilizationSelection.OFF -> true
        StabilizationSelection.OIS -> caps.isOisSupported
        StabilizationSelection.EIS -> caps.isEisSupported
      }
    if (!allowed) {
      showTransientBanner("Unavailable: ${selection.label} stabilization not supported on this lens")
      return
    }
    _uiState.update {
      it.copy(videoSettings = it.videoSettings.copy(stabilization = selection))
    }
  }

  fun toggleVideoHdr() {
    val state = _uiState.value
    if (state.videoRecordingState.isRecording) {
      showTransientBanner("Stop recording to toggle Video HDR")
      return
    }
    val hdr = state.videoCapabilities.hdrAvailability
    if (!hdr.isSupported) {
      showTransientBanner(hdr.reason)
      return
    }
    if (state.videoSettings.fps.isHighSpeed) {
      showTransientBanner("Video HDR unavailable in High-Speed ${state.videoSettings.fps.fps}fps mode")
      return
    }
    val nextHdr = !state.videoSettings.isHdrEnabled
    if (nextHdr && !hdr.supportedQualities.contains(state.videoSettings.quality)) {
      val fallbackQ = hdr.supportedQualities.firstOrNull()
      if (fallbackQ != null) {
        _uiState.update {
          it.copy(
            videoSettings = it.videoSettings.copy(isHdrEnabled = true, quality = fallbackQ)
          )
        }
        showTransientBanner("HDR ${hdr.label} enabled (${fallbackQ.shortLabel})")
        return
      }
    }
    _uiState.update {
      it.copy(videoSettings = it.videoSettings.copy(isHdrEnabled = nextHdr))
    }
  }

  fun toggleVideoAudio() {
    if (_uiState.value.videoRecordingState.isRecording) {
      showTransientBanner("Audio mode locked during active recording")
      return
    }
    _uiState.update { state ->
      val nextAudio = !state.videoSettings.isAudioEnabled
      state.copy(
        videoSettings = state.videoSettings.copy(isAudioEnabled = nextAudio),
        videoRecordingState = state.videoRecordingState.copy(pendingRecordWithAudio = false),
      )
    }
    val isAudio = _uiState.value.videoSettings.isAudioEnabled
    showTransientBanner(
      if (isAudio) "Audio Recording Enabled" else "Silent Video Mode (No Mic Required)"
    )
  }

  fun enableSilentVideoMode() {
    _uiState.update {
      it.copy(
        videoSettings = it.videoSettings.copy(isAudioEnabled = false),
        videoRecordingState = it.videoRecordingState.copy(pendingRecordWithAudio = false),
        errorMessage = null,
      )
    }
    showTransientBanner("Switched to Silent Video")
  }

  fun toggleVideoTorch() {
    val state = _uiState.value
    if (!state.sensorCapabilities.hasFlash) return
    _uiState.update {
      it.copy(videoSettings = it.videoSettings.copy(isTorchEnabled = !it.videoSettings.isTorchEnabled))
    }
  }

  fun toggleSlowMotionBakedIn() {
    val state = _uiState.value
    if (state.videoRecordingState.isRecording) return
    _uiState.update {
      it.copy(
        videoSettings =
          it.videoSettings.copy(isSlowMotionBakedIn = !it.videoSettings.isSlowMotionBakedIn)
      )
    }
  }

  fun updateAudioPermissionStatus(
    status: AudioPermissionStatus,
    pendingRecord: Boolean? = null,
  ) {
    _uiState.update { state ->
      state.copy(
        videoRecordingState =
          state.videoRecordingState.copy(
            audioPermissionStatus = status,
            pendingRecordWithAudio =
              pendingRecord ?: state.videoRecordingState.pendingRecordWithAudio,
          )
      )
    }
  }

  fun setPendingRecordWithAudio(pending: Boolean) {
    _uiState.update {
      it.copy(
        videoRecordingState = it.videoRecordingState.copy(pendingRecordWithAudio = pending)
      )
    }
  }

  fun onVideoRecordingStarted(withAudio: Boolean) {
    _uiState.update {
      it.copy(
        videoRecordingState =
          it.videoRecordingState.copy(
            isRecording = true,
            isPaused = false,
            isFinalizing = false,
            elapsedDurationMs = 0L,
            recordedBytes = 0L,
            audioAmplitude = 0f,
            hasAudioTrack = withAudio,
            pendingRecordWithAudio = false,
          ),
        isVideoSettingsOpen = false,
        errorMessage = null,
      )
    }
  }

  fun onVideoRecordingStatus(
    durationMs: Long,
    bytes: Long,
    amplitude: Float,
    hasAudio: Boolean,
  ) {
    _uiState.update {
      it.copy(
        videoRecordingState =
          it.videoRecordingState.copy(
            elapsedDurationMs = durationMs,
            recordedBytes = bytes,
            audioAmplitude = amplitude,
            hasAudioTrack = hasAudio,
          )
      )
    }
  }

  fun onVideoRecordingPaused() {
    _uiState.update {
      it.copy(videoRecordingState = it.videoRecordingState.copy(isPaused = true))
    }
  }

  fun onVideoRecordingResumed() {
    _uiState.update {
      it.copy(videoRecordingState = it.videoRecordingState.copy(isPaused = false))
    }
  }

  fun onVideoRecordingFinalizing() {
    _uiState.update {
      it.copy(videoRecordingState = it.videoRecordingState.copy(isFinalizing = true))
    }
  }

  fun onVideoRecordingSaved(
    context: Context,
    uri: Uri,
    displayName: String,
    durationMs: Long,
    fps: Int?,
    isHdr: Boolean,
  ) {
    val appContext = context.applicationContext
    viewModelScope.launch {
      val videoInfo =
        withContext(Dispatchers.IO) {
          MediaStoreVideoSaver.inspectVideoInfo(
            context = appContext,
            uri = uri,
            fallbackName = displayName,
            fallbackDurationMs = durationMs,
            fps = fps,
            isHdr = isHdr,
          )
        }
      val resLabel =
        if (videoInfo.width > 0 && videoInfo.height > 0) {
          "${videoInfo.width}×${videoInfo.height}"
        } else {
          "Video"
        }
      val durText = MediaStoreVideoSaver.formatDurationMs(videoInfo.durationMs)
      val banner = "Saved $resLabel ($durText) to Movies/UltraCamPro"
      _uiState.update {
        it.copy(
          videoRecordingState =
            it.videoRecordingState.copy(
              isRecording = false,
              isPaused = false,
              isFinalizing = false,
              elapsedDurationMs = 0L,
              recordedBytes = 0L,
              audioAmplitude = 0f,
            ),
          lastCapturedPhoto = videoInfo,
          statusBanner = banner,
          errorMessage = null,
        )
      }
      delay(2600)
      _uiState.update { state ->
        if (state.statusBanner == banner) state.copy(statusBanner = null) else state
      }
    }
  }

  fun onVideoRecordingFailed(message: String) {
    _uiState.update {
      it.copy(
        videoRecordingState =
          it.videoRecordingState.copy(
            isRecording = false,
            isPaused = false,
            isFinalizing = false,
            elapsedDurationMs = 0L,
            recordedBytes = 0L,
            audioAmplitude = 0f,
            pendingRecordWithAudio = false,
          ),
        errorMessage = message,
      )
    }
  }

  fun clearError() {
    _uiState.update { it.copy(errorMessage = null) }
  }
}
