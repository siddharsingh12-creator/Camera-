package com.example.camera

import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.RggbChannelVector
import android.os.Build
import android.util.Size
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import java.util.Locale
import kotlin.math.abs

object CameraCapabilitiesHelper {

  /**
   * Inspects the physical camera sensor's supported JPEG output dimensions directly from
   * CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP without artificial upscaling.
   */
  @OptIn(ExperimentalCamera2Interop::class)
  fun queryMaxNativeJpegSize(
    cameraInfo: CameraInfo,
    aspectRatio: PreviewAspectRatio,
  ): Size? {
    return try {
      val camera2Info = Camera2CameraInfo.from(cameraInfo)
      val map =
        camera2Info.getCameraCharacteristic(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
          ?: return null

      val standardSizes = map.getOutputSizes(ImageFormat.JPEG)?.toList().orEmpty()
      val highResSizes = map.getHighResolutionOutputSizes(ImageFormat.JPEG)?.toList().orEmpty()
      val allSizes = (standardSizes + highResSizes).distinct()
      if (allSizes.isEmpty()) return null

      val targetRatio =
        when (aspectRatio) {
          PreviewAspectRatio.RATIO_4_3,
          PreviewAspectRatio.RATIO_1_1,
          PreviewAspectRatio.FULL -> 4.0 / 3.0
          PreviewAspectRatio.RATIO_16_9 -> 16.0 / 9.0
        }

      val matchingAspect =
        allSizes.filter { size ->
          val longSide = maxOf(size.width, size.height).toDouble()
          val shortSide = minOf(size.width, size.height).toDouble()
          if (shortSide <= 0.0) false else abs((longSide / shortSide) - targetRatio) < 0.08
        }

      val candidates = matchingAspect.ifEmpty { allSizes }
      candidates.maxByOrNull { it.width.toLong() * it.height.toLong() }
    } catch (_: Exception) {
      null
    }
  }

  /**
   * Builds a CameraX ResolutionSelector targeting the highest supported native hardware resolution
   * for the selected aspect ratio.
   */
  fun buildCaptureResolutionSelector(aspectRatio: PreviewAspectRatio): ResolutionSelector {
    val aspectStrategy =
      when (aspectRatio) {
        PreviewAspectRatio.RATIO_4_3,
        PreviewAspectRatio.RATIO_1_1,
        PreviewAspectRatio.FULL -> AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
        PreviewAspectRatio.RATIO_16_9 -> AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
      }

    return ResolutionSelector.Builder()
      .setAspectRatioStrategy(aspectStrategy)
      .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
      .build()
  }

  fun buildPreviewResolutionSelector(aspectRatio: PreviewAspectRatio): ResolutionSelector {
    val aspectStrategy =
      when (aspectRatio) {
        PreviewAspectRatio.RATIO_4_3,
        PreviewAspectRatio.RATIO_1_1 -> AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
        PreviewAspectRatio.RATIO_16_9,
        PreviewAspectRatio.FULL -> AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
      }

    return ResolutionSelector.Builder()
      .setAspectRatioStrategy(aspectStrategy)
      .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
      .build()
  }

  fun extractSensorCapabilities(
    camera: Camera,
    activeCaptureSize: Size?,
    aspectRatio: PreviewAspectRatio,
  ): SensorCapabilities {
    val info = camera.cameraInfo
    val zoomState = info.zoomState.value
    val exposureState = info.exposureState
    val range =
      if (exposureState.isExposureCompensationSupported) {
        exposureState.exposureCompensationRange.lower..exposureState.exposureCompensationRange.upper
      } else {
        0..0
      }

    return SensorCapabilities(
      maxSensorJpegSize = queryMaxNativeJpegSize(info, aspectRatio),
      activeCaptureSize = activeCaptureSize,
      hasFlash = info.hasFlashUnit(),
      minZoomRatio = zoomState?.minZoomRatio ?: 1f,
      maxZoomRatio = zoomState?.maxZoomRatio ?: 1f,
      currentZoomRatio = zoomState?.zoomRatio ?: 1f,
      exposureRange = range,
      exposureStep = exposureState.exposureCompensationStep.toFloat(),
      currentExposureIndex = exposureState.exposureCompensationIndex,
    )
  }

  @OptIn(ExperimentalCamera2Interop::class)
  fun attachLiveTelemetryCallback(
    previewBuilder: Preview.Builder,
    onTelemetry: (LiveExposureTelemetry) -> Unit,
  ) {
    var lastEmitNs = 0L
    val minIntervalNs = 140_000_000L

    Camera2Interop.Extender(previewBuilder)
      .setSessionCaptureCallback(
        object : CameraCaptureSession.CaptureCallback() {
          override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult,
          ) {
            val now = System.nanoTime()
            if (now - lastEmitNs < minIntervalNs) return
            lastEmitNs = now

            val iso = result.get(CaptureResult.SENSOR_SENSITIVITY)
            val shutterNs = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
            val aperture = result.get(CaptureResult.LENS_APERTURE)
            val focusDist = result.get(CaptureResult.LENS_FOCUS_DISTANCE)
            val aeState = result.get(CaptureResult.CONTROL_AE_STATE)
            val afState = result.get(CaptureResult.CONTROL_AF_STATE)
            val awbState = result.get(CaptureResult.CONTROL_AWB_STATE)
            val gains = result.get(CaptureResult.COLOR_CORRECTION_GAINS)
            val gainsText =
              gains?.let {
                String.format(Locale.US, "R%.2f B%.2f", it.red, it.blue)
              }

            onTelemetry(
              LiveExposureTelemetry(
                iso = iso,
                shutterNs = shutterNs,
                aperture = aperture,
                focusDistanceDiopters = focusDist,
                aeState = aeState,
                afState = afState,
                awbState = awbState,
                colorGainSummary = gainsText,
              )
            )
          }
        }
      )
  }

  @OptIn(ExperimentalCamera2Interop::class)
  fun applyManualCaptureOptions(
    camera: Camera,
    profile: CameraHardwareProfile?,
    manual: ManualProSettings,
    liveTelemetry: LiveExposureTelemetry? = null,
  ) {
    if (profile == null) return
    try {
      val camera2Control = Camera2CameraControl.from(camera.cameraControl)
      val builder = CaptureRequestOptions.Builder()

      val exp = profile.exposureAndRaw
      if (
        exp.isManualExposureSupported &&
          (manual.isManualIsoEnabled || manual.isManualShutterEnabled)
      ) {
        builder.setCaptureRequestOption(
          CaptureRequest.CONTROL_AE_MODE,
          CameraMetadata.CONTROL_AE_MODE_OFF,
        )
        val isoRange = exp.isoRange
        val targetIso =
          if (manual.isManualIsoEnabled) manual.manualIso
          else liveTelemetry?.iso
        if (isoRange != null && targetIso != null) {
          builder.setCaptureRequestOption(
            CaptureRequest.SENSOR_SENSITIVITY,
            targetIso.coerceIn(isoRange),
          )
        }
        val shutterRange = exp.shutterRangeNs
        val targetShutter =
          if (manual.isManualShutterEnabled) manual.manualShutterNs
          else liveTelemetry?.shutterNs
        if (shutterRange != null && targetShutter != null) {
          builder.setCaptureRequestOption(
            CaptureRequest.SENSOR_EXPOSURE_TIME,
            targetShutter.coerceIn(shutterRange),
          )
        }
      } else {
        builder.setCaptureRequestOption(
          CaptureRequest.CONTROL_AE_MODE,
          CameraMetadata.CONTROL_AE_MODE_ON,
        )
        if (exp.isAeLockSupported) {
          builder.setCaptureRequestOption(
            CaptureRequest.CONTROL_AE_LOCK,
            manual.isExposureLockEnabled,
          )
        }
      }

      // White Balance (Auto, Camera2 AWB Modes, or Manual Kelvin RGB Gains)
      when {
        manual.whiteBalanceMode == WhiteBalanceOption.MANUAL_KELVIN && exp.isManualKelvinSupported -> {
          builder.setCaptureRequestOption(
            CaptureRequest.CONTROL_AWB_MODE,
            CameraMetadata.CONTROL_AWB_MODE_OFF,
          )
          builder.setCaptureRequestOption(
            CaptureRequest.COLOR_CORRECTION_MODE,
            CameraMetadata.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX,
          )
          builder.setCaptureRequestOption(
            CaptureRequest.COLOR_CORRECTION_GAINS,
            kelvinToRggbGains(manual.manualKelvin),
          )
        }
        manual.whiteBalanceMode != WhiteBalanceOption.AUTO &&
          exp.supportedAwbModes.contains(manual.whiteBalanceMode) -> {
          builder.setCaptureRequestOption(
            CaptureRequest.CONTROL_AWB_MODE,
            manual.whiteBalanceMode.camera2Mode,
          )
        }
        else -> {
          builder.setCaptureRequestOption(
            CaptureRequest.CONTROL_AWB_MODE,
            CameraMetadata.CONTROL_AWB_MODE_AUTO,
          )
        }
      }

      val foc = profile.focusCapabilities
      if (foc.isManualFocusSupported && manual.isManualFocusEnabled) {
        builder.setCaptureRequestOption(
          CaptureRequest.CONTROL_AF_MODE,
          CameraMetadata.CONTROL_AF_MODE_OFF,
        )
        builder.setCaptureRequestOption(
          CaptureRequest.LENS_FOCUS_DISTANCE,
          manual.manualFocusDiopters.coerceIn(0f, foc.minimumFocusDistanceDiopters),
        )
      } else if (foc.isAutoFocusSupported) {
        builder.setCaptureRequestOption(
          CaptureRequest.CONTROL_AF_MODE,
          CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE,
        )
      }

      val stab = profile.videoAndStabilization
      when (manual.stabilizationSelection) {
        StabilizationSelection.OIS -> {
          if (stab.isOisSupported) {
            builder.setCaptureRequestOption(
              CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
              CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON,
            )
          }
        }
        StabilizationSelection.EIS -> {
          if (
            stab.isPreviewStabilizationSupported &&
              Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
          ) {
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
              CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION,
            )
          } else if (stab.isEisSupported) {
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
              CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON,
            )
          }
        }
        StabilizationSelection.OFF -> {
          if (stab.isOisSupported) {
            builder.setCaptureRequestOption(
              CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
              CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF,
            )
          }
          if (stab.isEisSupported || stab.isPreviewStabilizationSupported) {
            builder.setCaptureRequestOption(
              CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
              CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF,
            )
          }
        }
        StabilizationSelection.AUTO -> {
          if (stab.isOisSupported) {
            builder.setCaptureRequestOption(
              CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
              CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON,
            )
          }
        }
      }

      camera2Control.setCaptureRequestOptions(builder.build())
    } catch (_: Exception) {
      // Ignore if camera session is in transition
    }
  }

  /**
   * Computes balanced RggbChannelVector sensor gains for a manual Kelvin white balance setting.
   * Higher Kelvin warms the image (boosts Red gain, reduces Blue gain); lower Kelvin cools it.
   */
  fun kelvinToRggbGains(kelvin: Int): RggbChannelVector {
    val t = ((kelvin.coerceIn(2200, 8000) - 5500) / 3300f)
    val redGain = (1.75f * (1f + 0.42f * t)).coerceIn(0.8f, 3.6f)
    val blueGain = (1.65f * (1f - 0.45f * t)).coerceIn(0.8f, 3.8f)
    return RggbChannelVector(redGain, 1.0f, 1.0f, blueGain)
  }
}
