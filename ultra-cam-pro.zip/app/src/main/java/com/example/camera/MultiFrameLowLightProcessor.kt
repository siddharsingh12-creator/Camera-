package com.example.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import kotlin.math.roundToInt
import kotlin.math.sqrt

object MultiFrameLowLightProcessor {

  fun alignAndBlendToMediaStore(
    context: Context,
    capturedFrames: List<Pair<ByteArray, Int>>,
    mirrorHorizontal: Boolean,
  ): Pair<Uri, String>? {
    if (capturedFrames.isEmpty()) return null

    val bitmaps =
      capturedFrames.mapNotNull { (bytes, rot) ->
        decodeOrientedBitmap(bytes, rot, mirrorHorizontal)
      }
    if (bitmaps.isEmpty()) return null

    if (bitmaps.size == 1) {
      return try {
        MediaStorePhotoSaver.saveBitmapToMediaStore(context, bitmaps[0], prefix = "LOWLT_")
      } finally {
        bitmaps.forEach { it.recycle() }
      }
    }

    val ref = bitmaps.first()
    val w = ref.width
    val h = ref.height
    val refPixels = IntArray(w * h)
    ref.getPixels(refPixels, 0, w, 0, 0, w, h)

    val rAccum = IntArray(w * h)
    val gAccum = IntArray(w * h)
    val bAccum = IntArray(w * h)
    val counts = IntArray(w * h)

    for (i in refPixels.indices) {
      val p = refPixels[i]
      rAccum[i] = (p ushr 16) and 0xFF
      gAccum[i] = (p ushr 8) and 0xFF
      bAccum[i] = p and 0xFF
      counts[i] = 1
    }

    val refLumaSmall = extractSmallLuma(refPixels, w, h, smallW = 120)
    val scaleX = w.toFloat() / 120f
    val sh = (h / scaleX).roundToInt().coerceAtLeast(24)

    for (frameIdx in 1 until bitmaps.size) {
      val bmp = bitmaps[frameIdx]
      if (bmp.width != w || bmp.height != h) continue
      val px = IntArray(w * h)
      bmp.getPixels(px, 0, w, 0, 0, w, h)

      val curSmall = extractSmallLuma(px, w, h, smallW = 120)
      val (dxSmall, dySmall) = findSmallTranslation(refLumaSmall, curSmall, 120, sh)
      val shiftX = (dxSmall * scaleX).roundToInt()
      val shiftY = (dySmall * scaleX).roundToInt()

      for (y in 0 until h) {
        val sy = y - shiftY
        if (sy !in 0 until h) continue
        val refOff = y * w
        val srcOff = sy * w
        for (x in 0 until w) {
          val sx = x - shiftX
          if (sx !in 0 until w) continue
          val p = px[srcOff + sx]
          rAccum[refOff + x] += (p ushr 16) and 0xFF
          gAccum[refOff + x] += (p ushr 8) and 0xFF
          bAccum[refOff + x] += p and 0xFF
          counts[refOff + x]++
        }
      }
    }

    val outPixels = IntArray(w * h)
    for (i in outPixels.indices) {
      val c = counts[i].coerceAtLeast(1)
      val r = (rAccum[i] / c).coerceIn(0, 255)
      val g = (gAccum[i] / c).coerceIn(0, 255)
      val b = (bAccum[i] / c).coerceIn(0, 255)
      outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    val outBitmap = Bitmap.createBitmap(outPixels, w, h, Bitmap.Config.ARGB_8888)
    return try {
      MediaStorePhotoSaver.saveBitmapToMediaStore(context, outBitmap, prefix = "LOWLT_")
    } finally {
      outBitmap.recycle()
      bitmaps.forEach { it.recycle() }
    }
  }

  private fun decodeOrientedBitmap(
    bytes: ByteArray,
    rotationDegrees: Int,
    mirrorHorizontal: Boolean,
  ): Bitmap? {
    val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
    if (rotationDegrees == 0 && !mirrorHorizontal) return raw
    val m = Matrix().apply {
      if (rotationDegrees != 0) postRotate(rotationDegrees.toFloat())
      if (mirrorHorizontal) postScale(-1f, 1f, raw.width / 2f, raw.height / 2f)
    }
    val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    if (rotated !== raw) raw.recycle()
    return rotated
  }

  private fun extractSmallLuma(pixels: IntArray, w: Int, h: Int, smallW: Int): FloatArray {
    val smallH = ((h * smallW).toFloat() / w.toFloat()).roundToInt().coerceAtLeast(24)
    val out = FloatArray(smallW * smallH)
    for (y in 0 until smallH) {
      val sy = ((y * h) / smallH).coerceIn(0, h - 1)
      val rowOff = sy * w
      val outOff = y * smallW
      for (x in 0 until smallW) {
        val sx = ((x * w) / smallW).coerceIn(0, w - 1)
        val p = pixels[rowOff + sx]
        out[outOff + x] =
          0.299f * ((p ushr 16) and 0xFF) +
            0.587f * ((p ushr 8) and 0xFF) +
            0.114f * (p and 0xFF)
      }
    }
    return out
  }

  private fun findSmallTranslation(
    refSmall: FloatArray,
    curSmall: FloatArray,
    sw: Int,
    sh: Int,
  ): Pair<Int, Int> {
    val px0 = sw / 4
    val py0 = sh / 4
    val pw = sw / 2
    val ph = sh / 2
    val maxShift = 8
    var bestDx = 0
    var bestDy = 0
    var bestScore = -1.0

    for (dy in -maxShift..maxShift) {
      for (dx in -maxShift..maxShift) {
        var sumA = 0.0
        var sumB = 0.0
        var n = 0
        for (y in py0 until (py0 + ph)) {
          val cy = y - dy
          if (cy !in 0 until sh) continue
          for (x in px0 until (px0 + pw)) {
            val cx = x - dx
            if (cx !in 0 until sw) continue
            sumA += refSmall[y * sw + x]
            sumB += curSmall[cy * sw + cx]
            n++
          }
        }
        if (n < 64) continue
        val mA = sumA / n
        val mB = sumB / n
        var num = 0.0
        var dA = 0.0
        var dB = 0.0
        for (y in py0 until (py0 + ph)) {
          val cy = y - dy
          if (cy !in 0 until sh) continue
          for (x in px0 until (px0 + pw)) {
            val cx = x - dx
            if (cx !in 0 until sw) continue
            val da = refSmall[y * sw + x] - mA
            val db = curSmall[cy * sw + cx] - mB
            num += da * db
            dA += da * da
            dB += db * db
          }
        }
        val denom = sqrt(dA * dB)
        val zncc = if (denom > 1e-5) num / denom else -1.0
        if (zncc > bestScore) {
          bestScore = zncc
          bestDx = dx
          bestDy = dy
        }
      }
    }
    return bestDx to bestDy
  }
}
