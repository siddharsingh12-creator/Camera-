package com.example.camera

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.media.MediaRecorder
import android.os.Build
import android.util.Range
import android.util.Size
import android.util.SizeF
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.lifecycle.ProcessCameraProvider
import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.roundToInt
import kotlin.math.tan

object DynamicCameraCapabilityManager {

  @OptIn(ExperimentalCamera2Interop::class)
  fun scanDeviceHardware(
    context: Context,
    cameraProvider: ProcessCameraProvider?,
  ): DeviceCameraInventory {
    return try {
      val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
      val cameraIdList = cameraManager.cameraIdList.toList()

      val cameraXInfosById = mutableMapOf<String, CameraInfo>()
      cameraProvider?.availableCameraInfos?.forEach { info ->
        val id =
          try {
            Camera2CameraInfo.from(info).cameraId
          } catch (_: Exception) {
            null
          }
        if (id != null) {
          cameraXInfosById[id] = info
        }
      }

      val topLevelProfiles = mutableListOf<CameraHardwareProfile>()
      val physicalProfilesById = linkedMapOf<String, CameraHardwareProfile>()

      // First pass: inspect all top-level camera IDs and any embedded physical sub-sensors
      for (cameraId in cameraIdList) {
        val chars = cameraManager.getCameraCharacteristics(cameraId)
        val isSelectable = cameraXInfosById.containsKey(cameraId)
        val cameraXInfo = cameraXInfosById[cameraId]
        val profile =
          buildRawProfile(
            cameraId = cameraId,
            chars = chars,
            cameraXInfo = cameraXInfo,
            isPhysicalOnlySensor = false,
            isCameraXSelectable = isSelectable,
            parentLogicalCameraId = null,
          )
        topLevelProfiles.add(profile)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
          val subIds =
            try {
              chars.physicalCameraIds
            } catch (_: Exception) {
              emptySet()
            }
          for (subId in subIds) {
            if (!physicalProfilesById.containsKey(subId)) {
              try {
                val subChars = cameraManager.getCameraCharacteristics(subId)
                val subSelectable = cameraXInfosById.containsKey(subId)
                val subProfile =
                  buildRawProfile(
                    cameraId = subId,
                    chars = subChars,
                    cameraXInfo = cameraXInfosById[subId],
                    isPhysicalOnlySensor = !cameraIdList.contains(subId),
                    isCameraXSelectable = subSelectable,
                    parentLogicalCameraId = cameraId,
                  )
                physicalProfilesById[subId] = subProfile
              } catch (_: Exception) {
                // Some OEMs list restricted physical IDs that cannot be queried directly
              }
            }
          }
        }
      }

      // Include standalone non-logical cameras in physical sensor catalog as well
      for (profile in topLevelProfiles) {
        if (!profile.isLogicalMultiCamera && !physicalProfilesById.containsKey(profile.cameraId)) {
          physicalProfilesById[profile.cameraId] = profile
        }
      }

      val allPhysicalList = physicalProfilesById.values.toList()

      // Classify roles cleanly using relative focal lengths across same-facing sensors
      val classifiedTopLevel = classifyRolesAndOpticalZoom(topLevelProfiles, physicalProfilesById)
      val classifiedPhysical = classifyRolesAndOpticalZoom(allPhysicalList, physicalProfilesById)

      val selectable =
        classifiedTopLevel
          .filter { it.isCameraXSelectable && it.isBackwardCompatible }
          .sortedWith(
            compareBy<CameraHardwareProfile>(
              {
                when (it.lensFacing) {
                  CameraMetadata.LENS_FACING_BACK -> 0
                  CameraMetadata.LENS_FACING_FRONT -> 1
                  else -> 2
                }
              },
              {
                when (it.role) {
                  CameraLensRole.WIDE -> 0
                  CameraLensRole.ULTRA_WIDE -> 1
                  CameraLensRole.TELEPHOTO -> 2
                  CameraLensRole.MACRO -> 3
                  CameraLensRole.FRONT -> 4
                  CameraLensRole.EXTERNAL -> 5
                  CameraLensRole.AUXILIARY -> 6
                }
              },
              { it.cameraId },
            )
          )

      val allDetected = (classifiedTopLevel + classifiedPhysical).distinctBy { it.cameraId }

      val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
      val hasLevelSensor =
        sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY) != null ||
          sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
      val hasMotionSensorForPanorama =
        sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null ||
          sensorManager?.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) != null ||
          sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null

      DeviceCameraInventory(
        allLogicalAndStandaloneCameras = classifiedTopLevel,
        allPhysicalSensors = classifiedPhysical,
        selectableCameras = selectable,
        backCameraCount =
          classifiedTopLevel.count {
            it.lensFacing == CameraMetadata.LENS_FACING_BACK && it.isBackwardCompatible
          },
        frontCameraCount =
          classifiedTopLevel.count {
            it.lensFacing == CameraMetadata.LENS_FACING_FRONT && it.isBackwardCompatible
          },
        externalCameraCount =
          classifiedTopLevel.count {
            it.lensFacing == CameraMetadata.LENS_FACING_EXTERNAL && it.isBackwardCompatible
          },
        hasUltraWide = allDetected.any { it.role == CameraLensRole.ULTRA_WIDE },
        hasTelephoto = allDetected.any { it.role == CameraLensRole.TELEPHOTO },
        hasMacro =
          allDetected.any {
            it.role == CameraLensRole.MACRO || it.focusCapabilities.isMacroFocusCapable
          },
        hasLevelSensor = hasLevelSensor,
        hasMotionSensorForPanorama = hasMotionSensorForPanorama,
        isInitialized = true,
        scanError = null,
      )
    } catch (e: Exception) {
      DeviceCameraInventory(
        isInitialized = true,
        scanError = e.localizedMessage ?: "Failed to inspect camera hardware.",
      )
    }
  }

  @OptIn(ExperimentalCamera2Interop::class)
  fun buildCameraSelectorForId(cameraId: String): CameraSelector {
    return CameraSelector.Builder()
      .addCameraFilter { cameraInfos ->
        val matched =
          cameraInfos.filter { info ->
            try {
              Camera2CameraInfo.from(info).cameraId == cameraId
            } catch (_: Exception) {
              false
            }
          }
        matched.ifEmpty { emptyList() }
      }
      .build()
  }

  private fun buildRawProfile(
    cameraId: String,
    chars: CameraCharacteristics,
    cameraXInfo: CameraInfo?,
    isPhysicalOnlySensor: Boolean,
    isCameraXSelectable: Boolean,
    parentLogicalCameraId: String?,
  ): CameraHardwareProfile {
    val capabilities =
      chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList().orEmpty()
    val isBackwardCompatible =
      capabilities.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)
    val isLogicalMultiCam =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        capabilities.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)
      } else {
        false
      }

    val physicalIds =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        try {
          chars.physicalCameraIds.toList().sorted()
        } catch (_: Exception) {
          emptyList()
        }
      } else {
        emptyList()
      }

    val lensFacing = chars.get(CameraCharacteristics.LENS_FACING) ?: CameraMetadata.LENS_FACING_BACK
    val facingLabel =
      when (lensFacing) {
        CameraMetadata.LENS_FACING_BACK -> "Rear"
        CameraMetadata.LENS_FACING_FRONT -> "Front"
        CameraMetadata.LENS_FACING_EXTERNAL -> "External"
        else -> "Unknown"
      }

    val hardwareLevel =
      when (chars.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> HardwareLevelLabel.LEGACY
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> HardwareLevelLabel.LIMITED
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> HardwareLevelLabel.FULL
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> HardwareLevelLabel.LEVEL_3
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> HardwareLevelLabel.EXTERNAL
        else -> HardwareLevelLabel.UNKNOWN
      }

    val focalLengths =
      chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.toList().orEmpty()
    val sensorSize: SizeF? = chars.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
    val primaryFocal = focalLengths.firstOrNull()
    val equiv35mm =
      if (primaryFocal != null && sensorSize != null && sensorSize.width > 0f) {
        primaryFocal * (36f / sensorSize.width)
      } else {
        null
      }
    val horizontalFovDeg =
      if (primaryFocal != null && primaryFocal > 0f && sensorSize != null && sensorSize.width > 0f) {
        (2.0 * atan((sensorSize.width / (2f * primaryFocal)).toDouble()) * (180.0 / PI)).toFloat()
      } else {
        null
      }
    val sensorSizeText =
      sensorSize?.let {
        "${String.format("%.2f", it.width)} × ${String.format("%.2f", it.height)} mm"
      }

    val apertures = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.toList().orEmpty()

    val maxDigitalZoom = chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
    val zoomRatioRange: ClosedFloatingPointRange<Float>? =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        chars.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let { range ->
          range.lower..range.upper
        }
      } else {
        null
      }

    val streamMap = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
    val jpegSizes =
      streamMap
        ?.getOutputSizes(ImageFormat.JPEG)
        ?.map { ResolutionSpec.fromSize(it) }
        ?.sortedByDescending { it.pixelCount }
        .orEmpty()
    val highResJpegSizes =
      streamMap
        ?.getHighResolutionOutputSizes(ImageFormat.JPEG)
        ?.map { ResolutionSpec.fromSize(it) }
        ?.sortedByDescending { it.pixelCount }
        .orEmpty()
    val allJpeg = (jpegSizes + highResJpegSizes).distinctBy { it.width to it.height }.sortedByDescending { it.pixelCount }
    val maxJpeg = allJpeg.firstOrNull()

    val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    val flashExplanation =
      if (hasFlash) "Hardware LED flash unit available"
      else "No hardware flash unit on this $facingLabel camera"

    // Focus capabilities
    val afModesRaw = chars.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.toList().orEmpty()
    val afModeLabels =
      afModesRaw
        .filter { it != CameraMetadata.CONTROL_AF_MODE_OFF }
        .map { mode ->
          when (mode) {
            CameraMetadata.CONTROL_AF_MODE_AUTO -> "AUTO"
            CameraMetadata.CONTROL_AF_MODE_MACRO -> "MACRO"
            CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO -> "CONTINUOUS_VIDEO"
            CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE -> "CONTINUOUS_PICTURE"
            CameraMetadata.CONTROL_AF_MODE_EDOF -> "EDOF"
            else -> "MODE_$mode"
          }
        }
    val hasAf = afModeLabels.isNotEmpty()
    val hasMacroAfMode = afModesRaw.contains(CameraMetadata.CONTROL_AF_MODE_MACRO)
    val minFocusDiopters = chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
    val minFocusCm = if (minFocusDiopters > 0f) 100f / minFocusDiopters else null
    val afOffSupported = afModesRaw.contains(CameraMetadata.CONTROL_AF_MODE_OFF)

    val sceneModesRaw =
      chars
        .get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)
        ?.toList()
        .orEmpty()
        .filter { it != CameraMetadata.CONTROL_SCENE_MODE_DISABLED }
    val supportsDepthOutput =
      capabilities.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT)
    val edgeModesRaw = chars.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)?.toList().orEmpty()
    val tonemapModesRaw =
      chars.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)?.toList().orEmpty()
    val supportsNaturalPipeline =
      hardwareLevel != HardwareLevelLabel.LEGACY &&
        edgeModesRaw.contains(CameraMetadata.EDGE_MODE_OFF) &&
        tonemapModesRaw.contains(CameraMetadata.TONEMAP_MODE_HIGH_QUALITY)
    val availableReqKeys =
      try {
        chars.availableCaptureRequestKeys.orEmpty()
      } catch (_: Exception) {
        emptyList()
      }
    val supportsFocusDistanceKey =
      availableReqKeys.isEmpty() || availableReqKeys.contains(CaptureRequest.LENS_FOCUS_DISTANCE)
    val supportsManualSensorKeys =
      availableReqKeys.isEmpty() ||
        (availableReqKeys.contains(CaptureRequest.SENSOR_SENSITIVITY) &&
          availableReqKeys.contains(CaptureRequest.SENSOR_EXPOSURE_TIME))

    val isManualFocusSupported =
      minFocusDiopters > 0f &&
        afOffSupported &&
        supportsFocusDistanceKey &&
        hardwareLevel != HardwareLevelLabel.LEGACY
    val calibrationLabel =
      when {
        minFocusDiopters <= 0f -> "Fixed Focus"
        else ->
          when (chars.get(CameraCharacteristics.LENS_INFO_FOCUS_DISTANCE_CALIBRATION)) {
            CameraMetadata.LENS_INFO_FOCUS_DISTANCE_CALIBRATION_CALIBRATED -> "Calibrated"
            CameraMetadata.LENS_INFO_FOCUS_DISTANCE_CALIBRATION_APPROXIMATE -> "Approximate"
            CameraMetadata.LENS_INFO_FOCUS_DISTANCE_CALIBRATION_UNCALIBRATED -> "Uncalibrated"
            else -> "Variable Focus"
          }
      }
    val unsupportedManualFocusReason =
      when {
        isManualFocusSupported -> null
        minFocusDiopters <= 0f -> "Unavailable: Fixed-focus lens (minimum focus distance = 0)"
        !afOffSupported -> "Unavailable: Hardware does not support AF_MODE_OFF"
        !supportsFocusDistanceKey -> "Unavailable: CaptureRequest.LENS_FOCUS_DISTANCE key missing"
        hardwareLevel == HardwareLevelLabel.LEGACY ->
          "Unavailable: LEGACY hardware level restricts manual focus distance"
        else -> "Unavailable: Manual focus unsupported on this sensor"
      }

    // Manual ISO & Shutter + White Balance + RAW capabilities
    val hasManualSensorCap =
      capabilities.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
    val hasManualPostProcCap =
      capabilities.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING)
    val aeModes = chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES)?.toList().orEmpty()
    val aeOffSupported = aeModes.contains(CameraMetadata.CONTROL_AE_MODE_OFF)
    val supportsLowLightBoostAe =
      Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM &&
        aeModes.contains(CameraMetadata.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY)
    val isAeLockSupported = chars.get(CameraCharacteristics.CONTROL_AE_LOCK_AVAILABLE) == true
    val isBurstSupported =
      capabilities.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BURST_CAPTURE) ||
        hardwareLevel == HardwareLevelLabel.FULL ||
        hardwareLevel == HardwareLevelLabel.LEVEL_3
    val isZslSupported =
      try {
        cameraXInfo?.isZslSupported == true
      } catch (_: Exception) {
        false
      }
    val isoRangeRaw: Range<Int>? = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
    val exposureRangeRaw: Range<Long>? =
      chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
    val isoRange = isoRangeRaw?.let { it.lower..it.upper }
    val shutterRange = exposureRangeRaw?.let { it.lower..it.upper }
    val isManualExposureSupported =
      hasManualSensorCap &&
        aeOffSupported &&
        supportsManualSensorKeys &&
        isoRange != null &&
        shutterRange != null
    val unsupportedManualExposureReason =
      when {
        isManualExposureSupported -> null
        !hasManualSensorCap ->
          "Unavailable: Sensor lacks MANUAL_SENSOR hardware capability (${hardwareLevel.displayName})"
        !aeOffSupported -> "Unavailable: Sensor does not support AE_MODE_OFF"
        !supportsManualSensorKeys ->
          "Unavailable: Sensor lacks SENSOR_SENSITIVITY / SENSOR_EXPOSURE_TIME request keys"
        isoRange == null || shutterRange == null ->
          "Unavailable: Sensor sensitivity or exposure time range unavailable"
        else -> "Unavailable: Manual exposure unsupported"
      }

    val evRangeRaw = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
    val evStep = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
    val evRange =
      if (evRangeRaw != null && evRangeRaw.lower < evRangeRaw.upper) {
        evRangeRaw.lower..evRangeRaw.upper
      } else {
        0..0
      }

    // White Balance modes + Manual Kelvin RGB Gain support
    val awbModesRaw = chars.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.toList().orEmpty()
    val awbOffSupported = awbModesRaw.contains(CameraMetadata.CONTROL_AWB_MODE_OFF)
    val supportsColorCorrectionKeys =
      availableReqKeys.isEmpty() ||
        (availableReqKeys.contains(CaptureRequest.COLOR_CORRECTION_MODE) &&
          availableReqKeys.contains(CaptureRequest.COLOR_CORRECTION_GAINS))
    val isManualKelvinSupported =
      hasManualPostProcCap &&
        awbOffSupported &&
        supportsColorCorrectionKeys &&
        hardwareLevel != HardwareLevelLabel.LEGACY

    val supportedAwbModes =
      buildList {
        awbModesRaw.forEach { mode ->
          WhiteBalanceOption.fromCamera2AwbMode(mode)?.let { add(it) }
        }
        if (none { it == WhiteBalanceOption.AUTO }) add(0, WhiteBalanceOption.AUTO)
        if (isManualKelvinSupported) add(WhiteBalanceOption.MANUAL_KELVIN)
      }.distinct()
    val unsupportedWbReason =
      when {
        supportedAwbModes.size <= 1 -> "Unavailable: Sensor only supports Auto White Balance"
        !isManualKelvinSupported ->
          "Kelvin dial unavailable (lacks MANUAL_POST_PROCESSING / COLOR_CORRECTION_GAINS)"
        else -> null
      }

    val hasRawCap = capabilities.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW)
    val rawSizes =
      streamMap
        ?.getOutputSizes(ImageFormat.RAW_SENSOR)
        ?.map { ResolutionSpec.fromSize(it) }
        ?.sortedByDescending { it.pixelCount }
        .orEmpty()
    var cameraXRawOnlySupported = false
    var cameraXRawJpegSupported = false
    if (cameraXInfo != null) {
      try {
        val imgCaps = ImageCapture.getImageCaptureCapabilities(cameraXInfo)
        val formats = imgCaps.supportedOutputFormats
        cameraXRawOnlySupported = formats.contains(ImageCapture.OUTPUT_FORMAT_RAW)
        cameraXRawJpegSupported = formats.contains(ImageCapture.OUTPUT_FORMAT_RAW_JPEG)
      } catch (_: Exception) {
        cameraXRawOnlySupported = false
        cameraXRawJpegSupported = false
      }
    }
    val isRawSupported = hasRawCap && rawSizes.isNotEmpty()
    val unsupportedRawReason =
      when {
        isRawSupported && (cameraXRawOnlySupported || cameraXRawJpegSupported) -> null
        isRawSupported ->
          "Hardware reports RAW_SENSOR, but CameraX RAW output is unavailable for this logical stream"
        else -> "Unavailable: Sensor lacks RAW_SENSOR (DNG) hardware capability"
      }

    // Frame rates, video sizes, and stabilization
    val fpsRanges =
      chars
        .get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
        ?.map { it.lower..it.upper }
        ?.distinct()
        ?.sortedWith(compareBy({ it.last }, { it.first }))
        .orEmpty()
    val highSpeedFps =
      try {
        streamMap
          ?.highSpeedVideoFpsRanges
          ?.map { it.lower..it.upper }
          ?.distinct()
          ?.sortedWith(compareBy({ it.last }, { it.first }))
          .orEmpty()
      } catch (_: Exception) {
        emptyList()
      }
    val videoSizes =
      streamMap
        ?.getOutputSizes(MediaRecorder::class.java)
        ?.map { ResolutionSpec.fromSize(it) }
        ?.distinctBy { it.width to it.height }
        ?.sortedByDescending { it.pixelCount }
        .orEmpty()

    val oisModes =
      chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.toList().orEmpty()
    val isOisSupported = oisModes.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)

    val eisModes =
      chars
        .get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
        ?.toList()
        .orEmpty()
    val isEisSupported = eisModes.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON)
    val isPreviewStabSupported =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        eisModes.contains(
          CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
        )
      } else {
        false
      }
    val unsupportedStabReason =
      if (!isOisSupported && !isEisSupported && !isPreviewStabSupported) {
        "Disabled: Neither OIS nor EIS hardware stabilization is supported on this sensor"
      } else {
        null
      }

    val capTags =
      capabilities.map { cap ->
        when (cap) {
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE -> "BACKWARD_COMPATIBLE"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR -> "MANUAL_SENSOR"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING -> "MANUAL_POST_PROC"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW -> "RAW"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_PRIVATE_REPROCESSING -> "ZSL_REPROCESSING"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_READ_SENSOR_SETTINGS -> "READ_SENSOR_SETTINGS"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BURST_CAPTURE -> "BURST_CAPTURE"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_YUV_REPROCESSING -> "YUV_REPROCESSING"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT -> "DEPTH_OUTPUT"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_CONSTRAINED_HIGH_SPEED_VIDEO ->
            "HIGH_SPEED_VIDEO"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA ->
            "LOGICAL_MULTI_CAMERA"
          CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MONOCHROME -> "MONOCHROME"
          else -> "CAP_$cap"
        }
      }

    val initialRole =
      when (lensFacing) {
        CameraMetadata.LENS_FACING_FRONT -> CameraLensRole.FRONT
        CameraMetadata.LENS_FACING_EXTERNAL -> CameraLensRole.EXTERNAL
        else -> if (isBackwardCompatible) CameraLensRole.WIDE else CameraLensRole.AUXILIARY
      }

    return CameraHardwareProfile(
      cameraId = cameraId,
      isLogicalMultiCamera = isLogicalMultiCam,
      isPhysicalOnlySensor = isPhysicalOnlySensor,
      isCameraXSelectable = isCameraXSelectable,
      parentLogicalCameraId = parentLogicalCameraId,
      physicalCameraIds = physicalIds,
      lensFacing = lensFacing,
      facingLabel = facingLabel,
      role = initialRole,
      hardwareLevel = hardwareLevel,
      isBackwardCompatible = isBackwardCompatible,
      isBurstSupported = isBurstSupported,
      isZslSupported = isZslSupported,
      supportedSceneModes = sceneModesRaw,
      hasMacroAfMode = hasMacroAfMode,
      supportsDepthOutput = supportsDepthOutput,
      supportsNaturalPipelineControls = supportsNaturalPipeline,
      supportsLowLightBoostAe = supportsLowLightBoostAe,
      focalLengthsMm = focalLengths,
      equivalent35mmFocalLength = equiv35mm,
      horizontalFovDegrees = horizontalFovDeg,
      sensorPhysicalSizeMm = sensorSizeText,
      apertures = apertures,
      maxDigitalZoom = maxDigitalZoom,
      controlZoomRatioRange = zoomRatioRange,
      hasOpticalZoom = focalLengths.size > 1,
      opticalZoomExplanation =
        if (focalLengths.size > 1) "Variable optical focal lengths supported"
        else "Fixed single focal length",
      opticalZoomStops = emptyList(),
      supportedJpegResolutions = allJpeg,
      highResJpegResolutions = highResJpegSizes,
      maxJpegResolution = maxJpeg,
      hasFlash = hasFlash,
      flashExplanation = flashExplanation,
      focusCapabilities =
        FocusCapabilities(
          isAutoFocusSupported = hasAf,
          afModes = afModeLabels,
          isManualFocusSupported = isManualFocusSupported,
          minimumFocusDistanceDiopters = minFocusDiopters,
          minimumFocusDistanceCm = minFocusCm,
          focusCalibrationLabel = calibrationLabel,
          isMacroFocusCapable = minFocusDiopters >= 10.0f,
          unsupportedManualReason = unsupportedManualFocusReason,
        ),
      exposureAndRaw =
        ExposureAndRawCapabilities(
          isManualExposureSupported = isManualExposureSupported,
          isAeLockSupported = isAeLockSupported,
          isoRange = isoRange,
          shutterRangeNs = shutterRange,
          exposureCompRange = evRange,
          exposureCompStep = evStep,
          supportedAwbModes = supportedAwbModes,
          isManualKelvinSupported = isManualKelvinSupported,
          unsupportedWhiteBalanceReason = unsupportedWbReason,
          isRawSupported = isRawSupported,
          isCameraXRawOnlySupported = cameraXRawOnlySupported,
          isCameraXRawJpegSupported = cameraXRawJpegSupported,
          rawOutputSizes = rawSizes,
          unsupportedManualReason = unsupportedManualExposureReason,
          unsupportedRawReason = unsupportedRawReason,
        ),
      videoAndStabilization =
        VideoAndStabilizationCapabilities(
          supportedFpsRanges = fpsRanges,
          highSpeedFpsRanges = highSpeedFps,
          supportedVideoSizes = videoSizes,
          isOisSupported = isOisSupported,
          isEisSupported = isEisSupported,
          isPreviewStabilizationSupported = isPreviewStabSupported,
          unsupportedStabilizationReason = unsupportedStabReason,
        ),
      capabilityTags = capTags,
    )
  }

  /**
   * Classifies Ultra-Wide, Telephoto, Macro, and Wide roles across rear sensors using actual
   * 35mm-equivalent focal length, horizontal FOV, and minimum focus distance, and derives real
   * optical zoom stops ONLY when backed by multiple physical sensors or optical focal lengths.
   */
  private fun classifyRolesAndOpticalZoom(
    profiles: List<CameraHardwareProfile>,
    physicalMap: Map<String, CameraHardwareProfile>,
  ): List<CameraHardwareProfile> {
    // Identify reference "1x" standard rear camera (backward compatible, ~21..35mm equiv or highest-res standard rear)
    val rearCandidates =
      profiles.filter {
        it.lensFacing == CameraMetadata.LENS_FACING_BACK && it.isBackwardCompatible
      } +
        physicalMap.values.filter {
          it.lensFacing == CameraMetadata.LENS_FACING_BACK && it.isBackwardCompatible
        }

    val referenceMain =
      rearCandidates
        .distinctBy { it.cameraId }
        .filter { p ->
          val eq = p.equivalent35mmFocalLength
          eq == null || eq in 21f..38f
        }
        .maxByOrNull { it.maxJpegResolution?.pixelCount ?: 0L }
        ?: rearCandidates.maxByOrNull { it.maxJpegResolution?.pixelCount ?: 0L }

    val refEqFocal = referenceMain?.equivalent35mmFocalLength
    val refFov = referenceMain?.horizontalFovDegrees

    fun classifySingleRole(p: CameraHardwareProfile): CameraLensRole {
      if (p.lensFacing == CameraMetadata.LENS_FACING_FRONT) return CameraLensRole.FRONT
      if (p.lensFacing == CameraMetadata.LENS_FACING_EXTERNAL) return CameraLensRole.EXTERNAL
      if (!p.isBackwardCompatible) return CameraLensRole.AUXILIARY
      if (p.isLogicalMultiCamera && p.physicalCameraIds.size > 1) return CameraLensRole.WIDE

      val eq = p.equivalent35mmFocalLength
      val fov = p.horizontalFovDegrees
      val minFocusD = p.focusCapabilities.minimumFocusDistanceDiopters
      val mp = p.maxJpegResolution?.megapixels ?: 0.0

      // Dedicated macro sensor check: close minimum focus distance (<= ~12.5cm) on a secondary
      // sensor that isn't an ultra-wide or telephoto lens
      val isLikelyDedicatedMacro =
        minFocusD >= 8.0f &&
          p.cameraId != referenceMain?.cameraId &&
          (eq == null || eq in 21f..44f) &&
          (mp in 0.5..8.5)
      if (isLikelyDedicatedMacro) return CameraLensRole.MACRO

      if ((eq != null && eq <= 20.5f) || (fov != null && fov >= 88f)) {
        return CameraLensRole.ULTRA_WIDE
      }
      if ((eq != null && eq >= 43f) || (fov != null && fov <= 42f)) {
        return CameraLensRole.TELEPHOTO
      }

      if (refEqFocal != null && eq != null && refEqFocal > 0f) {
        val ratio = eq / refEqFocal
        if (ratio <= 0.72f) return CameraLensRole.ULTRA_WIDE
        if (ratio >= 1.75f) return CameraLensRole.TELEPHOTO
      } else if (refFov != null && fov != null && fov > 0f) {
        val fovRatio = tan((refFov / 2.0) * PI / 180.0) / tan((fov / 2.0) * PI / 180.0)
        if (fovRatio <= 0.72) return CameraLensRole.ULTRA_WIDE
        if (fovRatio >= 1.75) return CameraLensRole.TELEPHOTO
      }

      return CameraLensRole.WIDE
    }

    return profiles.map { profile ->
      val role = classifySingleRole(profile)

      // Compute verified optical zoom stops ONLY from genuine multi-sensor or multi-focal hardware
      val stops = mutableListOf<OpticalZoomStop>()
      if (profile.isLogicalMultiCamera && profile.physicalCameraIds.size >= 2) {
        val subSensors =
          profile.physicalCameraIds
            .mapNotNull { physicalMap[it] }
            .filter { it.isBackwardCompatible }

        // Find the 1x primary sub-sensor inside this logical camera
        val primarySub =
          subSensors
            .filter { s ->
              val subRole = classifySingleRole(s)
              subRole == CameraLensRole.WIDE
            }
            .maxByOrNull { it.maxJpegResolution?.pixelCount ?: 0L }
            ?: subSensors.minByOrNull {
              kotlin.math.abs((it.equivalent35mmFocalLength ?: 26f) - 26f)
            }

        val primarySubEq = primarySub?.equivalent35mmFocalLength ?: refEqFocal
        val zoomRange = profile.controlZoomRatioRange

        subSensors.forEach { sub ->
          val subRole = classifySingleRole(sub)
          val subFocal = sub.focalLengthsMm.firstOrNull() ?: return@forEach
          val subEq = sub.equivalent35mmFocalLength
          val ratio =
            if (primarySubEq != null && subEq != null && primarySubEq > 0f) {
              subEq / primarySubEq
            } else if (sub.cameraId == primarySub?.cameraId) {
              1.0f
            } else {
              null
            }

          if (ratio != null) {
            val clampedOrValid =
              zoomRange == null || (ratio >= zoomRange.start - 0.05f && ratio <= zoomRange.endInclusive + 0.05f)
            if (clampedOrValid) {
              val rounded = ((ratio * 10f).roundToInt() / 10f)
              val label =
                if (rounded == rounded.toInt().toFloat()) "${rounded.toInt()}×"
                else String.format("%.1f×", rounded)
              stops.add(
                OpticalZoomStop(
                  label = label,
                  zoomRatio = ratio.coerceIn(
                    zoomRange?.start ?: ratio,
                    zoomRange?.endInclusive ?: ratio,
                  ),
                  targetCameraId = sub.cameraId,
                  focalLengthMm = subFocal,
                  equiv35mmFocal = subEq,
                  role = subRole,
                  isPhysicalSubSensor = true,
                )
              )
            }
          }
        }
      } else if (profile.focalLengthsMm.size > 1) {
        val baseFocal = profile.focalLengthsMm.minOrNull() ?: 1f
        profile.focalLengthsMm.sorted().forEach { fl ->
          val ratio = fl / baseFocal
          val rounded = ((ratio * 10f).roundToInt() / 10f)
          stops.add(
            OpticalZoomStop(
              label = "${String.format("%.1f", rounded)}×",
              zoomRatio = ratio,
              targetCameraId = profile.cameraId,
              focalLengthMm = fl,
              equiv35mmFocal = profile.equivalent35mmFocalLength?.let { it * ratio },
              role = role,
              isPhysicalSubSensor = false,
            )
          )
        }
      }

      val distinctStops = stops.distinctBy { it.label }.sortedBy { it.zoomRatio ?: 1f }
      val hasRealOpticalZoom = distinctStops.size >= 2
      val opticalZoomExplanation =
        when {
          profile.isLogicalMultiCamera && distinctStops.size >= 2 ->
            "Logical multi-camera array (${distinctStops.joinToString(" · ") { it.label }})"
          profile.focalLengthsMm.size > 1 ->
            "Variable optical focal lengths (${profile.focalLengthsMm.joinToString(", ") { "${it}mm" }})"
          else -> "Single fixed focal length — no optical zoom on this sensor"
        }

      profile.copy(
        role = role,
        hasOpticalZoom = hasRealOpticalZoom,
        opticalZoomExplanation = opticalZoomExplanation,
        opticalZoomStops = distinctStops,
      )
    }
  }
}
