package com.example.camera

import android.graphics.ImageFormat
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import kotlin.math.abs

/**
 * Real-time YUV_420_888 sensor frame analyzer providing:
 * 1. 48-bin Luminance & RGB live histogram + highlight/shadow clipping percentages.
 * 2. Zebra exposure warning coordinates for highlight/shadow clipping.
 * 3. Sobel-style spatial luminance gradient edge coordinates for Focus Peaking.
 */
class LiveFrameAnalyzer(
  private val isFrontCamera: () -> Boolean,
  private val isHistogramEnabled: () -> Boolean,
  private val isZebraEnabled: () -> Boolean,
  private val zebraThresholdPercent: () -> Int,
  private val isFocusPeakingEnabled: () -> Boolean,
  private val isAutoSceneEnabled: () -> Boolean = { false },
  private val onAnalysisReady: (FrameAnalysisData) -> Unit,
) : ImageAnalysis.Analyzer {

  private var lastAnalyzedNs = 0L
  private val minIntervalNs = 65_000_000L // ~15 fps cap for smooth low-overhead HUD updates

  override fun analyze(image: ImageProxy) {
    try {
      val histOn = isHistogramEnabled()
      val zebraOn = isZebraEnabled()
      val peakOn = isFocusPeakingEnabled()
      val autoSceneOn = isAutoSceneEnabled()
      if (!histOn && !zebraOn && !peakOn && !autoSceneOn) return

      val now = System.nanoTime()
      if (now - lastAnalyzedNs < minIntervalNs) return
      lastAnalyzedNs = now

      if (image.format != ImageFormat.YUV_420_888 || image.planes.size < 3) return

      val width = image.width
      val height = image.height
      if (width < 16 || height < 16) return

      val yPlane = image.planes[0]
      val uPlane = image.planes[1]
      val vPlane = image.planes[2]

      val yBuf = yPlane.buffer
      val uBuf = uPlane.buffer
      val vBuf = vPlane.buffer

      val yRowStride = yPlane.rowStride
      val yPixelStride = yPlane.pixelStride
      val uRowStride = uPlane.rowStride
      val uPixelStride = uPlane.pixelStride
      val vRowStride = vPlane.rowStride
      val vPixelStride = vPlane.pixelStride

      val gridCols = 72
      val gridRows = 54
      val stepX = (width / gridCols).coerceAtLeast(2)
      val stepY = (height / gridRows).coerceAtLeast(2)

      val lumaRaw = IntArray(48)
      val rRaw = IntArray(48)
      val gRaw = IntArray(48)
      val bRaw = IntArray(48)

      val thresholdIre = ((zebraThresholdPercent().coerceIn(75, 100) * 255) / 100)
      val shadowThreshold = 8

      val zebraHighList = ArrayList<Float>(512)
      val zebraShadowList = ArrayList<Float>(256)
      val peakList = ArrayList<Float>(1024)

      var totalSamples = 0
      var highlightClipped = 0
      var shadowClipped = 0
      var sumLuma = 0L
      var warmSampleCount = 0
      var chromaSampleCount = 0

      val rotation = image.imageInfo.rotationDegrees
      val mirrorX = isFrontCamera()
      val yLimit = yBuf.limit()
      val uLimit = uBuf.limit()
      val vLimit = vBuf.limit()

      var y = stepY
      while (y < height - stepY) {
        val uvRow = y shr 1
        var x = stepX
        while (x < width - stepX) {
          val yIdx = y * yRowStride + x * yPixelStride
          if (yIdx < yLimit) {
            val luma = yBuf.get(yIdx).toInt() and 0xFF
            totalSamples++
            sumLuma += luma

            if (luma >= thresholdIre) highlightClipped++
            if (luma <= shadowThreshold) shadowClipped++

            if (histOn || autoSceneOn) {
              val lBin = (luma * 47) / 255
              if (histOn) lumaRaw[lBin]++

              val uvCol = x shr 1
              val uIdx = uvRow * uRowStride + uvCol * uPixelStride
              val vIdx = uvRow * vRowStride + uvCol * vPixelStride
              if (uIdx < uLimit && vIdx < vLimit) {
                val uVal = (uBuf.get(uIdx).toInt() and 0xFF) - 128
                val vVal = (vBuf.get(vIdx).toInt() and 0xFF) - 128
                val r = (luma + ((1436 * vVal) shr 10)).coerceIn(0, 255)
                val g = (luma - ((352 * uVal + 731 * vVal) shr 10)).coerceIn(0, 255)
                val b = (luma + ((1815 * uVal) shr 10)).coerceIn(0, 255)
                if (histOn) {
                  rRaw[(r * 47) / 255]++
                  gRaw[(g * 47) / 255]++
                  bRaw[(b * 47) / 255]++
                }
                if (autoSceneOn) {
                  chromaSampleCount++
                  if (r > g + 10 && r > b + 20) warmSampleCount++
                }
              }
            }

            if (zebraOn && (luma >= thresholdIre || luma <= shadowThreshold)) {
              val uNorm = x.toFloat() / width.toFloat()
              val vNorm = y.toFloat() / height.toFloat()
              val (nx, ny) = transformNormalized(uNorm, vNorm, rotation, mirrorX)
              if (luma >= thresholdIre && zebraHighList.size < 3200) {
                zebraHighList.add(nx)
                zebraHighList.add(ny)
              } else if (luma <= shadowThreshold && zebraShadowList.size < 1600) {
                zebraShadowList.add(nx)
                zebraShadowList.add(ny)
              }
            }

            if (peakOn && peakList.size < 2400) {
              val xLeftIdx = y * yRowStride + (x - 2).coerceAtLeast(0) * yPixelStride
              val xRightIdx = y * yRowStride + (x + 2).coerceAtMost(width - 1) * yPixelStride
              val yUpIdx = (y - 2).coerceAtLeast(0) * yRowStride + x * yPixelStride
              val yDownIdx = (y + 2).coerceAtMost(height - 1) * yRowStride + x * yPixelStride

              if (xLeftIdx < yLimit && xRightIdx < yLimit && yUpIdx < yLimit && yDownIdx < yLimit) {
                val gx =
                  abs(
                    (yBuf.get(xRightIdx).toInt() and 0xFF) -
                      (yBuf.get(xLeftIdx).toInt() and 0xFF)
                  )
                val gy =
                  abs(
                    (yBuf.get(yDownIdx).toInt() and 0xFF) -
                      (yBuf.get(yUpIdx).toInt() and 0xFF)
                  )
                val grad = gx + gy
                if (grad >= 44) {
                  val uNorm = x.toFloat() / width.toFloat()
                  val vNorm = y.toFloat() / height.toFloat()
                  val (nx, ny) = transformNormalized(uNorm, vNorm, rotation, mirrorX)
                  peakList.add(nx)
                  peakList.add(ny)
                }
              }
            }
          }
          x += stepX
        }
        y += stepY
      }

      val lumaBins = normalizeHistogram(lumaRaw)
      val redBins = normalizeHistogram(rRaw)
      val greenBins = normalizeHistogram(gRaw)
      val blueBins = normalizeHistogram(bRaw)

      val hiPct =
        if (totalSamples > 0) (highlightClipped * 100f) / totalSamples.toFloat() else 0f
      val shPct =
        if (totalSamples > 0) (shadowClipped * 100f) / totalSamples.toFloat() else 0f
      val meanLumaNorm =
        if (totalSamples > 0) (sumLuma.toFloat() / (totalSamples * 255f)).coerceIn(0f, 1f) else 0.5f
      val isWarm = chromaSampleCount > 0 && warmSampleCount.toFloat() / chromaSampleCount.toFloat() > 0.24f

      onAnalysisReady(
        FrameAnalysisData(
          lumaBins = lumaBins,
          redBins = redBins,
          greenBins = greenBins,
          blueBins = blueBins,
          highlightClippedPercent = hiPct,
          shadowClippedPercent = shPct,
          focusPeakingPoints = peakList.toFloatArray(),
          zebraHighlightPoints = zebraHighList.toFloatArray(),
          zebraShadowPoints = zebraShadowList.toFloatArray(),
          meanLuma = meanLumaNorm,
          highlightShare = hiPct / 100f,
          shadowShare = shPct / 100f,
          isWarmScene = isWarm,
        )
      )
    } finally {
      image.close()
    }
  }

  private fun normalizeHistogram(raw: IntArray): FloatArray {
    var peak = 1
    for (v in raw) {
      if (v > peak) peak = v
    }
    val result = FloatArray(raw.size)
    val denom = peak.toFloat()
    for (i in raw.indices) {
      result[i] = (raw[i].toFloat() / denom).coerceIn(0f, 1f)
    }
    return result
  }

  private fun transformNormalized(
    u: Float,
    v: Float,
    rotationDegrees: Int,
    mirrorX: Boolean,
  ): Pair<Float, Float> {
    var nx: Float
    var ny: Float
    when (rotationDegrees) {
      90 -> {
        nx = 1f - v
        ny = u
      }
      180 -> {
        nx = 1f - u
        ny = 1f - v
      }
      270 -> {
        nx = v
        ny = 1f - u
      }
      else -> {
        nx = u
        ny = v
      }
    }
    if (mirrorX) {
      nx = 1f - nx
    }
    return nx.coerceIn(0f, 1f) to ny.coerceIn(0f, 1f)
  }
}
