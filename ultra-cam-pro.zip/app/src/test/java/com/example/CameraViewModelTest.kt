package com.example

import android.hardware.camera2.CameraMetadata
import android.util.Size
import com.example.camera.CameraHardwareProfile
import com.example.camera.CameraLensRole
import com.example.camera.CameraPermissionStatus
import com.example.camera.CameraViewModel
import com.example.camera.CaptureOutputFormat
import com.example.camera.CaptureSpeedMode
import com.example.camera.DeviceCameraInventory
import com.example.camera.ExposureAndRawCapabilities
import com.example.camera.FlashSetting
import com.example.camera.FocusCapabilities
import com.example.camera.FocusPeakingColor
import com.example.camera.FrameAnalysisData
import com.example.camera.HardwareLevelLabel
import com.example.camera.LensOption
import com.example.camera.LiveExposureTelemetry
import com.example.camera.PreviewAspectRatio
import com.example.camera.ProPreset
import com.example.camera.ProPresetsRepository
import com.example.camera.ResolutionSpec
import com.example.camera.SensorCapabilities
import com.example.camera.ShutterTimer
import com.example.camera.StabilizationSelection
import com.example.camera.VideoAndStabilizationCapabilities
import com.example.camera.WhiteBalanceOption
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CameraViewModelTest {

  private fun buildProfile(
    cameraId: String = "0",
    isManualExposureSupported: Boolean = false,
    isAeLockSupported: Boolean = false,
    isBurstSupported: Boolean = false,
    isRawSupported: Boolean = false,
    isCameraXRawOnlySupported: Boolean = isRawSupported,
    isManualFocusSupported: Boolean = false,
    supportedAwbModes: List<WhiteBalanceOption> = listOf(WhiteBalanceOption.AUTO),
    isManualKelvinSupported: Boolean = false,
  ): CameraHardwareProfile {
    return CameraHardwareProfile(
      cameraId = cameraId,
      isLogicalMultiCamera = false,
      isPhysicalOnlySensor = false,
      isCameraXSelectable = true,
      parentLogicalCameraId = null,
      physicalCameraIds = emptyList(),
      lensFacing = CameraMetadata.LENS_FACING_BACK,
      facingLabel = "Rear",
      role = CameraLensRole.WIDE,
      hardwareLevel =
        if (isManualExposureSupported) HardwareLevelLabel.FULL else HardwareLevelLabel.LIMITED,
      isBackwardCompatible = true,
      focalLengthsMm = listOf(4.71f),
      equivalent35mmFocalLength = 26f,
      horizontalFovDegrees = 70f,
      sensorPhysicalSizeMm = "6.40 × 4.80 mm",
      apertures = listOf(1.8f),
      maxDigitalZoom = 4.0f,
      controlZoomRatioRange = 1.0f..4.0f,
      hasOpticalZoom = false,
      opticalZoomExplanation = "Single fixed focal length — no optical zoom on this sensor",
      opticalZoomStops = emptyList(),
      supportedJpegResolutions = listOf(ResolutionSpec(4032, 3024)),
      highResJpegResolutions = emptyList(),
      maxJpegResolution = ResolutionSpec(4032, 3024),
      hasFlash = true,
      flashExplanation = "Hardware LED flash unit available",
      focusCapabilities =
        FocusCapabilities(
          isAutoFocusSupported = true,
          afModes = listOf("AUTO", "CONTINUOUS_PICTURE"),
          isManualFocusSupported = isManualFocusSupported,
          minimumFocusDistanceDiopters = if (isManualFocusSupported) 10f else 0f,
          unsupportedManualReason = if (isManualFocusSupported) null else "Disabled: Fixed-focus lens",
        ),
      exposureAndRaw =
        ExposureAndRawCapabilities(
          isManualExposureSupported = isManualExposureSupported,
          isoRange = if (isManualExposureSupported) 50..3200 else null,
          shutterRangeNs = if (isManualExposureSupported) 100_000L..1_000_000_000L else null,
          isAeLockSupported = isAeLockSupported,
          supportedAwbModes = supportedAwbModes,
          isManualKelvinSupported = isManualKelvinSupported,
          unsupportedWhiteBalanceReason =
            if (isManualKelvinSupported) null else "Custom Kelvin requires MANUAL_POST_PROCESSING",
          isRawSupported = isRawSupported,
          isCameraXRawOnlySupported = isCameraXRawOnlySupported,
          isCameraXRawJpegSupported = isRawSupported,
          unsupportedManualReason =
            if (isManualExposureSupported) null else "Disabled: Sensor lacks MANUAL_SENSOR",
          unsupportedRawReason =
            if (isRawSupported) null else "Disabled: Sensor lacks RAW_SENSOR",
        ),
      videoAndStabilization =
        VideoAndStabilizationCapabilities(
          isOisSupported = false,
          isEisSupported = false,
        ),
      isBurstSupported = isBurstSupported,
      isZslSupported = isBurstSupported,
      capabilityTags = listOf("BACKWARD_COMPATIBLE"),
    )
  }

  @Test
  fun `initial state does not bypass camera permission`() {
    val vm = CameraViewModel()
    assertEquals(CameraPermissionStatus.NOT_REQUESTED, vm.uiState.value.permissionStatus)
    assertEquals(LensOption.BACK, vm.uiState.value.lensOption)
    assertEquals(PreviewAspectRatio.RATIO_4_3, vm.uiState.value.aspectRatio)
    assertEquals(FlashSetting.OFF, vm.uiState.value.flashSetting)
    assertEquals(ShutterTimer.OFF, vm.uiState.value.shutterTimer)
    assertEquals(CaptureSpeedMode.MAX_QUALITY, vm.uiState.value.captureSpeedMode)
  }

  @Test
  fun `switchCamera toggles between rear and front only when available`() {
    val vm = CameraViewModel()
    vm.updateCameraAvailability(hasBack = true, hasFront = true)
    vm.switchCamera()
    assertEquals(LensOption.FRONT, vm.uiState.value.lensOption)
    vm.switchCamera()
    assertEquals(LensOption.BACK, vm.uiState.value.lensOption)

    vm.updateCameraAvailability(hasBack = true, hasFront = false)
    vm.switchCamera()
    assertEquals(LensOption.BACK, vm.uiState.value.lensOption)
  }

  @Test
  fun `flash cycles only when sensor supports flash`() {
    val vm = CameraViewModel()
    vm.updateSensorCapabilities(
      SensorCapabilities(
        maxSensorJpegSize = Size(4032, 3024),
        activeCaptureSize = Size(4032, 3024),
        hasFlash = true,
      )
    )
    vm.cycleFlashSetting()
    assertEquals(FlashSetting.AUTO, vm.uiState.value.flashSetting)
    vm.cycleFlashSetting()
    assertEquals(FlashSetting.ON, vm.uiState.value.flashSetting)
    vm.cycleFlashSetting()
    assertEquals(FlashSetting.OFF, vm.uiState.value.flashSetting)

    vm.cycleFlashSetting() // AUTO
    vm.updateSensorCapabilities(SensorCapabilities(hasFlash = false))
    assertEquals(FlashSetting.OFF, vm.uiState.value.flashSetting)
  }

  @Test
  fun `aspect ratios including 1_1 and grid controls update state cleanly`() {
    val vm = CameraViewModel()
    assertFalse(vm.uiState.value.isGridEnabled)
    vm.toggleGrid()
    assertTrue(vm.uiState.value.isGridEnabled)

    vm.selectAspectRatio(PreviewAspectRatio.RATIO_16_9)
    assertEquals(PreviewAspectRatio.RATIO_16_9, vm.uiState.value.aspectRatio)

    vm.selectAspectRatio(PreviewAspectRatio.RATIO_1_1)
    assertEquals(PreviewAspectRatio.RATIO_1_1, vm.uiState.value.aspectRatio)

    vm.selectAspectRatio(PreviewAspectRatio.FULL)
    assertEquals(PreviewAspectRatio.FULL, vm.uiState.value.aspectRatio)
  }

  @Test
  fun `shutter timer cycles 3s 5s 10s and off`() {
    val vm = CameraViewModel()
    assertEquals(ShutterTimer.OFF, vm.uiState.value.shutterTimer)
    vm.cycleShutterTimer()
    assertEquals(ShutterTimer.SEC_3, vm.uiState.value.shutterTimer)
    vm.cycleShutterTimer()
    assertEquals(ShutterTimer.SEC_5, vm.uiState.value.shutterTimer)
    vm.cycleShutterTimer()
    assertEquals(ShutterTimer.SEC_10, vm.uiState.value.shutterTimer)
    vm.cycleShutterTimer()
    assertEquals(ShutterTimer.OFF, vm.uiState.value.shutterTimer)
  }

  @Test
  fun `quick capture front mirror and volume shutter toggles work`() {
    val vm = CameraViewModel()
    assertEquals(CaptureSpeedMode.MAX_QUALITY, vm.uiState.value.captureSpeedMode)
    vm.toggleCaptureSpeedMode()
    assertEquals(CaptureSpeedMode.QUICK, vm.uiState.value.captureSpeedMode)
    vm.toggleCaptureSpeedMode()
    assertEquals(CaptureSpeedMode.MAX_QUALITY, vm.uiState.value.captureSpeedMode)

    assertTrue(vm.uiState.value.isFrontMirrorEnabled)
    vm.toggleFrontMirror()
    assertFalse(vm.uiState.value.isFrontMirrorEnabled)

    assertTrue(vm.uiState.value.isVolumeShutterEnabled)
    vm.toggleVolumeShutter()
    assertFalse(vm.uiState.value.isVolumeShutterEnabled)
  }

  @Test
  fun `volumeShutterEvents emits on triggerVolumeShutter`() = runBlocking {
    val vm = CameraViewModel()
    vm.triggerVolumeShutter()
    assertEquals(Unit, vm.volumeShutterEvents.first())
  }

  @Test
  fun `unsupported burst ae lock level and manual controls stay disabled`() {
    val vm = CameraViewModel()
    val basicBackProfile = buildProfile(cameraId = "0")

    vm.updateDeviceInventory(
      DeviceCameraInventory(
        allLogicalAndStandaloneCameras = listOf(basicBackProfile),
        allPhysicalSensors = listOf(basicBackProfile),
        selectableCameras = listOf(basicBackProfile),
        backCameraCount = 1,
        frontCameraCount = 0,
        hasLevelSensor = false,
        isInitialized = true,
      )
    )

    // Attempt to enable unsupported manual ISO, shutter, focus, RAW, OIS, burst, AE lock, level, WB, Kelvin
    vm.setManualIso(true, 800)
    vm.setManualShutter(true, 10_000_000L)
    vm.setManualFocus(true, 2.0f)
    vm.setWhiteBalance(WhiteBalanceOption.DAYLIGHT)
    vm.setManualKelvin(6200)
    vm.selectCaptureOutputFormat(CaptureOutputFormat.RAW_DNG)
    vm.selectCaptureOutputFormat(CaptureOutputFormat.RAW_PLUS_JPEG)
    vm.toggleRawCapture()
    vm.selectStabilization(StabilizationSelection.OIS)
    vm.toggleBurstMode()
    vm.toggleExposureLock()
    vm.toggleLevelIndicator()

    assertFalse(vm.uiState.value.manualSettings.isManualIsoEnabled)
    assertFalse(vm.uiState.value.manualSettings.isManualShutterEnabled)
    assertFalse(vm.uiState.value.manualSettings.isManualFocusEnabled)
    assertEquals(WhiteBalanceOption.AUTO, vm.uiState.value.manualSettings.whiteBalanceMode)
    assertEquals(CaptureOutputFormat.JPEG, vm.uiState.value.manualSettings.captureOutputFormat)
    assertFalse(vm.uiState.value.manualSettings.isRawCaptureEnabled)
    assertFalse(vm.uiState.value.manualSettings.isExposureLockEnabled)
    assertFalse(vm.uiState.value.isBurstModeEnabled)
    assertFalse(vm.uiState.value.isLevelEnabled)
    assertEquals(
      StabilizationSelection.AUTO,
      vm.uiState.value.manualSettings.stabilizationSelection,
    )
    assertTrue(vm.uiState.value.activeHardwareProfile?.opticalZoomStops?.isEmpty() == true)
  }

  @Test
  fun `supported burst ae lock white balance raw formats and level work properly`() {
    val vm = CameraViewModel()
    val fullBackProfile =
      buildProfile(
        cameraId = "0",
        isManualExposureSupported = true,
        isAeLockSupported = true,
        isBurstSupported = true,
        isRawSupported = true,
        isCameraXRawOnlySupported = true,
        isManualFocusSupported = true,
        supportedAwbModes =
          listOf(
            WhiteBalanceOption.AUTO,
            WhiteBalanceOption.DAYLIGHT,
            WhiteBalanceOption.INCANDESCENT,
          ),
        isManualKelvinSupported = true,
      )

    vm.updateDeviceInventory(
      DeviceCameraInventory(
        allLogicalAndStandaloneCameras = listOf(fullBackProfile),
        allPhysicalSensors = listOf(fullBackProfile),
        selectableCameras = listOf(fullBackProfile),
        backCameraCount = 1,
        frontCameraCount = 0,
        hasLevelSensor = true,
        isInitialized = true,
      )
    )

    vm.toggleLevelIndicator()
    assertTrue(vm.uiState.value.isLevelEnabled)

    vm.toggleBurstMode()
    assertTrue(vm.uiState.value.isBurstModeEnabled)

    // Selecting RAW_DNG automatically disables Burst mode
    vm.selectCaptureOutputFormat(CaptureOutputFormat.RAW_DNG)
    assertEquals(CaptureOutputFormat.RAW_DNG, vm.uiState.value.manualSettings.captureOutputFormat)
    assertTrue(vm.uiState.value.manualSettings.isRawCaptureEnabled)
    assertFalse(vm.uiState.value.isBurstModeEnabled)

    vm.selectCaptureOutputFormat(CaptureOutputFormat.RAW_PLUS_JPEG)
    assertEquals(
      CaptureOutputFormat.RAW_PLUS_JPEG,
      vm.uiState.value.manualSettings.captureOutputFormat,
    )

    // Unsupported AWB mode (SHADE wasn't in supportedAwbModes) stays unchanged
    vm.setWhiteBalance(WhiteBalanceOption.DAYLIGHT)
    assertEquals(WhiteBalanceOption.DAYLIGHT, vm.uiState.value.manualSettings.whiteBalanceMode)
    vm.setWhiteBalance(WhiteBalanceOption.SHADE)
    assertEquals(WhiteBalanceOption.DAYLIGHT, vm.uiState.value.manualSettings.whiteBalanceMode)

    vm.setManualKelvin(6800)
    assertEquals(WhiteBalanceOption.MANUAL_KELVIN, vm.uiState.value.manualSettings.whiteBalanceMode)
    assertEquals(6800, vm.uiState.value.manualSettings.manualKelvin)

    vm.toggleExposureLock()
    assertTrue(vm.uiState.value.manualSettings.isExposureLockEnabled)

    // Enabling Manual ISO releases AE Lock
    vm.setManualIso(true, 400)
    assertTrue(vm.uiState.value.manualSettings.isManualIsoEnabled)
    assertFalse(vm.uiState.value.manualSettings.isExposureLockEnabled)
  }

  @Test
  fun `focus peaking histogram and zebra toggles clear analysis when all disabled`() {
    val vm = CameraViewModel()
    vm.updateFrameAnalysis(FrameAnalysisData(highlightClippedPercent = 5.5f))
    assertTrue(vm.uiState.value.frameAnalysis != null)

    vm.toggleFocusPeaking()
    assertTrue(vm.uiState.value.manualSettings.isFocusPeakingEnabled)
    vm.cycleFocusPeakingColor()
    assertEquals(FocusPeakingColor.RED, vm.uiState.value.manualSettings.focusPeakingColor)

    vm.toggleHistogram()
    assertTrue(vm.uiState.value.manualSettings.isHistogramEnabled)

    vm.toggleZebraExposure()
    assertTrue(vm.uiState.value.manualSettings.isZebraEnabled)
    vm.setZebraThreshold(88)
    assertEquals(88, vm.uiState.value.manualSettings.zebraThresholdPercent)

    // Turning off two keeps analysis alive
    vm.toggleFocusPeaking()
    vm.toggleHistogram()
    assertTrue(vm.uiState.value.frameAnalysis != null)

    // Turning off the last analyzer clears cached frameAnalysis
    vm.toggleZebraExposure()
    assertNull(vm.uiState.value.frameAnalysis)
  }

  @Test
  fun `pro presets encode decode roundtrip and applyCustomPreset clamps to hardware`() {
    val preset =
      ProPreset(
        id = "p_night",
        name = "Night Long",
        isManualIsoEnabled = true,
        manualIso = 12800, // exceeds 3200 sensor max
        isManualShutterEnabled = true,
        manualShutterNs = 250_000_000L,
        whiteBalanceMode = WhiteBalanceOption.MANUAL_KELVIN,
        manualKelvin = 4200,
        isManualFocusEnabled = true,
        manualFocusDiopters = 1.5f,
        exposureCompIndex = 2,
        captureOutputFormat = CaptureOutputFormat.RAW_PLUS_JPEG,
        isFocusPeakingEnabled = true,
        isHistogramEnabled = true,
        isZebraEnabled = true,
      )

    val encoded = ProPresetsRepository.encodePresets(listOf(preset))
    val decoded = ProPresetsRepository.decodePresets(encoded)
    assertEquals(1, decoded.size)
    assertEquals(preset.name, decoded[0].name)
    assertEquals(12800, decoded[0].manualIso)
    assertEquals(CaptureOutputFormat.RAW_PLUS_JPEG, decoded[0].captureOutputFormat)

    val vm = CameraViewModel()
    val fullProfile =
      buildProfile(
        cameraId = "0",
        isManualExposureSupported = true,
        isRawSupported = true,
        isManualFocusSupported = true,
        isManualKelvinSupported = true,
      )
    vm.updateDeviceInventory(
      DeviceCameraInventory(
        allLogicalAndStandaloneCameras = listOf(fullProfile),
        allPhysicalSensors = listOf(fullProfile),
        selectableCameras = listOf(fullProfile),
        backCameraCount = 1,
        isInitialized = true,
      )
    )
    vm.updateSensorCapabilities(SensorCapabilities(exposureRange = -6..6))

    var appliedEv = 0
    vm.applyCustomPreset(decoded[0]) { appliedEv = it }

    assertEquals(2, appliedEv)
    assertTrue(vm.uiState.value.manualSettings.isManualIsoEnabled)
    assertEquals(3200, vm.uiState.value.manualSettings.manualIso) // clamped to max
    assertEquals(250_000_000L, vm.uiState.value.manualSettings.manualShutterNs)
    assertTrue(vm.uiState.value.manualSettings.isFocusPeakingEnabled)
    assertTrue(vm.uiState.value.manualSettings.isHistogramEnabled)
    assertTrue(vm.uiState.value.manualSettings.isZebraEnabled)

    vm.updateLiveTelemetry(LiveExposureTelemetry(iso = 200, shutterNs = 10_000_000L, aperture = 1.8f))
    assertEquals(200, vm.uiState.value.liveTelemetry.iso)

    vm.resetAllProToAuto { appliedEv = it }
    assertEquals(0, appliedEv)
    assertFalse(vm.uiState.value.manualSettings.isManualIsoEnabled)
    assertFalse(vm.uiState.value.manualSettings.isManualShutterEnabled)
    assertFalse(vm.uiState.value.manualSettings.isManualFocusEnabled)
    assertEquals(WhiteBalanceOption.AUTO, vm.uiState.value.manualSettings.whiteBalanceMode)
    assertEquals(CaptureOutputFormat.JPEG, vm.uiState.value.manualSettings.captureOutputFormat)
  }
}
