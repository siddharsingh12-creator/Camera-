package com.example

import android.hardware.camera2.CameraMetadata
import com.example.camera.CameraHardwareProfile
import com.example.camera.CameraLensRole
import com.example.camera.CameraViewModel
import com.example.camera.DetectedSceneType
import com.example.camera.DeviceCameraInventory
import com.example.camera.ExposureAndRawCapabilities
import com.example.camera.FocusCapabilities
import com.example.camera.FrameAnalysisData
import com.example.camera.HardwareLevelLabel
import com.example.camera.LiveExposureTelemetry
import com.example.camera.PanoramaStitcher
import com.example.camera.PhotographyMode
import com.example.camera.PhotographyModeManager
import com.example.camera.ResolutionSpec
import com.example.camera.VideoAndStabilizationCapabilities
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class PanoramaAndModesTest {

  private fun sampleScenePixel(x: Int, y: Int): Int {
    val r =
      (120 + 55 * sin(x * 0.081 + y * 0.029) + 35 * sin(x * 0.23 - y * 0.14))
        .roundToInt()
        .coerceIn(0, 255)
    val g =
      (125 + 50 * sin(x * 0.064 - y * 0.047) + 35 * sin(x * 0.19 + y * 0.17))
        .roundToInt()
        .coerceIn(0, 255)
    val b =
      (115 + 55 * sin(x * 0.095 + y * 0.052) + 30 * sin(x * 0.16 - y * 0.21))
        .roundToInt()
        .coerceIn(0, 255)
    return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
  }

  private fun cropSyntheticSlice(
    offsetX: Int,
    offsetY: Int,
    width: Int,
    height: Int,
    gain: Float = 1f,
  ): PanoramaStitcher.PixelFrame {
    val px = IntArray(width * height)
    for (y in 0 until height) {
      for (x in 0 until width) {
        val p = sampleScenePixel(offsetX + x, offsetY + y)
        val r = (((p ushr 16) and 0xFF) * gain).roundToInt().coerceIn(0, 255)
        val g = (((p ushr 8) and 0xFF) * gain).roundToInt().coerceIn(0, 255)
        val b = ((p and 0xFF) * gain).roundToInt().coerceIn(0, 255)
        px[y * width + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
      }
    }
    return PanoramaStitcher.PixelFrame(width = width, height = height, pixels = px)
  }

  private fun makeSensorProfile(
    cameraId: String = "0",
    facing: Int = CameraMetadata.LENS_FACING_BACK,
    role: CameraLensRole = CameraLensRole.WIDE,
    maxMpWidth: Int = 4032,
    maxMpHeight: Int = 3024,
    highResList: List<ResolutionSpec> = emptyList(),
    sceneModes: List<Int> = emptyList(),
    hasMacroAfMode: Boolean = false,
    minFocusDiopters: Float = 4.0f,
    supportsDepth: Boolean = false,
    supportsNaturalIsp: Boolean = true,
    supportsLowLightAe: Boolean = false,
    isManualExposure: Boolean = false,
    maxShutterNs: Long = 100_000_000L,
  ): CameraHardwareProfile {
    return CameraHardwareProfile(
      cameraId = cameraId,
      isLogicalMultiCamera = false,
      isPhysicalOnlySensor = false,
      isCameraXSelectable = true,
      parentLogicalCameraId = null,
      physicalCameraIds = emptyList(),
      lensFacing = facing,
      facingLabel = if (facing == CameraMetadata.LENS_FACING_FRONT) "Front" else "Rear",
      role = role,
      hardwareLevel =
        if (supportsNaturalIsp) HardwareLevelLabel.FULL else HardwareLevelLabel.LEGACY,
      isBackwardCompatible = true,
      supportedSceneModes = sceneModes,
      hasMacroAfMode = hasMacroAfMode,
      supportsDepthOutput = supportsDepth,
      supportsNaturalPipelineControls = supportsNaturalIsp,
      supportsLowLightBoostAe = supportsLowLightAe,
      focalLengthsMm = listOf(4.71f),
      equivalent35mmFocalLength = 26f,
      horizontalFovDegrees = 70f,
      sensorPhysicalSizeMm = "6.40 × 4.80 mm",
      apertures = listOf(1.8f),
      maxDigitalZoom = 4f,
      controlZoomRatioRange = 1f..4f,
      hasOpticalZoom = false,
      opticalZoomExplanation = "Fixed focal length",
      opticalZoomStops = emptyList(),
      supportedJpegResolutions = listOf(ResolutionSpec(maxMpWidth, maxMpHeight)),
      highResJpegResolutions = highResList,
      maxJpegResolution = ResolutionSpec(maxMpWidth, maxMpHeight),
      hasFlash = facing != CameraMetadata.LENS_FACING_FRONT,
      flashExplanation = "LED",
      focusCapabilities =
        FocusCapabilities(
          isAutoFocusSupported = true,
          isManualFocusSupported = minFocusDiopters > 0f,
          minimumFocusDistanceDiopters = minFocusDiopters,
          minimumFocusDistanceCm = if (minFocusDiopters > 0f) 100f / minFocusDiopters else null,
        ),
      exposureAndRaw =
        ExposureAndRawCapabilities(
          isManualExposureSupported = isManualExposure,
          isoRange = if (isManualExposure) 50..3200 else null,
          shutterRangeNs = if (isManualExposure) 100_000L..maxShutterNs else null,
        ),
      videoAndStabilization = VideoAndStabilizationCapabilities(),
      capabilityTags = listOf("BACKWARD_COMPATIBLE"),
    )
  }

  @Test
  fun `panorama stitcher recovers exact displacement and blends multi-frame sweep cleanly`() {
    val sliceW = 240
    val sliceH = 160
    val f0 = cropSyntheticSlice(offsetX = 0, offsetY = 20, width = sliceW, height = sliceH)
    val f1 = cropSyntheticSlice(offsetX = 108, offsetY = 24, width = sliceW, height = sliceH, gain = 1.05f)
    val f2 = cropSyntheticSlice(offsetX = 212, offsetY = 22, width = sliceW, height = sliceH, gain = 0.96f)

    val align01 = PanoramaStitcher.estimatePairwiseAlignment(f0, f1)
    assertNotNull(align01)
    assertTrue("Expected dx near 108, got ${align01!!.dx}", abs(align01.dx - 108) <= 3)
    assertTrue("Expected dy near 4, got ${align01.dy}", abs(align01.dy - 4) <= 3)
    assertTrue("Expected high ZNCC score, got ${align01.correlationScore}", align01.correlationScore > 0.85)

    val stitchedPair = PanoramaStitcher.stitchFrames(listOf(f0, f1, f2))
    assertNotNull(stitchedPair)
    val (stitchedFrame, usedCount) = stitchedPair!!
    assertEquals(3, usedCount)
    assertTrue(
      "Expected stitched width near 452, got ${stitchedFrame.width}",
      abs(stitchedFrame.width - 452) <= 6,
    )
    assertTrue(
      "Expected cropped intersection height near 156, got ${stitchedFrame.height}",
      stitchedFrame.height in 150..160,
    )
  }

  @Test
  fun `panorama stitcher rejects completely non-overlapping flat frames`() {
    val flat = PanoramaStitcher.PixelFrame(200, 140, IntArray(200 * 140) { 0xFF808080.toInt() })
    val flat2 = PanoramaStitcher.PixelFrame(200, 140, IntArray(200 * 140) { 0xFF808080.toInt() })
    assertNull(PanoramaStitcher.estimatePairwiseAlignment(flat, flat2))
    assertNull(PanoramaStitcher.stitchFrames(listOf(flat, flat2)))
  }

  @Test
  fun `unsupported modes remain blocked when hardware lacks required capabilities`() {
    val restricted =
      makeSensorProfile(
        cameraId = "0",
        maxMpWidth = 3264,
        maxMpHeight = 2448,
        sceneModes = emptyList(),
        hasMacroAfMode = false,
        minFocusDiopters = 2.0f,
        supportsDepth = false,
        supportsNaturalIsp = false,
        supportsLowLightAe = false,
        isManualExposure = false,
      )
    val inventory =
      DeviceCameraInventory(
        allLogicalAndStandaloneCameras = listOf(restricted),
        allPhysicalSensors = listOf(restricted),
        selectableCameras = listOf(restricted),
        backCameraCount = 1,
        hasMotionSensorForPanorama = false,
        isInitialized = true,
      )

    val modeCaps =
      PhotographyModeManager.evaluateModeCapabilities(
        profile = restricted,
        inventory = inventory,
        selector = null,
        cameraInfo = null,
        extensionsManager = null,
      )

    assertTrue(modeCaps.availabilityOf(PhotographyMode.STANDARD).isSupported)
    assertTrue(modeCaps.availabilityOf(PhotographyMode.PORTRAIT).isSupported)

    assertFalse(modeCaps.availabilityOf(PhotographyMode.HDR).isSupported)
    assertFalse(modeCaps.availabilityOf(PhotographyMode.NIGHT).isSupported)
    assertFalse(modeCaps.availabilityOf(PhotographyMode.MACRO).isSupported)
    assertFalse(modeCaps.availabilityOf(PhotographyMode.HIGH_RES).isSupported)
    assertFalse(modeCaps.availabilityOf(PhotographyMode.PANORAMA).isSupported)
    assertFalse(modeCaps.availabilityOf(PhotographyMode.LOW_LIGHT).isSupported)
    assertFalse(modeCaps.availabilityOf(PhotographyMode.AUTO_SCENE).isSupported)
    assertFalse(modeCaps.availabilityOf(PhotographyMode.NATURAL_COLOR).isSupported)

    val vm = CameraViewModel()
    vm.updateDeviceInventory(inventory)
    vm.updateModeCapabilities(modeCaps)

    listOf(
      PhotographyMode.HDR,
      PhotographyMode.NIGHT,
      PhotographyMode.MACRO,
      PhotographyMode.HIGH_RES,
      PhotographyMode.PANORAMA,
      PhotographyMode.LOW_LIGHT,
      PhotographyMode.AUTO_SCENE,
      PhotographyMode.NATURAL_COLOR,
    ).forEach { blockedMode ->
      vm.selectPhotographyMode(blockedMode)
      assertEquals(
        "Blocked mode $blockedMode must not become active",
        PhotographyMode.STANDARD,
        vm.uiState.value.photographyMode,
      )
      assertNotNull(vm.uiState.value.statusBanner)
    }
  }

  @Test
  fun `supported modes enable cleanly and macro mode switches to dedicated macro sensor`() {
    val mainWide =
      makeSensorProfile(
        cameraId = "0",
        role = CameraLensRole.WIDE,
        maxMpWidth = 8000,
        maxMpHeight = 6000,
        sceneModes =
          listOf(
            CameraMetadata.CONTROL_SCENE_MODE_HDR,
            CameraMetadata.CONTROL_SCENE_MODE_NIGHT,
            CameraMetadata.CONTROL_SCENE_MODE_LANDSCAPE,
          ),
        supportsNaturalIsp = true,
        supportsLowLightAe = true,
        isManualExposure = true,
        maxShutterNs = 500_000_000L,
      )
    val dedicatedMacro =
      makeSensorProfile(
        cameraId = "3",
        role = CameraLensRole.MACRO,
        maxMpWidth = 1600,
        maxMpHeight = 1200,
        sceneModes = emptyList(),
        hasMacroAfMode = true,
        minFocusDiopters = 25f,
        supportsNaturalIsp = false,
        isManualExposure = false,
      )
    val inventory =
      DeviceCameraInventory(
        allLogicalAndStandaloneCameras = listOf(mainWide, dedicatedMacro),
        allPhysicalSensors = listOf(mainWide, dedicatedMacro),
        selectableCameras = listOf(mainWide, dedicatedMacro),
        backCameraCount = 2,
        hasMacro = true,
        hasMotionSensorForPanorama = true,
        isInitialized = true,
      )

    val mainCaps =
      PhotographyModeManager.evaluateModeCapabilities(
        profile = mainWide,
        inventory = inventory,
        selector = null,
        cameraInfo = null,
        extensionsManager = null,
      )

    assertEquals("3", mainCaps.bestMacroCameraId)
    assertTrue(mainCaps.availabilityOf(PhotographyMode.HDR).isSupported)
    assertTrue(mainCaps.availabilityOf(PhotographyMode.NIGHT).isSupported)
    assertTrue(mainCaps.availabilityOf(PhotographyMode.MACRO).isSupported)
    assertTrue(mainCaps.availabilityOf(PhotographyMode.HIGH_RES).isSupported)
    assertTrue(mainCaps.availabilityOf(PhotographyMode.PANORAMA).isSupported)
    assertTrue(mainCaps.availabilityOf(PhotographyMode.LOW_LIGHT).isSupported)
    assertTrue(mainCaps.availabilityOf(PhotographyMode.AUTO_SCENE).isSupported)
    assertTrue(mainCaps.availabilityOf(PhotographyMode.NATURAL_COLOR).isSupported)

    val vm = CameraViewModel()
    vm.updateDeviceInventory(inventory)
    vm.updateModeCapabilities(mainCaps)

    vm.selectPhotographyMode(PhotographyMode.MACRO)
    assertEquals(PhotographyMode.MACRO, vm.uiState.value.photographyMode)
    assertEquals("3", vm.uiState.value.activeCameraId)

    vm.selectSpecificCamera("0")
    vm.updateModeCapabilities(mainCaps)
    vm.selectPhotographyMode(PhotographyMode.HIGH_RES)
    assertEquals(PhotographyMode.HIGH_RES, vm.uiState.value.photographyMode)

    val limitedCaps =
      PhotographyModeManager.evaluateModeCapabilities(
        profile = dedicatedMacro,
        inventory = inventory,
        selector = null,
        cameraInfo = null,
        extensionsManager = null,
      )
    vm.updateModeCapabilities(limitedCaps)
    assertEquals(PhotographyMode.STANDARD, vm.uiState.value.photographyMode)
  }

  @Test
  fun `auto scene classifier maps telemetry to accurate scene types`() {
    assertEquals(
      DetectedSceneType.MACRO,
      PhotographyModeManager.classifyLiveScene(
        FrameAnalysisData(meanLuma = 0.5f),
        LiveExposureTelemetry(focusDistanceDiopters = 8.0f),
      ),
    )
    assertEquals(
      DetectedSceneType.LOW_LIGHT,
      PhotographyModeManager.classifyLiveScene(
        FrameAnalysisData(meanLuma = 0.14f),
        LiveExposureTelemetry(iso = 1600),
      ),
    )
    assertEquals(
      DetectedSceneType.HIGH_CONTRAST,
      PhotographyModeManager.classifyLiveScene(
        FrameAnalysisData(meanLuma = 0.45f, highlightShare = 0.08f, shadowShare = 0.12f),
        LiveExposureTelemetry(iso = 100),
      ),
    )
    assertEquals(
      DetectedSceneType.PORTRAIT,
      PhotographyModeManager.classifyLiveScene(
        FrameAnalysisData(meanLuma = 0.50f, isWarmScene = true),
        LiveExposureTelemetry(iso = 100),
      ),
    )
    assertEquals(
      DetectedSceneType.LANDSCAPE,
      PhotographyModeManager.classifyLiveScene(
        FrameAnalysisData(meanLuma = 0.55f, shadowShare = 0.02f, isWarmScene = false),
        LiveExposureTelemetry(iso = 100),
      ),
    )
  }
}
