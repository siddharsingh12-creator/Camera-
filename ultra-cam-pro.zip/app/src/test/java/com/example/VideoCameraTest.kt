package com.example

import android.util.Range
import android.util.Size
import androidx.camera.core.DynamicRange
import androidx.camera.video.Quality
import com.example.camera.AppCaptureDomain
import com.example.camera.AudioPermissionStatus
import com.example.camera.CameraViewModel
import com.example.camera.MediaStoreVideoSaver
import com.example.camera.StabilizationSelection
import com.example.camera.VideoBitrateOption
import com.example.camera.VideoCapabilityManager
import com.example.camera.VideoFpsOption
import com.example.camera.VideoQualityOption
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class VideoCameraTest {

  @Test
  fun `capability manager blocks 4k 2k high fps and hdr when hardware lacks support`() {
    val caps =
      VideoCapabilityManager.evaluateCapabilitiesCore(
        cameraId = "0",
        supportedCameraXQualities = listOf(Quality.FHD, Quality.HD, Quality.SD),
        resolvedQualitySizes =
          mapOf(
            Quality.FHD to Size(1920, 1080),
            Quality.HD to Size(1280, 720),
            Quality.SD to Size(720, 480),
          ),
        hdrSupportedQualities = emptyList(),
        preferredHdrRange = null,
        hasHardwareQhdProfile = false,
        selectedQuality = VideoQualityOption.FHD_1080P,
        standardFpsRanges = listOf(Range(15, 30), Range(30, 30)),
        highSpeedQualities = emptyList(),
        highSpeedFpsRanges = emptyList(),
        minFrameDurationBySizeNs = mapOf(Size(1920, 1080) to 33_333_333L),
        isCameraXStabilizationSupported = false,
        isOisSupported = false,
        isEisSupported = false,
        maxEncoderBitrateBps = 25_000_000,
      )

    assertTrue(caps.availabilityOf(VideoQualityOption.FHD_1080P).isSupported)
    assertTrue(caps.availabilityOf(VideoQualityOption.HD_720P).isSupported)
    assertTrue(caps.availabilityOf(VideoQualityOption.SD_480P).isSupported)
    assertFalse(caps.availabilityOf(VideoQualityOption.QHD_2K).isSupported)
    assertFalse(caps.availabilityOf(VideoQualityOption.UHD_4K).isSupported)

    assertFalse(caps.availabilityOf(VideoFpsOption.FPS_24).isSupported)
    assertTrue(caps.availabilityOf(VideoFpsOption.FPS_30).isSupported)
    assertFalse(caps.availabilityOf(VideoFpsOption.FPS_60).isSupported)
    assertFalse(caps.availabilityOf(VideoFpsOption.FPS_120).isSupported)
    assertFalse(caps.availabilityOf(VideoFpsOption.FPS_240).isSupported)

    assertFalse(caps.hdrAvailability.isSupported)
    assertFalse(caps.isOisSupported)
    assertFalse(caps.isEisSupported)
    assertFalse(caps.isVideoStabilizationSupported)
    assertTrue(caps.isBitrateSupported(VideoBitrateOption.MBPS_20))
    assertFalse(caps.isBitrateSupported(VideoBitrateOption.MBPS_50))
  }

  @Test
  fun `capability manager rejects misreported 4k stream and enforces per-resolution minFrameDuration`() {
    // 1. Even if Quality.UHD appears in list, if resolved size < 2000p it must not be marked 4K
    val misreported4k =
      VideoCapabilityManager.evaluateCapabilitiesCore(
        cameraId = "0",
        supportedCameraXQualities = listOf(Quality.UHD, Quality.FHD),
        resolvedQualitySizes =
          mapOf(
            Quality.UHD to Size(1920, 1080),
            Quality.FHD to Size(1920, 1080),
          ),
        hdrSupportedQualities = emptyList(),
        preferredHdrRange = null,
        hasHardwareQhdProfile = false,
        selectedQuality = VideoQualityOption.FHD_1080P,
        standardFpsRanges = listOf(Range(30, 30)),
        highSpeedQualities = emptyList(),
        highSpeedFpsRanges = emptyList(),
        minFrameDurationBySizeNs = emptyMap(),
        isCameraXStabilizationSupported = true,
        isOisSupported = true,
        isEisSupported = false,
        maxEncoderBitrateBps = 50_000_000,
      )
    assertFalse(misreported4k.availabilityOf(VideoQualityOption.UHD_4K).isSupported)

    // 2. Real 4K stream whose sensor readout duration caps at 30fps must block 60fps at 4K
    val size4k = Size(3840, 2160)
    val size1080p = Size(1920, 1080)
    val caps4kSelected =
      VideoCapabilityManager.evaluateCapabilitiesCore(
        cameraId = "0",
        supportedCameraXQualities = listOf(Quality.UHD, Quality.FHD, Quality.HD),
        resolvedQualitySizes = mapOf(Quality.UHD to size4k, Quality.FHD to size1080p),
        hdrSupportedQualities = listOf(Quality.UHD, Quality.FHD),
        preferredHdrRange = DynamicRange.HLG_10_BIT,
        hasHardwareQhdProfile = false,
        selectedQuality = VideoQualityOption.UHD_4K,
        standardFpsRanges = listOf(Range(24, 24), Range(30, 30), Range(60, 60)),
        highSpeedQualities = listOf(Quality.FHD, Quality.HD),
        highSpeedFpsRanges = listOf(Range(120, 120), Range(30, 120), Range(240, 240)),
        minFrameDurationBySizeNs =
          mapOf(
            size4k to 33_333_333L, // 30 fps max at 4K
            size1080p to 16_666_666L, // 60 fps capable at 1080p
          ),
        isCameraXStabilizationSupported = true,
        isOisSupported = true,
        isEisSupported = true,
        maxEncoderBitrateBps = 100_000_000,
      )

    assertTrue(caps4kSelected.availabilityOf(VideoQualityOption.UHD_4K).isSupported)
    assertTrue(caps4kSelected.availabilityOf(VideoFpsOption.FPS_24).isSupported)
    assertTrue(caps4kSelected.availabilityOf(VideoFpsOption.FPS_30).isSupported)
    assertFalse(caps4kSelected.availabilityOf(VideoFpsOption.FPS_60).isSupported)
    assertTrue(caps4kSelected.availabilityOf(VideoFpsOption.FPS_120).isSupported)
    assertTrue(caps4kSelected.availabilityOf(VideoFpsOption.FPS_240).isSupported)
    assertTrue(caps4kSelected.hdrAvailability.isSupported)
    assertEquals("HLG10", caps4kSelected.hdrAvailability.label)

    // Same sensor with 1080p selected unlocks 60fps
    val caps1080pSelected =
      VideoCapabilityManager.evaluateCapabilitiesCore(
        cameraId = "0",
        supportedCameraXQualities = listOf(Quality.UHD, Quality.FHD, Quality.HD),
        resolvedQualitySizes = mapOf(Quality.UHD to size4k, Quality.FHD to size1080p),
        hdrSupportedQualities = listOf(Quality.UHD, Quality.FHD),
        preferredHdrRange = DynamicRange.HLG_10_BIT,
        hasHardwareQhdProfile = false,
        selectedQuality = VideoQualityOption.FHD_1080P,
        standardFpsRanges = listOf(Range(24, 24), Range(30, 30), Range(60, 60)),
        highSpeedQualities = listOf(Quality.FHD, Quality.HD),
        highSpeedFpsRanges = listOf(Range(120, 120), Range(240, 240)),
        minFrameDurationBySizeNs =
          mapOf(
            size4k to 33_333_333L,
            size1080p to 16_666_666L,
          ),
        isCameraXStabilizationSupported = true,
        isOisSupported = true,
        isEisSupported = true,
        maxEncoderBitrateBps = 100_000_000,
      )
    assertTrue(caps1080pSelected.availabilityOf(VideoFpsOption.FPS_60).isSupported)
  }

  @Test
  fun `viewmodel sanitizes video settings across camera switches and blocks high-speed hdr conflict`() {
    val vm = CameraViewModel()
    val flagshipBack =
      VideoCapabilityManager.evaluateCapabilitiesCore(
        cameraId = "0",
        supportedCameraXQualities = listOf(Quality.UHD, Quality.FHD, Quality.HD),
        resolvedQualitySizes =
          mapOf(
            Quality.UHD to Size(3840, 2160),
            Quality.FHD to Size(1920, 1080),
            Quality.HD to Size(1280, 720),
          ),
        hdrSupportedQualities = listOf(Quality.UHD, Quality.FHD),
        preferredHdrRange = DynamicRange.HLG_10_BIT,
        hasHardwareQhdProfile = false,
        selectedQuality = VideoQualityOption.UHD_4K,
        standardFpsRanges = listOf(Range(24, 24), Range(30, 30), Range(60, 60)),
        highSpeedQualities = listOf(Quality.FHD),
        highSpeedFpsRanges = listOf(Range(120, 120)),
        minFrameDurationBySizeNs = emptyMap(),
        isCameraXStabilizationSupported = true,
        isOisSupported = true,
        isEisSupported = true,
        maxEncoderBitrateBps = 85_000_000,
      )
    vm.updateVideoCapabilities(flagshipBack)
    vm.selectCaptureDomain(AppCaptureDomain.VIDEO)
    assertEquals(AppCaptureDomain.VIDEO, vm.uiState.value.captureDomain)

    vm.selectVideoQuality(VideoQualityOption.UHD_4K)
    vm.selectVideoBitrate(VideoBitrateOption.MBPS_80)
    vm.selectVideoStabilization(StabilizationSelection.OIS)
    vm.toggleVideoHdr()
    assertEquals(VideoQualityOption.UHD_4K, vm.uiState.value.videoSettings.quality)
    assertEquals(VideoBitrateOption.MBPS_80, vm.uiState.value.videoSettings.bitrate)
    assertEquals(StabilizationSelection.OIS, vm.uiState.value.videoSettings.stabilization)
    assertTrue(vm.uiState.value.videoSettings.isHdrEnabled)

    // Selecting 120fps must disable HDR and switch from 4K to supported FHD high-speed quality
    vm.selectVideoFps(VideoFpsOption.FPS_120)
    assertEquals(VideoFpsOption.FPS_120, vm.uiState.value.videoSettings.fps)
    assertEquals(VideoQualityOption.FHD_1080P, vm.uiState.value.videoSettings.quality)
    assertFalse(vm.uiState.value.videoSettings.isHdrEnabled)

    // Switching to a limited front sensor drops 120fps, 80M bitrate, and OIS
    val restrictedFront =
      VideoCapabilityManager.evaluateCapabilitiesCore(
        cameraId = "1",
        supportedCameraXQualities = listOf(Quality.FHD, Quality.HD),
        resolvedQualitySizes =
          mapOf(Quality.FHD to Size(1920, 1080), Quality.HD to Size(1280, 720)),
        hdrSupportedQualities = emptyList(),
        preferredHdrRange = null,
        hasHardwareQhdProfile = false,
        selectedQuality = VideoQualityOption.FHD_1080P,
        standardFpsRanges = listOf(Range(30, 30)),
        highSpeedQualities = emptyList(),
        highSpeedFpsRanges = emptyList(),
        minFrameDurationBySizeNs = emptyMap(),
        isCameraXStabilizationSupported = false,
        isOisSupported = false,
        isEisSupported = false,
        maxEncoderBitrateBps = 25_000_000,
      )
    vm.updateVideoCapabilities(restrictedFront)

    assertEquals(VideoQualityOption.FHD_1080P, vm.uiState.value.videoSettings.quality)
    assertEquals(VideoFpsOption.FPS_30, vm.uiState.value.videoSettings.fps)
    assertEquals(VideoBitrateOption.AUTO, vm.uiState.value.videoSettings.bitrate)
    assertEquals(StabilizationSelection.AUTO, vm.uiState.value.videoSettings.stabilization)
    assertFalse(vm.uiState.value.videoSettings.isHdrEnabled)
  }

  @Test
  fun `silent video mode audio permission state and active recording guards behave properly`() {
    val vm = CameraViewModel()
    vm.selectCaptureDomain(AppCaptureDomain.VIDEO)

    assertTrue(vm.uiState.value.videoSettings.isAudioEnabled)
    assertEquals(
      AudioPermissionStatus.NOT_REQUESTED,
      vm.uiState.value.videoRecordingState.audioPermissionStatus,
    )

    // Simulate user denying mic permission and choosing Silent Video
    vm.setPendingRecordWithAudio(true)
    vm.updateAudioPermissionStatus(AudioPermissionStatus.DENIED, pendingRecord = false)
    vm.enableSilentVideoMode()
    assertFalse(vm.uiState.value.videoSettings.isAudioEnabled)
    assertFalse(vm.uiState.value.videoRecordingState.pendingRecordWithAudio)

    // Start recording in silent mode
    vm.onVideoRecordingStarted(withAudio = false)
    assertTrue(vm.uiState.value.videoRecordingState.isRecording)
    assertFalse(vm.uiState.value.videoRecordingState.hasAudioTrack)
    assertTrue(vm.uiState.value.videoRecordingState.canPauseOrResume)

    // Domain switching and audio toggling are blocked while recording
    vm.selectCaptureDomain(AppCaptureDomain.PHOTO)
    assertEquals(AppCaptureDomain.VIDEO, vm.uiState.value.captureDomain)
    vm.toggleVideoAudio()
    assertFalse(vm.uiState.value.videoSettings.isAudioEnabled)

    // Status, pause, resume, and failure reset
    vm.onVideoRecordingStatus(durationMs = 12_500L, bytes = 15_000_000L, amplitude = 0f, hasAudio = false)
    assertEquals(12_500L, vm.uiState.value.videoRecordingState.elapsedDurationMs)
    assertEquals(15_000_000L, vm.uiState.value.videoRecordingState.recordedBytes)

    vm.onVideoRecordingPaused()
    assertTrue(vm.uiState.value.videoRecordingState.isPaused)
    vm.onVideoRecordingResumed()
    assertFalse(vm.uiState.value.videoRecordingState.isPaused)

    vm.onVideoRecordingFailed("Disk full")
    assertFalse(vm.uiState.value.videoRecordingState.isRecording)
    assertEquals(0L, vm.uiState.value.videoRecordingState.elapsedDurationMs)
    assertNotNull(vm.uiState.value.errorMessage)
  }

  @Test
  fun `video duration formatter formats short medium and long durations cleanly`() {
    assertEquals("00:00", MediaStoreVideoSaver.formatDurationMs(0L))
    assertEquals("00:09", MediaStoreVideoSaver.formatDurationMs(9_400L))
    assertEquals("02:15", MediaStoreVideoSaver.formatDurationMs(135_000L))
    assertEquals("1:05:08", MediaStoreVideoSaver.formatDurationMs(3_908_000L))
  }
}
